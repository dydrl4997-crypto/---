import {getStore} from '@netlify/blobs';
import {scanMarket,slotOf,alertCandidates,notifyTelegram,isStale} from '../../server/scan.mjs';
import {timingSafeEqual} from 'node:crypto';
export default async request=>{
 const secret=process.env.SCAN_SECRET||'', actual=request.headers.get('authorization')||'', expected='Bearer '+secret;
 if(request.method!=='POST'||secret.length<32||Buffer.byteLength(actual)!==Buffer.byteLength(expected)||!timingSafeEqual(Buffer.from(actual),Buffer.from(expected)))return;
 const store=getStore({name:'dark-scan-v78',consistency:'strong'}),slot=slotOf(Date.now());
 // Atomic per-slot claim. Retrying in the same interval never double-scans/sends.
 const lock='claim-'+slot;if(!(await store.setJSON(lock,{slot},{onlyIfNew:true})).modified)return;
 // Clean up the same interval's claim from a week ago (bounded normal-operation storage).
 await store.delete('claim-'+(slot-7*86400000)).catch(()=>{});
 const previous=await store.get('history',{type:'json'})||{};
 const snapshot=await scanMarket({scope:process.env.SCAN_SCOPE==='broad'?'broad':'rise',warnings:(process.env.SCAN_WARNINGS||'').split(',').map(x=>x.trim().toUpperCase()).filter(Boolean).map(x=>x.startsWith('KRW-')?x:'KRW-'+x),previous});
 const rows=alertCandidates(snapshot,previous);snapshot.notification={status:'발송 전'};
 await store.setJSON('latest',snapshot);
 if(!isStale(snapshot))snapshot.notification=await notifyTelegram(rows);else snapshot.notification={status:'시간 초과로 차단'};
 // Failed/missing data does not clear previous alert keys; rearm only after a verified non-alert state.
 for(const r of snapshot.results){if(r.tier==='U'||!['OK','PARTIAL'].includes(snapshot.status))continue;const prior=previous[r.symbol]||{};const key=`${r.strategy}|${r.tier}|${r.phase}`;const eligible=(r.tier==='A'&&r.signal==='GREEN')||(r.tier==='B'&&r.signal==='YELLOW'&&r.phase==='진입 임박');previous[r.symbol]={firstTier:r.firstTier||r.tier,tier:r.tier,key:!eligible?'':snapshot.notification.status==='발송 성공'&&rows.includes(r)?key:prior.key};}
 await store.setJSON('history',previous);await store.setJSON('latest',snapshot);
};
export const config={background:true};
