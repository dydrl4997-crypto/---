import {getStore} from '@netlify/blobs';
import {isStale} from '../../server/scan.mjs';
const headers={'cache-control':'no-store','content-type':'application/json'};
export default async request=>{
 if(request.method!=='GET')return new Response(null,{status:405});
 try{const x=await getStore({name:'dark-scan-v78',consistency:'strong'}).get('latest',{type:'json'});if(!x)return Response.json({status:'NOT_RUN',stale:true,message:'서버 첫 검색 대기',results:[]},{headers});
 const stale=isStale(x);return Response.json({...x,stale,results:stale||!['OK','PARTIAL'].includes(x.status)?[]:x.results},{headers});
 }catch{return Response.json({status:'FAILED',stale:true,message:'서버 저장소 조회 실패',results:[]},{headers,status:503});}
};
