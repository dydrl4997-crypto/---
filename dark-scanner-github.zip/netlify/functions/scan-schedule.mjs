export default async (_request,context)=>{
 const secret=process.env.SCAN_SECRET;if(!secret||secret.length<32)throw Error('SCAN_SECRET (32자 이상) 미설정');
 const base=process.env.URL||context.site?.url;if(!base)throw Error('사이트 URL 없음');
 const res=await fetch(new URL('/.netlify/functions/scan-worker',base),{method:'POST',headers:{authorization:'Bearer '+secret},signal:AbortSignal.timeout(10000)});
 if(res.status!==202)throw Error('백그라운드 요청 실패 '+res.status);
};
export const config={schedule:'1,16,31,46 * * * *'};
