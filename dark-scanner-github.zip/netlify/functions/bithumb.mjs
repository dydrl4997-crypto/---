// Anonymous, read-only Bithumb public API proxy. No API credentials, trading, or open proxy behavior.
const allow=/^v1\/(market\/all|ticker|candles\/minutes\/(15|30|60|240))\?/;
export default async (request)=>{
 const q=new URL(request.url).searchParams.get('path')||'';
 if(!allow.test(q))return Response.json({error:'지원하지 않는 공개 API 경로'},{status:400});
 const ctrl=new AbortController(),t=setTimeout(()=>ctrl.abort(),12000);
 try{
  const r=await fetch('https://api.bithumb.com/'+q,{signal:ctrl.signal,headers:{accept:'application/json'}});
  return new Response(await r.text(),{status:r.status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'public, max-age=15'}});
 }catch(e){return Response.json({error:String(e.message||e)},{status:502});}finally{clearTimeout(t);}
};
export const config={path:'/.netlify/functions/bithumb'};
