import assert from 'node:assert/strict';
import {dailyVolatilityExpansion,analyzeSymbol} from '../js/engine.mjs';
const start=Date.parse('2026-11-20T15:00:00Z'); // Nov 21 00:00 KST
const bars=[];
for(let i=0;i<96*2+8;i++){
 const day=Math.floor(i/96),j=i%96,base=100;
 const spread=day===0?2:day===1?8:12;
 const open=base, high=base+spread*(j/(day===2?7:95)), low=base-spread*(j/(day===2?7:95));
 bars.push({time:start+i*900000,end:start+(i+1)*900000,open,close:base+(day===2?3:0),high,low,volume:100,turnover:day===2?300:100});
}
const r=dailyVolatilityExpansion(bars);
assert.equal(r.verified,true);assert.equal(r.direction,'UP');assert.equal(r.expanded,true);assert.equal(r.elapsedBars,8);
assert.equal(r.previousKey,'2026-11-22');assert.equal(r.currentKey,'2026-11-23');
assert.equal(r.liquidityConfirmed,true);
assert.equal(dailyVolatilityExpansion(bars.slice(-90)).verified,false);
assert.equal(dailyVolatilityExpansion(bars.slice(0,96)).verified,false);
const fake=(n,u)=>Array.from({length:n},(_,i)=>({time:i*u*60000,end:(i+1)*u*60000,open:100,close:100,high:101,low:99,volume:100,turnover:100}));
assert.ok('volatility' in analyzeSymbol('KRW-TEST',{'15m':bars,'1h':fake(200,60),'4h':fake(100,240)}));
console.log('PASS: KST calendar-day separation, expanding up move, same-time turnover, missing-data gate');
