import assert from 'node:assert/strict';
import {analyzeChartPatterns,bestPattern} from '../js/patterns.mjs';
assert.deepEqual(analyzeChartPatterns([]),[]);
const bars=Array.from({length:80},(_,i)=>({open:100+i*.08,close:100+i*.08+.2,high:102+i*.08,low:98+i*.08,turnover:1000,end:i*3600000}));
const result=analyzeChartPatterns(bars);
assert(Array.isArray(result));
assert(result.every(x=>['형성 중','돌파 대기','돌파 확인','무효화','목선 돌파 대기','목선 돌파 확인'].includes(x.stage)));
assert.equal(bestPattern([]),null);
console.log('v7.6 patterns OK');
