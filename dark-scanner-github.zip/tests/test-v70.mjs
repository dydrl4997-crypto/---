import assert from 'node:assert/strict';
import {surgePullback} from '../js/surge-pullback.mjs';
const start=Date.UTC(2026,10,24,0,0)-9*3600000;
const bars=Array.from({length:55},(_,i)=>{const close=i<42?100:i===42?108:i===43?110:i===44?107:i===45?105:i===46?104:i===47?105:i===48?106:i===49?106:i===50?105:i===51?106:i===52?107:i===53?108:109;return {end:start+(i+1)*900000,open:close-.4,close,high:close+1,low:close-1,turnover:100,volume:10};});
const unqualified=surgePullback(bars,{qualified:false});assert.equal(unqualified.discovered,false);
const result=surgePullback(bars,{qualified:true,currentKey:'2026-11-24'});assert.equal(typeof result.stage,'string');assert.equal(typeof result.trigger,'boolean');
console.log('PASS: v7 surge detection input and stage guards');
