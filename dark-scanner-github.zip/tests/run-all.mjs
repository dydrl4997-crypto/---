import {readdir} from 'node:fs/promises';
for(const f of (await readdir(new URL('.',import.meta.url))).filter(x=>x.startsWith('test-')&&x.endsWith('.mjs')).sort())await import('./'+f);
