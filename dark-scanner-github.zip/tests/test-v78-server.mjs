import assert from 'node:assert/strict';
import {scanMarket,alertCandidates,notifyTelegram,isStale,slotOf} from '../server/scan.mjs';
import {validateSets,units} from '../js/data-health.mjs';
import {closedBars} from '../js/api.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import schedule,{config} from '../netlify/functions/scan-schedule.mjs';
const now=Date.parse('2026-11-25T05:16:00Z'),clock=()=>now;
function raw(unit){let end=Math.floor(now/(unit*60000))*unit*60000;return Array.from({length:200},(_,i)=>({candle_date_time_utc:new Date(end-(200-i)*unit*60000).toISOString().slice(0,-1),opening_price:100,trade_price:100,high_price:101,low_price:99,candle_acc_trade_volume:10,candle_acc_trade_price:1000}));}
const sets=Object.fromEntries(Object.entries(units).map(([tf,u])=>[tf,closedBars(raw(u),u,now)]));
validateSets(sets,now);
assert.throws(()=>validateSets({...sets,'15m':sets['15m'].slice(0,-1)},now),/최신/);
assert.throws(()=>validateSets({...sets,'15m':sets['15m'].filter((_,i)=>i!==100)},now),/누락/);
assert.throws(()=>validateSets({...sets,'15m':[...sets['15m'].slice(0,-1),sets['15m'].at(-2)]},now),/중복/);
const api=async(p,args)=>p==='v1/market/all'?[{market:'KRW-TEST',korean_name:'테스트'}]:p==='v1/ticker'?[{market:'KRW-TEST',acc_trade_price_24h:1e9,signed_change_rate:.1,trade_price:100}]:raw(Number(p.split('/').at(-1)));
const options={api,now:clock,wait:async()=>{}};
const x=await scanMarket(options);assert.equal(x.status,'OK');assert.equal(x.valid,1);assert.equal(x.results[0].tier,analyzeSymbol('KRW-TEST',sets).tier);assert.equal(x.results[0].score,analyzeSymbol('KRW-TEST',sets).score);
const failed=await scanMarket({...options,api:async()=>{throw Error('DNS');}});assert.equal(failed.status,'FAILED');assert.deepEqual(alertCandidates(failed,{},now),[]);
const bad=await scanMarket({...options,api:async(p,a)=>p.endsWith('/15')?raw(15).slice(0,-1):api(p,a)});assert.equal(bad.results[0].tier,'U');assert.equal(bad.status,'FAILED');
const candidate={symbol:'KRW-TEST',koreanName:'테스트',strategy:'눌림목',tier:'A',signal:'GREEN',phase:'진입 검토',price:100,entryStop:98,entryRR:2,candleEnds:{'15m':slotOf(now)}};
const ready={...x,results:[candidate]};assert.equal(alertCandidates(ready,{},now).length,1);assert.equal(alertCandidates(ready,{'KRW-TEST':{key:'눌림목|A|진입 검토'}},now).length,0);assert.equal(alertCandidates(ready,{},now+900000).length,0);assert.equal(isStale(ready,now+900000),true);assert.equal(alertCandidates({...ready,status:'FAILED'}, {}, now).length,0);
assert.equal((await notifyTelegram([candidate],{})).status,'미설정');
let payload;assert.equal((await notifyTelegram([candidate],{TELEGRAM_BOT_TOKEN:'fake',TELEGRAM_CHAT_ID:'fake'},async(url,opts)=>{payload=JSON.parse(opts.body);return {ok:true,json:async()=>({ok:true})};})).status,'발송 성공');assert.match(payload.text,/자동 매매 아님/);
assert.equal((await notifyTelegram([candidate],{TELEGRAM_BOT_TOKEN:'fake',TELEGRAM_CHAT_ID:'fake'},async()=>({ok:false}))).status,'발송 실패');
assert.equal(config.schedule,'1,16,31,46 * * * *');let old=global.fetch;let oldSecret=process.env.SCAN_SECRET,oldURL=process.env.URL;process.env.SCAN_SECRET='x'.repeat(32);process.env.URL='https://example.invalid';try{global.fetch=async(url,opts)=>{assert.equal(String(url),'https://example.invalid/.netlify/functions/scan-worker');assert.equal(opts.headers.authorization,'Bearer '+'x'.repeat(32));return {status:202};};await schedule(null,{});}finally{global.fetch=old;if(oldSecret===undefined)delete process.env.SCAN_SECRET;else process.env.SCAN_SECRET=oldSecret;if(oldURL===undefined)delete process.env.URL;else process.env.URL=oldURL;}
console.log('PASS v7.8: shared engine parity, missing/stale/duplicate data, failure suppression, repeat suppression, mock Telegram and scheduler');
