import assert from 'node:assert/strict';
import {rsiSeries,pivots,detectDivergences,analyzeSymbol} from '../js/engine.mjs';
assert.equal(rsiSeries([1,2,3]).length,3);
assert.deepEqual(pivots([3,2,1,2,3,2,1,3],'low',2,1),[2,6]);
assert.deepEqual(detectDivergences([], '15m'), []);
const make=(n,unit)=>Array.from({length:n},(_,i)=>{const p=100+i*.05+Math.sin(i/4)*.25;const open=p-.08;return{open,high:p+.1,low:open-.1,close:p,volume:1000,turnover:4000,time:i*unit*60000,end:(i+1)*unit*60000}});
const sets={'15m':make(100,15),'1h':make(200,60),'4h':make(100,240)};
const out=analyzeSymbol('KRW-ELSA',sets);
assert.notEqual(out.tier,'A','RVOL<=1 and no volume recovery should not be auto-A');
assert.equal(out.volumeCore,false);
assert.equal(out.points['거래량·가격']<=8,true);
assert.equal(analyzeSymbol('KRW-ELSA',{'15m':[],'1h':[],'4h':[]}).tier,'U');
const r=analyzeSymbol('KRW-ELSA',sets,{marketWarning:'MANUAL WARNING'});
assert.notEqual(r.tier,'A','manual exchange caution blocks A');
console.log('PASS: closed candle scoring gates, insufficient data, divergence baseline, manual risk warnings');

assert.ok(!(out.phase==='진입 임박' && (out.verifiedFactors<3 || !out.fifteenVolumeCore)), '진입 임박은 핵심 검증 3개와 15분 거래량 확인 필요');
assert.ok(!(out.tier==='A' && (out.verifiedFactors<3 || !out.fifteenVolumeCore)), 'A는 핵심 근거 필수');
