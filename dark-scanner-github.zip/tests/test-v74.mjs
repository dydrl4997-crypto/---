import assert from 'node:assert/strict';
import {analyzeSymbol} from '../js/engine.mjs';
const bars=(n,mins)=>Array.from({length:n},(_,i)=>({open:100,close:100,high:101,low:99,volume:10,turnover:100,time:i*mins*60000,end:(i+1)*mins*60000}));
const a=analyzeSymbol('KRW-TEST',{'15m':bars(200,15),'1h':bars(200,60),'4h':bars(100,240)});
assert.equal(a.oneHourPullbackVolumeConfirmed,false);
assert.equal(a.oneHourPullbackConfirmed,false);
assert.notEqual(a.tier,'A');
console.log('PASS v7.4: no 1h breakout/retest/volume => no A');
