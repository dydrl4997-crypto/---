import assert from 'node:assert/strict';
import handler from '../netlify/functions/bithumb.mjs';
import {dailySevenPercentMover} from '../js/engine.mjs';
let requests=0;
const originalFetch=globalThis.fetch;
try {
 globalThis.fetch=async()=>{requests++;return new Response('[]',{status:200});};
 for(const unit of [15,30,60,240]){
  const p=`v1/candles/minutes/${unit}?market=KRW-BTC&count=200`;
  const r=await handler(new Request('https://local.test/.netlify/functions/bithumb?path='+encodeURIComponent(p)));
  assert.equal(r.status,200,`${unit}m proxy should allow request`);
 }
 const blocked=await handler(new Request('https://local.test/.netlify/functions/bithumb?path='+encodeURIComponent('v1/candles/minutes/5?market=KRW-BTC')));
 assert.equal(blocked.status,400);assert.equal(requests,4);
}finally{globalThis.fetch=originalFetch;}
const t=Date.parse('2026-11-25T00:00:00+09:00');
const b=(i,open,high,close)=>({open,high,low:Math.min(open,close),close,volume:10,turnover:100,time:t+i*900000,end:t+(i+1)*900000});
const full=Array.from({length:20},(_,i)=>b(i,120,120,120)).concat([b(20,100,110,105),b(21,105,109,105)]);
assert.equal(dailySevenPercentMover(full).qualified,false);
for(const broken of [full.slice(20),full.filter((_,i)=>i!==10),[...full,full.at(-1)]]){
 const r=dailySevenPercentMover(broken);assert.equal(r.verified,false);assert.equal(r.qualified,false);
}
console.log('PASS: 30m proxy (mock upstream), KST +7% missing/duplicate candle rejection');
