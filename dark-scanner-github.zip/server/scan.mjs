import {closedBars} from '../js/api.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import {determineUniverse} from '../js/universe.mjs';
import {validateSets,units} from '../js/data-health.mjs';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export const slotOf=t=>Math.floor(t/900000)*900000;
export function makeApi(fetcher=fetch){return async(path,params)=>{
 const res=await fetcher('https://api.bithumb.com/'+path+'?'+new URLSearchParams(params),{signal:AbortSignal.timeout(10000),headers:{accept:'application/json'}});
 if(!res.ok)throw Error('빗썸 HTTP '+res.status);
 const x=await res.json();if(!Array.isArray(x))throw Error('빗썸 응답 형식 오류');return x;
};}
export async function scanMarket({api=makeApi(),now=Date.now,wait=sleep,scope='rise',warnings=[],previous={},analyze=analyzeSymbol}={}){
 const startedAt=now(),slot=slotOf(startedAt),results=[], errors=[];
 const base={version:'7.8',startedAt,slot,scope,marketCount:0,total:0,valid:0,invalid:0,results,errors};
 try{
  const markets=(await api('v1/market/all',{isDetails:'true'})).filter(x=>/^KRW-[A-Z0-9]+$/.test(x.market));
  base.marketCount=markets.length;if(!markets.length)throw Error('원화마켓 목록 없음');
  const ts=[];for(let i=0;i<markets.length;i+=45){ts.push(...await api('v1/ticker',{markets:markets.slice(i,i+45).map(x=>x.market).join(',')}));await wait(200);}
  const validTickers=new Set(ts.filter(t=>Number.isFinite(Number(t.acc_trade_price_24h))&&Number.isFinite(Number(t.signed_change_rate))&&Number(t.trade_price)>0).map(t=>t.market));
  if(markets.some(m=>!validTickers.has(m.market)))throw Error('전체 시세 일부 누락/형식 오류');
  const universe=determineUniverse(markets,ts,scope==='broad');base.total=universe.length;if(!universe.length)throw Error('검색 대상 없음');
  const meta=new Map(markets.map(m=>[m.market,m]));let i=0;
  // Three workers, at most 3 simultaneous upstream requests; no burst of 12.
  async function worker(){while(i<universe.length){const symbol=universe[i++],m=meta.get(symbol);let r;
    try{
      if(now()-startedAt>10*60000||slotOf(now())!==slot)throw Error('검색 시간 초과 / 새 봉 마감');
      const sets={};for(const [tf,unit] of Object.entries(units)){sets[tf]=closedBars(await api('v1/candles/minutes/'+unit,{market:symbol,count:200}),unit,startedAt);await wait(150);}
      validateSets(sets,startedAt);r=analyze(symbol,sets,{marketWarning:warnings.includes(symbol)?'MANUAL WARNING':m.market_warning||'NONE'});
      r.candleEnds=Object.fromEntries(Object.entries(sets).map(([k,v])=>[k,v.at(-1).end]));
    }catch(e){r={symbol,tier:'U',score:0,signal:'GRAY',entryState:'데이터 미검증',reason:String(e.message),checkedAt:new Date(now()).toISOString()};}
    r.koreanName=m.korean_name||symbol;r.firstTier=previous[symbol]?.firstTier||(r.tier==='U'?undefined:r.tier);r.previousTier=previous[symbol]?.tier||r.tier;
    if(r.tier==='U')errors.push({symbol,reason:r.reason});results.push(r);
  }}
  await Promise.all(Array.from({length:Math.min(3,universe.length)},worker));
  base.valid=results.filter(r=>r.tier!=='U').length;base.invalid=results.length-base.valid;
  results.sort((a,b)=>({A:0,B:1,C:2,U:3}[a.tier]-{A:0,B:1,C:2,U:3}[b.tier])||Number(b.phase==='진입 임박')-Number(a.phase==='진입 임박')||b.score-a.score);
  if(slotOf(now())!==slot||now()-startedAt>10*60000)return {...base,status:'STALE',message:'검색 시간 초과 또는 새 봉 마감 — 신호 차단',finishedAt:now()};
  return {...base,status:base.valid===0?'FAILED':base.invalid?'PARTIAL':'OK',message:base.invalid?'일부 또는 전체 데이터 미검증':'선정 후보 데이터 검증 완료',finishedAt:now()};
 }catch(e){return {...base,status:'FAILED',message:String(e.message),finishedAt:now()};}
}
export function isStale(x,now=Date.now()){return !x||!Number.isFinite(x.slot)||slotOf(now)!==x.slot||!Number.isFinite(x.finishedAt)||now-x.finishedAt>15*60000;}
export function alertCandidates(snapshot,previous={},now=Date.now()){
 if(isStale(snapshot,now)||!['OK','PARTIAL'].includes(snapshot.status))return [];
 return snapshot.results.filter(r=>r.candleEnds?.['15m']===snapshot.slot&&((r.tier==='A'&&r.signal==='GREEN')||(r.tier==='B'&&r.signal==='YELLOW'&&r.phase==='진입 임박'))&&Number.isFinite(r.price)&&Number.isFinite(r.entryStop)&&r.entryStop>0&&r.entryStop<r.price&&Number.isFinite(r.entryRR)&&r.entryRR>0&&previous[r.symbol]?.key!==`${r.strategy}|${r.tier}|${r.phase}`).slice(0,5);
}
export async function notifyTelegram(rows,env=process.env,fetcher=fetch){
 if(!env.TELEGRAM_BOT_TOKEN||!env.TELEGRAM_CHAT_ID)return {status:'미설정'};
 if(!rows.length)return {status:'새 후보 없음'};
 const text='다크 트레이딩 연구소 · 확정봉 후보 (자동 매매 아님)\n'+rows.map(r=>`${r.koreanName} ${r.symbol} | ${r.tier} ${r.phase} | ${r.strategy}\n15분봉 종가 ${r.price} / 무효화 ${r.entryStop} / 손익비 ${r.entryRR.toFixed(2)}\n${new Date(r.candleEnds['15m']).toISOString()} UTC 봉 마감`).join('\n\n');
 try{const res=await fetcher(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({chat_id:env.TELEGRAM_CHAT_ID,text}),signal:AbortSignal.timeout(10000)});if(!res.ok||!(await res.json()).ok)throw Error('실패');return {status:'발송 성공',count:rows.length};}catch{return {status:'발송 실패'};}
}
