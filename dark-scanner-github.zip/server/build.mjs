import {mkdir,cp,rm} from 'node:fs/promises';
await rm('dist',{recursive:true,force:true});await mkdir('dist');for(const p of ['index.html','style.css','js'])await cp(p,'dist/'+p,{recursive:true});
