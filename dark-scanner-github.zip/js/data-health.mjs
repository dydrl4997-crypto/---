// The expected final candle is aligned to the exchange's UTC minute buckets.
export const units={'15m':15,'30m':30,'1h':60,'4h':240};
export function validateSets(sets,now){
 for(const [tf,mins] of Object.entries(units)){
  const bars=sets[tf],step=mins*60000,expected=Math.floor(now/step)*step;
  if(!Array.isArray(bars)||!bars.length)throw Error(tf+' 봉 누락');
  for(let i=0;i<bars.length;i++){
   const b=bars[i];if(![b.time,b.end,b.open,b.close,b.high,b.low,b.volume,b.turnover].every(Number.isFinite)||b.time%step!==0||b.end!==b.time+step||b.low<=0||b.low>Math.min(b.open,b.close)||b.high<Math.max(b.open,b.close)||b.volume<0||b.turnover<0||(i&&b.time<=bars[i-1].time))throw Error(tf+' 봉 형식/중복 오류');
  }
  if(bars.at(-1).end!==expected)throw Error(tf+' 최신 확정봉 미수신');
  // Do not invent no-trade bars; expose gaps rather than treating them as contiguous.
  if(bars.some((b,i)=>i&&b.time-bars[i-1].time!==step))throw Error(tf+' 중간 봉 누락 (거래 없음 포함)');
 }
}
