// v7.6: heuristic discovery from COMPLETED 1h candles, not a guaranteed chart pattern or entry signal.
const avg=a=>a.reduce((s,x)=>s+x,0)/Math.max(1,a.length);
const hi=a=>Math.max(...a.map(b=>b.high));
const lo=a=>Math.min(...a.map(b=>b.low));
const ratio=(a,b)=>b>0?a/b:Infinity;
const result=(name,stage,level,invalid,detail,kind)=>({name,stage,level,invalid,detail,kind});
export function analyzeChartPatterns(bars){
 if(!Array.isArray(bars)||bars.length<55)return [];
 const a=bars.slice(-55),last=a.at(-1),prior=a.slice(-25,-1),older=a.slice(-49,-25),out=[];
 const piv=(key,type)=>{const v=a.map(x=>x[key]),r=[];for(let i=2;i<v.length-2;i++)if([1,2].every(d=>type==='low'?(v[i]<v[i-d]&&v[i]<=v[i+d]):(v[i]>v[i-d]&&v[i]>=v[i+d])))r.push({i,v:v[i]});return r;};
 const lows=piv('low','low'),highs=piv('high','high'),L=lows.slice(-3),H=highs.slice(-3);
 const highR=hi(prior),lowR=lo(prior),width=(highR-lowR)/Math.max(1e-9,last.close);
 const volBase=avg(prior.map(b=>b.turnover));
 const bullBreak=last.close>highR*1.002&&last.turnover>volBase*1.2;
 const lowBreak=last.close<lowR*.995;
 const add=(name,condition,kind='지속')=>{if(!condition)return;const stage=lowBreak?'무효화':bullBreak?'돌파 확인':last.close>highR*.985?'돌파 대기':'형성 중';out.push(result(name,stage,highR,lowR,`${stage==='돌파 확인'?'1시간봉 거래대금 동반 돌파. 재지지 확인 필요':stage==='무효화'?'패턴 하단 이탈':stage==='돌파 대기'?'상단 저항 근접, 다음 확정봉·거래량 확인':'패턴 구조 형성 중, 확정봉 추가 확인'} · 상단 ${highR.toFixed(4)} / 하단 ${lowR.toFixed(4)}`,kind));};
 const higherL=L.length>=2&&L.at(-1).v>L.at(-2).v*1.003;
 const higherH=H.length>=2&&H.at(-1).v>H.at(-2).v*1.003;
 const flatHigh=H.length>=2&&Math.abs(H.at(-1).v/H.at(-2).v-1)<.018;
 const lowerH=H.length>=2&&H.at(-1).v<H.at(-2).v*.997;
 const lowerL=L.length>=2&&L.at(-1).v<L.at(-2).v*.997;
 add('상승 삼각형',higherL&&flatHigh,'지속');
 add('상승 가격 구조(HH·HL)',higherL&&higherH,'구조');
 const recent=a.slice(-13),preceding=a.slice(-37,-13);
 const priorImpulse=preceding.at(-1).close/preceding[0].open-1;
 const tight=ratio(hi(recent)-lo(recent),last.close)<.075;
 const channelDown=avg(recent.slice(-6).map(x=>x.high))<avg(recent.slice(0,6).map(x=>x.high))*.999;
 add('상승 깃발형 후보',priorImpulse>.055&&tight&&channelDown,'지속');
 add('상승 페넌트 후보',priorImpulse>.055&&tight&&lowerH&&higherL,'지속');
 add('박스권 수축',width<.065&&ratio(hi(older)-lo(older),avg(older.map(x=>x.close)))>width*1.25,'지속');
 add('삼각수렴',lowerH&&higherL,'중립');
 add('하락 쐐기형 후보',lowerH&&lowerL&&H.length>=2&&L.length>=2&&Math.abs(H.at(-1).v-L.at(-1).v)<Math.abs(H.at(-2).v-L.at(-2).v)*.9,'반전');
 if(L.length>=2){const x=L.at(-2),y=L.at(-1),diff=Math.abs(x.v/y.v-1),between=a.slice(x.i,y.i+1),neck=hi(between);if(y.i-x.i>=4&&diff<.025)out.push(result('이중바닥 후보',last.close>neck*1.002?'목선 돌파 확인':'목선 돌파 대기',neck,Math.min(x.v,y.v),`목선 ${neck.toFixed(4)} · 종가 돌파 후 거래량과 재지지 추가 확인`,'반전'));}
 // Keep explanations concise; patterns are NOT added to A-grade score/gates.
 return out.slice(0,5);
}
export function bestPattern(patterns){return patterns.find(x=>x.stage==='돌파 확인')||patterns.find(x=>x.stage==='돌파 대기')||patterns[0]||null;}
