// v7: closed 15-minute candles only. Discovery != trade entry.
const avg=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
export function surgePullback(bars, dailyMover){
 const empty={discovered:false,stage:'해당 없음',trigger:false,reason:'당일 급등 이력 없음'};
 if(!dailyMover?.qualified||!bars||bars.length<45)return empty;
 const key=b=>new Date(b.end-1+9*3600000).toISOString().slice(0,10);
 const today=bars.filter(b=>key(b)===dailyMover.currentKey);
 if(today.length<4)return {...empty,stage:'첫 눌림 관찰',reason:'금일 확정봉 부족'};
 const peakIndex=today.reduce((best,b,i)=>b.high>today[best].high?i:best,0);
 const peak=today[peakIndex].high,open=today[0].open,last=today.at(-1);
 const after=today.slice(peakIndex+1);
 const correction=after.filter(b=>b.close<b.open);
 const low=after.length?Math.min(...after.map(b=>b.low)):peak;
 const depth=(peak-low)/peak;
 const gain=(peak/open-1);
 const base=bars.slice(-21).map(x=>x.close);
 const ema=(()=>{let e=avg(base.slice(0,20));for(const x of base.slice(20))e=x*2/21+e*19/21;return e;})();
 const prior=bars.slice(-7,-1),priorRed=prior.filter(b=>b.close<b.open);
 const turnover=Number(last.turnover)||0;
 const recovery=priorRed.length>0&&turnover>=avg(priorRed.map(x=>x.turnover))*1.2&&turnover>=avg(bars.slice(-21,-1).map(x=>x.turnover))*.8;
 const bullish=last.close>last.open&&last.close>bars.at(-2).close&&last.close>=ema;
 const recentTop=Math.max(...bars.slice(-9,-1).map(x=>x.high));
 const support=low>0&&last.close>=low*1.002&&last.close>=open*1.015;
 const isPullback=after.length>=2&&depth>=.018&&depth<=.28&&support;
 const hasBase=after.length>=5&&after.length<=48;
 const stage=!isPullback?'첫 눌림 관찰':!hasBase?'첫 눌림':bullish&&recovery&&last.close>recentTop?'2차 상승 확정':'2차 상승 준비';
 const trigger=isPullback&&bullish&&recovery&&last.close>bars.at(-2).high&&depth<=.20;
 const chasing=last.close>low*1.09 || last.close>peak*1.025;
 return {discovered:isPullback,stage,trigger:trigger&&!chasing,peak,low,depthPct:depth*100,peakGainPct:gain*100,volumeRecovery:recovery,ema20:ema,stop:low*.997,chasing,reason:!isPullback?'조정 깊이·지지 구조 미충족':chasing?'저점 대비 추격 구간':!bullish?'15분봉 반전 확정 대기':!recovery?'거래량 회복 대기':trigger?'15분봉 반전·거래량 확인':'추가 가격 구조 확인 대기'};
}
