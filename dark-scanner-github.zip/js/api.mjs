const ROOT='https://api.bithumb.com';
const MAX_DELAY=15000;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function url(path,params={}){const s=new URLSearchParams(params);return `${path}${s.size?'?'+s.toString():''}`;}
export async function apiGet(path,params={}){
 // Prefer same-origin function for CORS reliability when deployed through Git/CLI with Netlify Functions.
 // Direct Bithumb fallback is used for simple static hosting and depends on exchange CORS policy.
 const q=url(path,params);let lastErr;
 const paths=[`/.netlify/functions/bithumb?path=${encodeURIComponent(q)}`,`${ROOT}/${q}`];
 for(const target of paths){
  const ctrl=new AbortController(),t=setTimeout(()=>ctrl.abort(),MAX_DELAY);
  try{const r=await fetch(target,{signal:ctrl.signal,headers:{accept:'application/json'},cache:'no-store'});
   if(!r.ok)throw Error('HTTP '+r.status);const data=await r.json();
   if(!Array.isArray(data)&&(!data||typeof data!=='object'||data.error))throw Error(data?.error?.message||'API 형식 오류');
   return data;
  }catch(e){lastErr=e;}finally{clearTimeout(t);}
 }
 throw Error('빗썸 API 접근 실패: '+(lastErr?.message||'연결 불가')+' · 네트워크/CORS 및 Netlify Function 배포 확인');
}
export async function marketList(){return (await apiGet('v1/market/all',{isDetails:'true'})).filter(v=>v.market?.startsWith('KRW-'));}
export async function tickers(markets){const all=[];for(let i=0;i<markets.length;i+=45){const chunk=markets.slice(i,i+45);const r=await apiGet('v1/ticker',{markets:chunk.join(',')});all.push(...r);await sleep(180);}return all;}
export function closedBars(raw,unitMins,now=Date.now()){
 if(!Array.isArray(raw))return[];
 return raw.map(r=>{
  const start=Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z');
  const end=start+unitMins*60000;
  return{open:Number(r.opening_price),close:Number(r.trade_price),high:Number(r.high_price),low:Number(r.low_price),volume:Number(r.candle_acc_trade_volume),turnover:Number(r.candle_acc_trade_price),time:start,end};
 }).filter(b=>Number.isFinite(b.end)&&b.end<=now-1000&&[b.open,b.close,b.high,b.low,b.volume,b.turnover].every(Number.isFinite)&&b.volume>=0).sort((a,b)=>a.time-b.time);
}
export async function candles(market,unit){const raw=await apiGet(`v1/candles/minutes/${unit}`,{market,count:200});return closedBars(raw,unit);}
export async function symbolSets(market){const [m,n,h,q]=await Promise.all([candles(market,15),candles(market,30),candles(market,60),candles(market,240)]);return{'15m':m,'30m':n,'1h':h,'4h':q};}
