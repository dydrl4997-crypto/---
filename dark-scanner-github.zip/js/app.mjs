import {marketList,tickers,symbolSets} from './api.mjs';
import {determineUniverse} from './universe.mjs';
import {validateSets} from './data-health.mjs';
import {analyzeSymbol,tierDescription} from './engine.mjs';
const $=s=>document.querySelector(s);
const scope=$('#scope'), warn=$('#warn'), legacy=$('#legacy'), scan=$('#scan'), reset=$('#reset'), cards=$('#cards'), status=$('#status'),bar=$('#bar');
const storeKey='darklab-v6-history';const leaderKey='darklab-v6-leaders';
let leaders=[],results=[],filter='ALL',category='ALL',busy=false, history={};
function safeRead(){try{return JSON.parse(localStorage.getItem(storeKey)||'{}')}catch{return{}}}
function persist(){try{localStorage.setItem(storeKey,JSON.stringify(history))}catch{}}
function textSafe(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const f=n=>Number.isFinite(n)?n.toLocaleString('ko-KR',{maximumFractionDigits:n>=1000?0:n>=1?2:4}):'–';
function setProgress(i,total,msg){bar.style.width=(total?100*i/total:0)+'%';status.textContent=msg;}
function symbolsFromInput(value){return [...new Set(value.toUpperCase().split(/[\s,;]+/).map(s=>s.trim().replace(/^KRW-/,'')).filter(s=>/^[A-Z0-9]{2,15}$/.test(s)))];}
function leaderRank(t){
 const change=Number(t.signed_change_rate||0)*100,turnover=Number(t.acc_trade_price_24h||0);
 // Score for DISCOVERY only, not an entry grade or prediction.
 return (change>0?Math.min(change,35)*2:change*3)+Math.min(35,Math.log10(Math.max(1,turnover))*3);
}
function determineLeaders(markets,ts){
 const allowed=new Set(markets.filter(x=>!x.market_warning||x.market_warning==='NONE').map(x=>x.market));
 return ts.filter(x=>allowed.has(x.market)&&Number(x.acc_trade_price_24h)>=1000000000&&Number(x.signed_change_rate)>0)
  .sort((a,b)=>leaderRank(b)-leaderRank(a)).slice(0,15)
  .map((x,i)=>({symbol:x.market,rank:i+1,change:Number(x.signed_change_rate)*100,turnover:Number(x.acc_trade_price_24h),rankScore:leaderRank(x)}));
}
function divergenceSummary(r){
 const ds=(r.divergences||[]).filter(x=>x.confirmed);
 const weight={"15m":1,"1h":2,"4h":3};
 const bull=Math.max(0,...ds.filter(x=>x.side==='bull').map(x=>weight[x.tf]||1));
 const bear=Math.max(0,...ds.filter(x=>x.side==='bear').map(x=>weight[x.tf]||1));
 if(bear>bull)return {icon:'🔴',label:'매수 경고',reason:'하락 다이버전스 우세'};
 if(bull>bear)return {icon:'🟢',label:'반등 보조',reason:'상승 다이버전스 우세'};
 if(bull&&bear)return {icon:'🟡',label:'신호 충돌',reason:'상승·하락 신호 혼재'};
 return {icon:'⚪',label:'중립',reason:'확정 다이버전스 없음'};
}
let serverMode=false;
function display(){
 const view=results.filter(x=>(category==='ALL'||(category==='PULLBACK'&&/눌림목/.test(x.strategy||'')&&!x.surge?.discovered)||(category==='REBOUND'&&/반등/.test(x.strategy||''))||(category==='MOMENTUM'&&x.strategy==='급등 초입')||(category==='DOWNVOL'&&x.volatility?.verified&&x.volatility.expanded&&x.volatility.liquidityConfirmed&&x.volatility.direction==='DOWN')||(category==='SURGE'&&x.dailyMover?.qualified))&&(filter==='ALL'||x.tier===filter||(filter==='NEAR'&&x.phase==='진입 임박')||(filter==='CHANGED'&&x.firstTier&&x.firstTier!==x.tier)));
 const ready=results.filter(r=>r.signal==='GREEN').length;
 for(const [id,v] of [['#ma',results.filter(x=>x.tier==='A').length],['#mb',results.filter(x=>x.tier==='B').length],['#mc',results.filter(x=>x.tier==='C').length],['#md',ready]])$(id).textContent=results.length?v:'–';
 if(!view.length){cards.innerHTML=`<div class="empty">조건에 맞는 종목이 없어요.<br><small>A급이 없다면 신호를 억지로 만들지 않는 것이 정상입니다.</small></div>`;return;}
 cards.innerHTML=view.map(r=>{
  const loaded=Number.isFinite(r.price), first=r.firstTier||r.tier;
  const dv=divergenceSummary(r);
  const strategy=r.strategy||'정밀 관찰';
  const coinName=r.koreanName||r.symbol.replace('KRW-','');
  const pat=r.primaryPattern;
  const v=r.volatility; const dm=r.dailyMover;
  const changed=first!==r.tier;
  const light=r.signal||'GRAY';
  const lightText={GREEN:'🟢 초록 · 진입 검토',YELLOW:'🟡 노랑 · 조건 대기',RED:'🔴 빨강 · 진입 제외',GRAY:'⚪ 회색 · 미검증'}[light];
  const summary=(r.signalReasons||[]).slice(0,2).join(' · ')||r.reason||'추가 검증 필요';
  const invalid=Number.isFinite(pat?.invalid)?pat.invalid:r.stop;
  return `<article class="card"><div class="card-top"><div><div class="sym">${textSafe(coinName)} <small>(${textSafe(r.symbol.replace('KRW-',''))})</small></div><div class="sub">빗썸 ${textSafe(r.symbol)} · 거래소 시세 참고</div></div><span class="rating ${r.tier}">${tierDescription(r.tier)} · ${r.score}점</span></div>
   <div class="card-price-row"><div class="price">${loaded?f(r.price)+'원':'검증 불가'}</div><span class="phase-pill">${textSafe(r.phase||'미검증')}</span></div>
   <div class="traffic ${light}"><strong>${lightText}</strong><small>${textSafe(summary)}</small></div>
   <div class="card-section"><h3>① 차트 패턴</h3>${pat?`<div class="section-pair"><b>${textSafe(pat.name)}</b><span class="stage">${textSafe(pat.stage)}</span></div><p>${textSafe(pat.detail)}</p>`:'<p>뚜렷한 패턴 미발견 · 기존 가격 구조와 거래량 분석 우선</p>'}</div>
   <div class="card-section"><h3>② 진입 근거</h3><p><b>전략:</b> ${textSafe(strategy)} · <b>판단:</b> ${textSafe(r.entryState||'진입 제외')}</p><p>${textSafe(r.reason||'검증 자료 부족')}</p><div class="compact-tags"><span class="tag ${r.volumeCore?'up':'danger'}">1시간 거래량 ${r.volumeCore?'통과':'미통과'}</span><span class="tag">다이버전스 ${dv.icon} ${dv.label}</span></div></div>
   <div class="card-section"><h3>③ 진입·위험 관리</h3><div class="risk-grid"><div><small>15분 진입 무효화</small><b>${f(r.entryStop)}원</b></div><div><small>정밀 손절 기준</small><b>${f(r.stop)}원</b></div><div><small>최근 저항</small><b>${f(r.resistance)}원</b></div><div><small>진입 기준 손익비</small><b>${f(r.entryRR)} : 1</b></div></div>${pat?`<p class="risk-note">패턴 무효화 참고 ${f(invalid)}원 · 패턴 단독으로 A급 판정 불가</p>`:''}</div>
   <div class="card-verdict"><b>④ 다크의 한 줄 판단</b><p>${textSafe(r.entryState||'진입 제외')} · ${textSafe(summary)}</p></div>
   <details class="card-details"><summary>상세 분석 펼치기 · 거래량·등급·다이버전스</summary>
   <div class="detail-body"><div class="tags"><span class="tag">RVOL 1시간 ${f(r.rvol)}배 / 15분 ${f(r.rvol15)}배</span><span class="tag ${r.thirtyBearish||!r.thirtyVerified?'danger':''}">30분봉 ${textSafe(r.thirtyState||'미검증')}</span><span class="tag">확정봉 기반</span>${r.marketWarning!=='NONE'?'<span class="tag danger">⚠ 위험 경고 반영</span>':''}</div>
   <p>최초 발견 ${textSafe(first)}급 · 현재 ${textSafe(r.tier)}급 ${changed?'· 등급 변화':'· 유지'} · 원점수 ${r.score}점 (현재 등급과 다를 수 있음)</p>
   <p>다이버전스: ${textSafe(dv.reason)} · 가격·거래량·지지선 우선</p>
   ${dm?.qualified?`<p>금일 +7% 강세 추적 · 최고 +${f(dm.peakPct)}% · 현재 ${f(dm.currentPct)}% · 강세 이력 유지 · ${textSafe(r.day7PatternState||'미검증')}</p><p>급등·2차 상승: ${textSafe(r.surge?.stage||'미검증')} · ${textSafe(r.surge?.reason||'')} · 15분 트리거 ${r.surge?.trigger?'충족':'대기'}</p>`:''}
   <p>${v?.verified?`전일 대비 변동폭 ${f(v.ratio)}배 · 전일 ${f(v.prevRangePct)}% / 금일 ${f(v.todayRangePct)}% · 거래대금 ${f(v.turnoverRatio)}배 · ${v.direction==='UP'?'상승':v.direction==='DOWN'?'하락':'중립'}`:`전일 대비 변동성 미검증 · ${textSafe(v?.reason||'데이터 부족')}`}</p>
   <p>기존 손익비 ${f(r.rr)} · 핵심 근거 ${r.verifiedFactors??0}/4 · 기존 추세 검증 ${r.independent??0}/4</p>
   ${r.points?`<details><summary>점수 세부 항목</summary><table>${Object.entries(r.points).map(([k,v])=>`<tr><td>${textSafe(k)}</td><td>${v}점</td></tr>`).join('')}</table></details>`:''}
   </div></details>
   <p class="note">최종 평가 ${new Date(r.checkedAt).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'})} KST · 뉴스/언락 검증 별도</p></article>`;
 }).join('');
}
async function run(){if(busy)return;serverMode=false;busy=true;scan.disabled=true;const started=Date.now();cards.innerHTML='<div class="empty">빗썸 확정봉 데이터를 검사하고 있어요...</div>';setProgress(0,1,'빗썸 원화마켓 조회 중...');
 try{
  const markets=await marketList();const ts=await tickers(markets.map(x=>x.market));const universe=determineUniverse(markets,ts,scope.value==='broad');const risingCount=ts.filter(x=>Number(x.signed_change_rate)>0).length;const fallingCount=ts.filter(x=>Number(x.signed_change_rate)<0).length;const totalTicker=ts.length;
  if(!universe.length)throw Error('선택된 검색 코인이 없습니다. KRW 마켓 종목 코드를 확인해 주세요.');
  const selected=new Map(markets.map(x=>[x.market,x]));const manualWarn=symbolsFromInput(warn.value);
  const legacyMap={};for(const pair of legacy.value.toUpperCase().split(/[\s,;]+/)){const match=pair.match(/^([A-Z0-9]{2,15}):([ABC])$/);if(match)legacyMap[match[1]]=match[2];}
  const loaded=[];let done=0;const errors=[];
  // Max 3 concurrent market sets to respect rate limits and the user's mobile connection.
  let index=0;async function worker(){while(true){const i=index++;if(i>=universe.length)return;const market=universe[i];
   try{const s=await symbolSets(market);validateSets(s,Date.now());const metadata=selected.get(market)||{};
    const risky=manualWarn.includes(market.replace('KRW-',''))? 'MANUAL WARNING':metadata.market_warning||'NONE';
    const r=analyzeSymbol(market,s,{marketWarning:risky});
    r.koreanName=metadata.korean_name||market.replace('KRW-','');
    r.firstTier=history[market]?.firstTier||legacyMap[market.replace('KRW-','')]||r.tier;r.previousTier=history[market]?.currentTier||r.tier;
    history[market]={firstTier:r.firstTier,currentTier:r.tier,updatedAt:r.checkedAt};loaded.push(r);
   }catch(e){errors.push(market+': '+e.message);loaded.push({symbol:market,koreanName:selected.get(market)?.korean_name||market.replace('KRW-',''),tier:'U',score:0,entryState:'데이터 미검증',signal:'GRAY',firstTier:history[market]?.firstTier||'C',price:NaN,rvol:NaN,reason:'API 오류: '+e.message,divergences:[],marketWarning:'NONE',checkedAt:new Date().toISOString()});}
   done++;setProgress(done,universe.length,`${done}/${universe.length} 종목 검사 · 오류 ${errors.length}건`);
   await new Promise(r=>setTimeout(r,220));
  }}await Promise.all(Array.from({length:Math.min(3,universe.length)},()=>worker()));
  persist();results=loaded.sort((a,b)=>({A:0,B:1,C:2,U:3}[a.tier]-{A:0,B:1,C:2,U:3}[b.tier])||(a.phase==='진입 임박'?-1:0)-(b.phase==='진입 임박'?-1:0)||b.score-a.score);
  $('#updated').textContent=`${new Date().toLocaleString('ko-KR',{timeZone:'Asia/Seoul'})} KST · 수동 검색 · ${results.length}개`;
  display();setProgress(universe.length,universe.length,`검사 완료 (${Math.round((Date.now()-started)/1000)}초) · ${errors.length}건 API/데이터 오류 · 자동 갱신 아님`);
  $('#online').textContent=errors.length?'● 일부 데이터 실패':'● 홈페이지 데이터 수집 성공'; const found=results.filter(x=>x.strategy&&x.strategy!=='정밀 관찰').length; $('#diagnostics').textContent=`시장 분위기(최근 24시간): 상승 ${risingCount} / 하락 ${fallingCount} / 전체 ${totalTicker} · 전체 KRW ${markets.length}개 · 후보 분석 ${universe.length}개 · 전략 패턴 ${found}개 · A ${results.filter(x=>x.tier==='A').length} / B ${results.filter(x=>x.tier==='B').length} · 진입 임박 ${results.filter(x=>x.phase==='진입 임박').length} · 데이터 정상 ${results.filter(x=>x.tier!=='U').length}개 / 미검증 ${results.filter(x=>x.tier==='U').length}개 · API 오류 ${errors.length}개 · 푸시 감시 연결은 별도`;
 }catch(e){results=[];display();setProgress(0,1,'오류: '+e.message);$('#online').textContent='● API 연결 실패';$('#diagnostics').textContent='API 오류로 분석할 수 없습니다.';}
 finally{busy=false;scan.disabled=false;}
}
for(const btn of document.querySelectorAll('.category-filter'))btn.addEventListener('click',()=>{category=btn.dataset.category;for(const x of document.querySelectorAll('.category-filter'))x.classList.toggle('active',x===btn);display();});
for(const btn of document.querySelectorAll('.filter'))btn.addEventListener('click',()=>{filter=btn.dataset.tier;for(const x of document.querySelectorAll('.filter'))x.classList.toggle('active',x===btn);display();});
scan.addEventListener('click',run);
async function refreshServer(load=false){
 const el=$('#server-status');
 try{
  const res=await fetch('/.netlify/functions/scan-results',{cache:'no-store'});if(!res.ok)throw Error('HTTP '+res.status);
  const x=await res.json();
  const fmt=t=>t?new Date(t).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'}):'없음';
  el.textContent=`${x.stale?'오래된 결과 / 미검증':x.status} · 마지막 실행 ${fmt(x.finishedAt)} KST · 정상 ${x.valid??0}/${x.total??0} · 미검증 ${x.invalid??0} · 알림 ${x.notification?.status??'미설정'} · ${x.message??''}`;
  if(x.stale||!['OK','PARTIAL'].includes(x.status)){if(serverMode&&!busy){results=[];display();cards.textContent='서버 결과 미검증 또는 오래됨 — 현재 매매 신호 없음';}return;}
  if((load||serverMode)&&!busy){serverMode=true;results=x.results||[];display();$('#updated').textContent=`서버 검색 ${fmt(x.finishedAt)} KST · ${x.status}`;$('#diagnostics').textContent=`서버 검색 대상 ${x.total}개 · 정상 ${x.valid}개 · 미검증 ${x.invalid}개 · 시장 목록 ${x.marketCount}개`;status.textContent='서버 저장 결과 표시 · 수동 경고 입력과 별개';}
 }catch(e){el.textContent='서버 API 미연결: '+e.message;if(serverMode&&!busy){results=[];display();cards.textContent='서버 결과 조회 실패 — 매매 신호 미검증';}}
}
$('#server-load').addEventListener('click',()=>refreshServer(true));
refreshServer(true);setInterval(()=>refreshServer(false),60000);

reset.addEventListener('click',()=>{if(confirm('최초 발견 등급과 변경 기록을 초기화할까요?')){history={};persist();results=results.map(x=>({...x,firstTier:x.tier}));display();status.textContent='브라우저 내부 등급 기록을 초기화했어요.';}});
try{history=safeRead();warn.value=localStorage.getItem('darklab-v5-warn')||'';legacy.value=localStorage.getItem('darklab-v5-legacy')||'';}catch{}
for(const inp of [warn,legacy])inp.addEventListener('change',()=>{try{localStorage.setItem('darklab-v5-warn',warn.value);localStorage.setItem('darklab-v5-legacy',legacy.value)}catch{}});
