export function determineUniverse(markets,ts,broad=false){
 const allowed=new Set(markets.filter(x=>!x.market_warning||x.market_warning==='NONE').map(x=>x.market));
 const liquid=ts.filter(x=>allowed.has(x.market)&&Number(x.acc_trade_price_24h)>=300000000)
   .sort((a,b)=>Number(b.acc_trade_price_24h)-Number(a.acc_trade_price_24h));
 const positive=liquid.filter(x=>Number(x.signed_change_rate)>0)
   .sort((a,b)=>Number(b.signed_change_rate)-Number(a.signed_change_rate));
 const negative=liquid.filter(x=>Number(x.signed_change_rate)<=0)
   .sort((a,b)=>Number(b.acc_trade_price_24h)-Number(a.acc_trade_price_24h));
 // Diversified discovery: rising movers for pullbacks, liquid laggards for rebounds,
 // and turnover leaders for early momentum. 24h return != KST midnight return.
 const pool=[...positive.slice(0,broad?75:55),...liquid.slice(0,broad?120:100),...negative.slice(0,broad?75:55)];
 return [...new Set(pool.map(x=>x.market))];
}
