import {analyzeChartPatterns,bestPattern} from './patterns.mjs';
import {surgePullback} from './surge-pullback.mjs';
// Dark Trading Lab v6.2: deterministic CLOSED-CANDLE ONLY analysis.
// No inference of order flow, whale activity, or a trading probability from OHLCV alone.
export const TIER_RULES = Object.freeze({A:85,B:60});
const eps=1e-9;
export function mean(xs){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:NaN;}
export function ema(xs,period){if(xs.length<period)return NaN;const k=2/(period+1);let e=mean(xs.slice(0,period));for(let i=period;i<xs.length;i++)e=xs[i]*k+e*(1-k);return e;}
export function rsiSeries(closes,period=14){
 const out=Array(closes.length).fill(null);if(closes.length<=period)return out;
 let gain=0,loss=0;for(let i=1;i<=period;i++){const d=closes[i]-closes[i-1];gain+=Math.max(0,d);loss+=Math.max(0,-d);}
 gain/=period;loss/=period;const val=()=>loss===0?(gain===0?50:100):100-100/(1+gain/loss);
 out[period]=val();for(let i=period+1;i<closes.length;i++){const d=closes[i]-closes[i-1];gain=(gain*(period-1)+Math.max(0,d))/period;loss=(loss*(period-1)+Math.max(0,-d))/period;out[i]=val();}return out;
}
export function macdHistogram(closes){
 const out=Array(closes.length).fill(null);if(closes.length<35)return out;
 const emaLine=(n)=>{const xs=Array(closes.length).fill(null);let v=mean(closes.slice(0,n));xs[n-1]=v;const k=2/(n+1);for(let i=n;i<closes.length;i++){v=closes[i]*k+v*(1-k);xs[i]=v;}return xs;};
 const e12=emaLine(12),e26=emaLine(26);let sig=null;const mac=[];
 for(let i=25;i<closes.length;i++){const v=e12[i]-e26[i];mac.push(v);if(mac.length===9)sig=mean(mac);else if(mac.length>9)sig=v*(2/10)+sig*(8/10);if(sig!==null)out[i]=v-sig;}
 return out;
}
export function obvSeries(bars){let cur=0;return bars.map((b,i)=>{if(i){if(b.close>bars[i-1].close)cur+=b.volume;else if(b.close<bars[i-1].close)cur-=b.volume;}return cur;});}
export function pivots(values,kind,left=2,right=2){
 const out=[];for(let i=left;i<values.length-right;i++){
  if(!Number.isFinite(values[i]))continue;
  let pass=true;for(let d=1;d<=left;d++)if(kind==='low'?values[i]>=values[i-d]:values[i]<=values[i-d])pass=false;
  for(let d=1;d<=right;d++)if(kind==='low'?values[i]>values[i+d]:values[i]<values[i+d])pass=false;
  if(pass)out.push(i);
 }return out;
}
// Divergence uses CONFIRMED swing points (2 subsequent CLOSED candles) with minimum relative separation.
export function detectDivergences(bars,tf='15m'){
 const out=[];if(!bars||bars.length<45)return out;
 const closes=bars.map(x=>x.close),rsi=rsiSeries(closes),macd=macdHistogram(closes),low=bars.map(x=>x.low),high=bars.map(x=>x.high);
 for(const kind of ['low','high']){
  const idx=pivots(kind==='low'?low:high,kind).filter(i=>i>=15&&i>=bars.length-58);
  for(let j=idx.length-1;j>0;j--){
   const a=idx[j-1],b=idx[j];if(b-a<4||b-a>40||!Number.isFinite(rsi[a])||!Number.isFinite(rsi[b]))continue;
   const p1=kind==='low'?low[a]:high[a],p2=kind==='low'?low[b]:high[b],dp=(p2-p1)/p1,dr=rsi[b]-rsi[a];
   const ordinary=kind==='low'?(dp<=-0.002&&dr>=3):(dp>=0.002&&dr<=-3);
   const hidden=kind==='low'?(dp>=0.002&&dr<=-3):(dp<=-0.002&&dr>=3);
   if(ordinary||hidden){
    const side=kind==='low'?'bull':'bear';
    const confirm=side==='bull'?bars.at(-1).close>bars[b].high:bars.at(-1).close<bars[b].low;
    const macdAgree=Number.isFinite(macd[a])&&Number.isFinite(macd[b])&&(side==='bull'?macd[b]>macd[a]:macd[b]<macd[a]);
    out.push({tf,side,macdAgree,kind:ordinary?'일반':'히든',confirmed:confirm,first:a,second:b,p1,p2,rsi1:rsi[a],rsi2:rsi[b],time:bars[b].time});break;
   }
  }
 }
 return out;
}
// User-defined support toolkit. All values use completed OHLCV bars only.
export function sma(xs,n){return xs.length>=n?mean(xs.slice(-n)):NaN;}
export function ichimoku(bars){
 const mid=(n,offset=0)=>{const a=bars.slice(Math.max(0,bars.length-offset-n),bars.length-offset);return a.length===n?(Math.max(...a.map(x=>x.high))+Math.min(...a.map(x=>x.low)))/2:NaN;};
 // Current displayed cloud uses 26-bar displaced spans, not today's projected cloud.
 const tenkan=mid(9),kijun=mid(26),spanA=(mid(9,26)+mid(26,26))/2,spanB=mid(52,26);
 return {tenkan,kijun,spanA,spanB,cloudTop:Math.max(spanA,spanB),cloudBottom:Math.min(spanA,spanB),cloudColor:spanA>=spanB?'양운':'음운'};
}
export function doubleBottom(bars,lookback=48,tolerance=.018){
 const window=bars.slice(-lookback), lows=window.map(x=>x.low),idx=pivots(lows,'low',2,2);
 for(let j=idx.length-1;j>0;j--){const a=idx[j-1],b=idx[j];if(b-a<4||b-a>32)continue;
  const diff=Math.abs(lows[a]-lows[b])/Math.max(lows[a],lows[b]);
  const neckline=Math.max(...window.slice(a,b+1).map(x=>x.high));
  if(diff<=tolerance)return {formed:true,confirmed:window.at(-1).close>neckline,neckline,low:Math.min(lows[a],lows[b])};
 }return {formed:false,confirmed:false,neckline:NaN,low:NaN};
}
export function supportEvidence(bars){
 const closes=bars.map(x=>x.close),price=closes.at(-1),ma20=sma(closes,20),ma60=sma(closes,60),ma180=sma(closes,180),cloud=ichimoku(bars),db=doubleBottom(bars);
 const levels=[['MA20',ma20],['MA60',ma60],['MA180',ma180],['구름 상단',cloud.cloudTop],['구름 하단',cloud.cloudBottom]];
 const defended=levels.filter(([_,v])=>Number.isFinite(v)&&price>=v*.995&&price<=v*1.035&&Math.min(...bars.slice(-4).map(x=>x.low))<=v*1.015).map(x=>x[0]);
 const pivotIds=pivots(bars.map(x=>x.low),'low');const higherLow=pivotIds.length>=2&&bars[pivotIds.at(-1)].low>bars[pivotIds.at(-2)].low*1.002;
 return {ma20,ma60,ma180,cloud,doubleBottom:db,higherLow,defended,hasSupport:defended.length>0||db.confirmed||higherLow};
}
// v7.5: A support *touch* is not a support *confirmation*.
// Examine the last completed 1h candles only; 15m/4h never substitute for this evidence.
export function confirmedHourlySupports(bars, breakoutLevel=NaN){
 const last=bars.at(-1), prior=bars.at(-2);
 if(!last||!prior)return {confirmed:false,confirmedLevels:[],watchedLevels:[],reason:'1시간 확정봉 부족'};
 const evidence=supportEvidence(bars);
 const levels=[['돌파 저항→지지',breakoutLevel],['MA20',evidence.ma20],['MA60',evidence.ma60],['MA180',evidence.ma180],['구름 상단',evidence.cloud.cloudTop],['구름 하단',evidence.cloud.cloudBottom]];
 const watchedLevels=[],confirmedLevels=[];
 // Support zone: max 1.2% touch tolerance; close must reclaim level within 0.3%.
 // A confirmed hourly bullish response is mandatory, not merely a lower wick.
 const recovery=last.close>last.open&&last.close>prior.close&&last.close>=last.low+(last.high-last.low)*.55;
 for(const [name,level] of levels){
  if(!Number.isFinite(level)||level<=0)continue;
  const touched=[prior,last].some(b=>b.low<=level*1.012&&b.high>=level*.988);
  if(!touched)continue;
  watchedLevels.push(name);
  if(recovery&&last.close>=level*.997&&last.low>=level*.975&&last.close>=prior.low)confirmedLevels.push(name);
 }
 return {confirmed:confirmedLevels.length>0,confirmedLevels,watchedLevels,recovery,reason:confirmedLevels.length?'1시간 확정봉 지지·종가 회복 확인':'1시간 이평·구름·돌파구간 지지 확정 대기'};
}
// Compare completed 15-minute bars in the current KST calendar day against
// the full preceding KST day. No rolling 24h ticker values or open candles.
export function dailyVolatilityExpansion(bars, threshold=1.3){
 const dayKey=b=>new Date(b.end-1+9*3600000).toISOString().slice(0,10);
 if(!bars?.length)return {verified:false,reason:'15분봉 없음'};
 const ordered=[...bars].sort((a,b)=>a.end-b.end), currentKey=dayKey(ordered.at(-1));
 const today=ordered.filter(b=>dayKey(b)===currentKey);
 const previousKey=new Date(Date.parse(currentKey+'T00:00:00Z')-86400000).toISOString().slice(0,10);
 const yesterday=ordered.filter(b=>dayKey(b)===previousKey);
 if(yesterday.length!==96||today.length<1||today.length>96)return {verified:false,reason:`전일 완성 96봉 필요 (전일 ${yesterday.length}봉 / 금일 ${today.length}봉)`};
 const range=bs=>{const open=bs[0].open;return open>0?(Math.max(...bs.map(b=>b.high))-Math.min(...bs.map(b=>b.low)))/open:NaN};
 const prevRange=range(yesterday),todayRange=range(today),ratio=prevRange>0?todayRange/prevRange:NaN;
 const elapsed=today.length, prevSame=yesterday.slice(0,elapsed);
 const todayTurnover=today.reduce((a,b)=>a+b.turnover,0),prevSameTurnover=prevSame.reduce((a,b)=>a+b.turnover,0);
 const turnoverRatio=prevSameTurnover>0?todayTurnover/prevSameTurnover:NaN;
 const returnPct=(today.at(-1).close/today[0].open-1)*100;
 const direction=returnPct>=2?'UP':returnPct<=-2?'DOWN':'NEUTRAL';
 return {verified:Number.isFinite(ratio)&&Number.isFinite(turnoverRatio),currentKey,previousKey,
  prevRangePct:prevRange*100,todayRangePct:todayRange*100,ratio,turnoverRatio,returnPct,direction,
  expanded:ratio>=threshold,liquidityConfirmed:turnoverRatio>=1.1,elapsedBars:elapsed,
  reason:'KST 전일 전체 96봉 대비 금일 마감된 15분봉 누적 고저폭 (장중 비교 편향 존재)'};
}
// Intraday KST +7% high-watermark discovery from COMPLETED 15m candles only.
// This is a discovery cohort, NOT a confirmed pullback or entry signal.
export function dailySevenPercentMover(bars,threshold=7){
 if(!bars?.length)return {verified:false,reason:'15분봉 없음'};
 const ordered=[...bars].sort((a,b)=>a.end-b.end);
 const dayKey=b=>new Date(b.end-1+9*3600000).toISOString().slice(0,10);
 const currentKey=dayKey(ordered.at(-1));
 const today=ordered.filter(b=>dayKey(b)===currentKey);
 if(!today.length||!(today[0].open>0))return {verified:false,reason:'금일 시가 데이터 없음'};
 // Do not mistake the first available intraday candle for the KST midnight open.
 const midnight=Date.parse(currentKey+'T00:00:00+09:00');
 const step=15*60000;
 if(today.length>96||today.some((b,i)=>b.end!==midnight+(i+1)*step))return {verified:false,qualified:false,currentKey,reason:'금일 자정 이후 15분봉 누락 또는 시간 불일치'};
 const open=today[0].open;
 const peakPct=(Math.max(...today.map(b=>b.high))/open-1)*100;
 const currentPct=(today.at(-1).close/open-1)*100;
 return {verified:true,currentKey,peakPct,currentPct,qualified:peakPct>=threshold,
  pullbackFromPeakPct:(1-today.at(-1).close/Math.max(...today.map(b=>b.high)))*100,
  reason:'KST 금일 확정 15분봉 고가 기준 +7% 최초 도달 후 당일 유지'};
}
function recentLowPivot(bars){const ids=pivots(bars.map(x=>x.low),'low');return ids.length?bars[ids.at(-1)].low:Math.min(...bars.slice(-16).map(x=>x.low));}
function safeN(n){return Number.isFinite(n)?n:0;}
export function analyzeSymbol(symbol,sets,context={}){
 const h=sets['1h'],q=sets['4h'],m=sets['15m'],n=sets['30m'];
 if(!h||h.length<180||!q||q.length<46||!m||m.length<70){return {symbol,tier:'U',score:0,entryState:'데이터 미검증',signal:'GRAY',status:'데이터 부족',reason:'확정봉 수 부족 (15분 70봉 / 1시간 180봉 / 4시간 46봉 필요)',divergences:[],safe:false,checkedAt:new Date().toISOString()};}
 const latestTime=Math.min(...[h.at(-1).end,q.at(-1).end,m.at(-1).end].filter(Number.isFinite));
 const hClose=h.map(b=>b.close),qClose=q.map(b=>b.close),mClose=m.map(b=>b.close);
 const last=h.at(-1),prev=h.at(-2),last15=m.at(-1),price=m.at(-1).close;
 const ema20=ema(hClose,20),ema60=ema(hClose,60),qema20=ema(qClose,20),qema40=ema(qClose,40),mema20=ema(mClose,20);
 const obv=obvSeries(h),obvDirection=obv.at(-1)>obv.at(-7)&&obv.at(-7)>=obv.at(-14);
 const prevVols=h.slice(-21,-1).map(b=>b.turnover),currentVol=safeN(last.turnover),avgVol=mean(prevVols),rvol=avgVol>0?currentVol/avgVol:0;
 const priorCorrections=h.slice(-6,-1).filter(x=>x.close<x.open).map(x=>x.turnover),downAvg=mean(priorCorrections);
 const pullbackVolContracted=priorCorrections.length>=2&&mean(priorCorrections)<mean(h.slice(-13,-6).map(x=>x.turnover))*.85;
 const turnup=last.close>last.open && last.close>prev.close && last.close>prev.high*0.9995;
 // For a pullback, a low overall RVOL is permissible ONLY if the completed bullish reversal candle
 // expands clearly versus the preceding corrective red candles. Never award volume confirmation for falling volume alone.
 const volRecovery=turnup && priorCorrections.length>=2 && currentVol>downAvg*1.25 && currentVol>=avgVol*.65;
 const volBreakout=turnup&&rvol>=1.2;
 const volumeCore=volRecovery||volBreakout;
 const hPiv=pivots(h.map(x=>x.low),'low');const higherLow=hPiv.length>=2&&h[hPiv.at(-1)].low>h[hPiv.at(-2)].low*1.001;
 const priceCore=price>ema20&&ema20>ema60&&qClose.at(-1)>qema20&&qema20>qema40;
 const nearSupport=price>=ema20*.989 && price<=ema20*1.05;
 const divergence=[...detectDivergences(m,'15m'),...detectDivergences(h,'1h'),...detectDivergences(q,'4h')];
 const bullDiv=divergence.some(x=>x.side==='bull'&&x.confirmed),bearDiv=divergence.some(x=>x.side==='bear'&&x.confirmed);
 const rsiH=rsiSeries(hClose),rsiRising=rsiH.at(-1)>rsiH.at(-4)&&rsiH.at(-1)>=47&&rsiH.at(-1)<=75;
 const support=Math.min(recentLowPivot(h),...h.slice(-5).map(x=>x.low));
 const stop=support*.997;
 const stopPct=(price-stop)/price;
 const resistance=Math.max(...h.slice(-35,-1).map(x=>x.high));
 const rewardPct=(resistance-price)/price;
 const rr=stopPct>0?rewardPct/stopPct:0;
 const riskValid=stopPct>=0.006&&stopPct<=0.05&&rr>=1.5;
 // 30-minute CLOSED candles provide a slower confirmation, not a replacement for the 15m trigger.
 // Missing 30m data cannot be silently treated as confirmation.
 const thirtyVerified=Array.isArray(n)&&n.length>=35;
 const nClose=thirtyVerified?n.map(b=>b.close):[];
 const nEma20=thirtyVerified?ema(nClose,20):NaN;
 const nLast=thirtyVerified?n.at(-1):null;
 const nPrev=thirtyVerified?n.at(-2):null;
 const thirtyBearish=thirtyVerified&&nLast.close<nEma20&&nLast.close<nPrev.close&&nLast.low<nPrev.low;
 const thirtySupportive=thirtyVerified&&nLast.close>=nEma20*.995&&nLast.close>=nPrev.low;
 const thirtyState=!thirtyVerified?'데이터 미검증':thirtyBearish?'하락 구조 경고':thirtySupportive?'지지·추세 확인':'중립·추가 확인';
 const prev15=m.at(-2);
 const meaningful15=last15.close>last15.open&&last15.close>mema20&&last15.close>prev15.close;
 const recent15=m.slice(-21,-1);
 const rvol15=mean(recent15.map(x=>x.turnover))>0?last15.turnover/mean(recent15.map(x=>x.turnover)):0;
 const correction15=m.slice(-7,-1).filter(x=>x.close<x.open);
 const fifteenVolRecovery=meaningful15&&correction15.length>=1&&last15.turnover>mean(correction15.map(x=>x.turnover))*1.15&&rvol15>=.8;
 const fifteenBreakout=meaningful15&&rvol15>=1.3;
 const fifteenVolumeCore=fifteenVolRecovery||fifteenBreakout;
 const last15Low=Math.min(...m.slice(-9,-1).map(x=>x.low));
 const fifteenStructure=price>last15Low&&price>mema20;
 const entryStop=Math.max(stop,last15Low*.997);
 const entryStopPct=(price-entryStop)/price;
 const entryRR=entryStopPct>0?rewardPct/entryStopPct:0;
 const entryRiskValid=entryStopPct>=.006&&entryStopPct<=.05&&entryRR>=1.5;
 const hardInvalidation=price<=stop||Boolean(context.marketWarning && !["NONE",""].includes(context.marketWarning));
 const risingStructure=last.close>=prev.close;
 const points={
  '가격 구조':(priceCore?16:0)+(higherLow?7:0)+(risingStructure?7:0),
  '거래량·가격':(volumeCore?12:0)+(pullbackVolContracted?5:0)+(rvol>=1?3:0),
  '독립 수급·지표':(obvDirection?10:0)+(rsiRising?5:0)+(bullDiv?(divergence.some(x=>x.side==='bull'&&x.confirmed&&x.macdAgree)?5:2):0),
  '지지·저항':(nearSupport?8:0)+(rewardPct>0.02?4:0)+(riskValid?3:0),
  '확정 트리거·위험':(turnup?9:0)+(meaningful15?3:0)+(riskValid?3:0)
 };
 const score=Math.min(100,Object.values(points).reduce((a,b)=>a+b,0));
 const independent=[priceCore,volumeCore,obvDirection,nearSupport&&higherLow].filter(Boolean).length;
 const warned=context.marketWarning && !['NONE','',null].includes(context.marketWarning);
 const hasFullVerification=priceCore&&volumeCore&&turnup&&meaningful15&&riskValid&&independent>=3&&!bearDiv&&!warned;
 // No A if any mandatory verification is absent, regardless of apparent numeric score.
 const tier=hasFullVerification&&score>=85?'A':(score>=60&&independent>=2&&stopPct>0&&Number.isFinite(stop)&&!warned?'B':'C');
 // Three INDEPENDENT discovery routes. A strict grade and a green entry light require
 // the strategy-specific trigger, volume, and risk checks; no 1h bullish trend prerequisite
 // for countertrend rebounds or early momentum. All indicators use closed candles.
 const impulseBase=h.at(-13)?.close||price;
 const impulseGain=(Math.max(...h.slice(-12).map(x=>x.high))-impulseBase)/impulseBase;
 const recentHigh15=Math.max(...m.slice(-13,-1).map(x=>x.high));
 const priorRange=m.slice(-25,-1);
 const rangeHigh=Math.max(...priorRange.map(x=>x.high));
 const rangeLow=Math.min(...priorRange.map(x=>x.low));
 const compression=(rangeHigh-rangeLow)/Math.max(eps,mean(priorRange.map(x=>x.close)))<=.09;
 const last15HigherLow=last15.low>=Math.min(...m.slice(-9,-1).map(x=>x.low))*.998;
 const fifteenTrigger=meaningful15&&fifteenStructure&&last15HigherLow;
 const downTrend=ema20<ema60||qClose.at(-1)<qema20;
 const baseLow=Math.min(...h.slice(-30,-5).map(x=>x.low));
 const defendedLow=Math.min(...h.slice(-5).map(x=>x.low))>=baseLow*.995;
 // v7.2: Completed 1h breakout -> retest -> support; 4h remains advisory only.
 const oneHourUptrend=last.close>ema20&&ema20>ema60&&ema20>ema(hClose.slice(0,-4),20);
 let breakoutLevel=NaN, breakoutIndex=-1, oneHourRetest=false, oneHourBreakoutVolume=false, oneHourCorrectionVolume=false, oneHourReentryVolume=false;
 for(let i=h.length-2;i>=Math.max(25,h.length-25);i--){
   const level=Math.max(...h.slice(i-24,i).map(b=>b.high));
   if(h[i].close>level*1.001&&h[i].turnover>mean(h.slice(i-20,i).map(b=>b.turnover))*1.1){
     breakoutLevel=level;breakoutIndex=i;oneHourBreakoutVolume=true;break;
   }
 }
 if(breakoutIndex>=0){
   const after=h.slice(breakoutIndex+1);
   // Require a recent, completed 1h retest and actual bullish defense; no stale historical touch.
   const recentAfter=after.slice(-6);
   const defended=recentAfter.some(b=>b.low<=breakoutLevel*1.015&&b.close>=breakoutLevel*.997&&b.close>=b.open);
   const corrective=after.filter(b=>b.close<b.open);
   const breakoutTurnover=h[breakoutIndex].turnover;
   oneHourCorrectionVolume=corrective.length>=1&&mean(corrective.map(b=>b.turnover))<=breakoutTurnover*.85;
   // Re-entry volume must recover from correction on a completed bullish 1h candle.
   // It need not exceed the breakout candle or 1h baseline during a normal retest.
   oneHourReentryVolume=corrective.length>=1&&last.close>=last.open&&
      last.turnover>=mean(corrective.map(b=>b.turnover))*1.15;
   oneHourRetest=defended&&last.close>=breakoutLevel&&
      Math.min(...after.map(b=>b.close))>=breakoutLevel*.992;
 }
 const hourlySupport=confirmedHourlySupports(h,breakoutLevel);
 const chartPatterns=analyzeChartPatterns(h);
 const primaryPattern=bestPattern(chartPatterns);
 const oneHourPullbackVolumeConfirmed=oneHourBreakoutVolume&&oneHourCorrectionVolume&&oneHourReentryVolume;
 const oneHourPullbackConfirmed=oneHourUptrend&&oneHourRetest&&hourlySupport.confirmed&&oneHourPullbackVolumeConfirmed;
 const oneHourLowDefended=defendedLow&&last.close>=Math.min(...h.slice(-6,-1).map(b=>b.low));
 const oneHourReboundStructure=oneHourLowDefended&&last.close>prev.high&&last.close>ema20;
 const oneHourReboundVolume=volumeCore|| (rvol>=1.0&&obvDirection);
 // Rebound-only: completed 4h bottom defense + seller exhaustion, without demanding a 4h uptrend.
 const fourHourBaseLow=Math.min(...q.slice(-18,-3).map(b=>b.low));
 const fourHourLowDefended=Math.min(...q.slice(-3).map(b=>b.low))>=fourHourBaseLow*.995;
 const fourHourRedRecent=q.slice(-4).filter(b=>b.close<b.open).map(b=>b.turnover);
 const fourHourRedEarlier=q.slice(-12,-4).filter(b=>b.close<b.open).map(b=>b.turnover);
 const fourHourSellExhausted=fourHourRedEarlier.length>=2 &&
   (fourHourRedRecent.length===0 || mean(fourHourRedRecent)<=mean(fourHourRedEarlier)*.85);
 const fourHourReboundConfirmed=fourHourLowDefended&&fourHourSellExhausted;
 const fourHourReference=qClose.at(-1)>=qema20?'4시간 추세 우호':'4시간 약세·저항 참고';
 // Momentum also requires a completed 1h breakout, rather than a 15m-only spike.
 const oneHourMomentumLevel=Math.max(...h.slice(-21,-1).map(b=>b.high));
 const oneHourMomentumConfirmed=last.close>oneHourMomentumLevel*1.001 &&
   last.turnover>mean(h.slice(-21,-1).map(b=>b.turnover))*1.2 && last.close>ema20;
 const decliningSellVolume=h.slice(-7,-1).filter(x=>x.close<x.open).length>=2&&pullbackVolContracted;
 const pullbackDiscovery=impulseGain>=.035&&nearSupport&&(pullbackVolContracted||fifteenStructure);
 const pullbackTrigger=pullbackDiscovery&&oneHourPullbackConfirmed&&fifteenTrigger&&fifteenVolumeCore;
 const reboundDiscovery=downTrend&&defendedLow&&(rsiRising||bullDiv||obvDirection||fifteenStructure);
 const reboundTrigger=reboundDiscovery&&oneHourReboundStructure&&oneHourReboundVolume&&fourHourReboundConfirmed&&fifteenTrigger&&fifteenVolumeCore;
 const momentumDiscovery=(compression||Math.abs(ema20-ema60)/price<.04)&&
   (rvol15>=1.15||rvol>=1.2||obvDirection)&&price>=mema20*.99;
 const momentumTrigger=momentumDiscovery&&oneHourMomentumConfirmed&&last15.close>recentHigh15&&
   fifteenTrigger&&rvol15>=1.3&&price>mema20;
 const strategies=[
  {name:impulseGain>=.07?'당일 강세 눌림목':'눌림목',discover:pullbackDiscovery,trigger:pullbackTrigger,
   missing:[!fifteenTrigger?'15분봉 재상승 확정 대기':null,!fifteenVolumeCore?'재상승 거래량 회복 대기':null,!oneHourPullbackConfirmed?'1시간 돌파·지지·거래량 흐름 확정 대기':null,!hourlySupport.confirmed?'1시간 이평·구름·돌파구간 지지 확정 대기':null].filter(Boolean)},
  {name:'기술적 반등',discover:reboundDiscovery,trigger:reboundTrigger,
   missing:[!fifteenTrigger?'15분봉 저점 방어·반전 대기':null,!fifteenVolumeCore?'반등 거래량 확인 대기':null,!oneHourReboundStructure?'1시간 저점 방어·구조 전환 대기':null,!oneHourReboundVolume?'1시간 거래량 회복 대기':null,!fourHourReboundConfirmed?'4시간 저점 방어·매도량 둔화 대기':null].filter(Boolean)},
  {name:'급등 초입',discover:momentumDiscovery,trigger:momentumTrigger,
   missing:[!oneHourMomentumConfirmed?'1시간봉 돌파·거래량 확정 대기':null,last15.close<=recentHigh15?'15분봉 박스 상단 돌파 대기':null,rvol15<1.3?'돌파 거래량 증가 대기':null].filter(Boolean)}
 ];
 const active=strategies.filter(x=>x.discover);
 const selected=active.find(x=>x.trigger)||active[0];
 const volatility=dailyVolatilityExpansion(m);
 const dailyMover=dailySevenPercentMover(m);
 const surge=surgePullback(m,dailyMover);
 const support15=supportEvidence(m),support1h=supportEvidence(h);
 const validatedSupport=support15.hasSupport||support1h.hasSupport; // discovery only; A-grade pullbacks use hourlySupport.confirmed
 const volGate=volatility.verified&&volatility.expanded&&volatility.liquidityConfirmed;
 const day7PullbackDiscovery=dailyMover.qualified&&pullbackDiscovery&&validatedSupport;
 const surgeDiscovery=surge.discovered&&validatedSupport;
 const surgeTrigger=surgeDiscovery&&surge.trigger&&oneHourPullbackConfirmed&&fifteenTrigger&&fifteenVolumeCore;
 const downVolDiscovery=volGate&&volatility.direction==='DOWN'&&reboundDiscovery;
 const day7PullbackTrigger=day7PullbackDiscovery&&pullbackTrigger;
 const downVolTrigger=downVolDiscovery&&reboundTrigger;
 // Specialized routes are separate from ordinary pullback/rebound discovery.
 strategies.unshift(
  {name:'급등·2차 상승 눌림목',discover:surgeDiscovery,trigger:surgeTrigger,missing:[!surge.trigger?surge.reason:null,!validatedSupport?'지지선 확인 대기':null,!fifteenVolumeCore?'15분 거래량 회복 대기':null,!oneHourPullbackConfirmed?'1시간 돌파·지지·거래량 흐름 확정 대기':null,!hourlySupport.confirmed?'1시간 이평·구름·돌파구간 지지 확정 대기':null].filter(Boolean)},
  {name:'금일 +7% 강세 눌림목',discover:day7PullbackDiscovery,trigger:day7PullbackTrigger,
   missing:[!validatedSupport?'이평·구름·저점 지지 대기':null,!fifteenTrigger?'15분봉 재상승 확정 대기':null,!fifteenVolumeCore?'15분 거래량 회복 대기':null,!oneHourPullbackConfirmed?'1시간 돌파·지지·거래량 흐름 확정 대기':null,!hourlySupport.confirmed?'1시간 이평·구름·돌파구간 지지 확정 대기':null].filter(Boolean)},
  {name:'변동성 확대 · 급락 후 반등',discover:downVolDiscovery,trigger:downVolTrigger,
   missing:[!defendedLow?'저점 재탈환·방어 대기':null,!fifteenTrigger?'15분봉 반전 확정 대기':null,!fifteenVolumeCore?'반등 거래량 확인 대기':null,!oneHourReboundStructure?'1시간 저점 방어·구조 전환 대기':null,!oneHourReboundVolume?'1시간 거래량 회복 대기':null,!fourHourReboundConfirmed?'4시간 저점 방어·매도량 둔화 대기':null].filter(Boolean)}
 );
 // Prefer the dedicated day-7 pullback / downside-volatility rebound routes when discovered.
 const specialized=strategies.slice(0,3).find(x=>x.discover);
 const chosen=specialized||selected;

 const momentumNotChasing=price<=recentHigh15*1.025 && entryRR>=1.8;
 const strategy=chosen?.name||'정밀 관찰';
 const triggerReady=Boolean(chosen?.trigger);
 // Recalculate the score using the existing precision factors, but do not force a
 // rising 1h/4h trend for reversal and momentum setups. Preserve the original score
 // as a diagnostic and award strategy confirmation for independent evidence.
 const strategyScore=Math.min(100,Math.round(
  (chosen?.discover?32:0)+(fifteenStructure?13:0)+(fifteenTrigger?12:0)+
  (fifteenVolumeCore?15:0)+(obvDirection?8:0)+(nearSupport||defendedLow?8:0)+
  (entryRiskValid?12:0)
 ));
 // Never show a high 'entry-ready' score when a mandatory gate fails.
 // 1h RVOL can be low during a valid pullback; require independent 15m recovery,
 // but for technical rebounds also require non-collapsing 1h participation.
 const isRebound=Boolean(chosen)&&/반등/.test(chosen.name);
 const isPullback=Boolean(chosen)&&/눌림목/.test(chosen.name);
 const reboundLiquidityWeak=isRebound&&!oneHourReboundVolume;
 const isMomentum=Boolean(chosen)&&chosen.name==='급등 초입';
 const strategyGateMissing=(isPullback&&!oneHourPullbackConfirmed)||(isRebound&&(!oneHourReboundStructure||!oneHourReboundVolume||!fourHourReboundConfirmed))||(isMomentum&&!oneHourMomentumConfirmed);
 const confirmationMissing=!fifteenVolumeCore||reboundLiquidityWeak||strategyGateMissing;
 const rawScore=chosen?strategyScore:score;
 const finalScore=confirmationMissing?Math.min(rawScore,79):rawScore;
 // Discovery history and current trade validity are independent.
 const day7History=Boolean(dailyMover.qualified);
 const day7PatternActive=day7History&&day7PullbackDiscovery;
 const day7Invalidated=day7History&&(hardInvalidation||price<=stop);
 const day7PatternState=!day7History?'해당 없음':day7Invalidated?'무효화':day7PatternActive?'눌림목 유효 후보':'눌림목 조건 미충족';
 const strictReady=triggerReady&&(chosen?.name==='급등 초입'?momentumNotChasing&&oneHourMomentumConfirmed:isPullback?oneHourPullbackConfirmed:isRebound?oneHourReboundStructure&&oneHourReboundVolume&&fourHourReboundConfirmed:validatedSupport)&&entryRiskValid&&!bearDiv&&!warned&&!hardInvalidation&&price<resistance&&!reboundLiquidityWeak&&!strategyGateMissing;
 const verifiedFactors=[fifteenStructure,fifteenVolumeCore,obvDirection,nearSupport||defendedLow].filter(Boolean).length;
 // Never label a setup entry-ready when the displayed independent evidence is absent.
 const gradeA=!day7Invalidated&&strictReady&&finalScore>=85&&verifiedFactors>=3&&fifteenVolumeCore;
 const gradeB=!day7Invalidated&&Boolean(chosen?.discover)&&finalScore>=60&&!warned&&!hardInvalidation&&verifiedFactors>=2;
 const finalTier=gradeA?'A':gradeB?'B':'C';
 const nearEntry=finalTier==='B'&&Boolean(chosen)&&(chosen?.name==='급등 초입'||validatedSupport)&&entryRiskValid&&!bearDiv&&
   chosen.missing.length===1&&fifteenStructure&&fifteenVolumeCore&&verifiedFactors>=3&&chosen.missing[0]!==undefined;
 const phase=gradeA?'진입 검토':nearEntry?'진입 임박':gradeB?'형성 중':'제외/보류';
 const signal=hardInvalidation||bearDiv?'RED':gradeA?'GREEN':gradeB?'YELLOW':'RED';
 const entryState=signal==='GREEN'?'진입 검토':signal==='YELLOW'?phase:'진입 제외';
 const signalReasons=[...(chosen?.missing||[])];
 if(day7Invalidated)signalReasons.push('금일 강세 이력은 유지하되 손절 기준 이탈로 진입 무효화');
 if(!entryRiskValid)signalReasons.push('진입 위치·손익비 부적합');
 if(!thirtyVerified)signalReasons.push('30분 확정봉 데이터 부족: 참고 정보 미검증');
 if(thirtyBearish)signalReasons.push('30분봉 하락 구조: 참고 경고');
 if(reboundLiquidityWeak)signalReasons.push('기술적 반등: 1시간 거래량 회복 미확인');
 if(isPullback&&!hourlySupport.confirmed)signalReasons.push('눌림목: 1시간 이평선·구름대·돌파구간 지지 확정봉 미확인');
 if(isPullback&&!oneHourPullbackConfirmed)signalReasons.push('눌림목: 1시간 상승 추세·돌파 후 지지 미확정 (A급 보류)');
 if(isRebound&&!fourHourReboundConfirmed)signalReasons.push('기술적 반등: 4시간 저점 방어·매도량 둔화 미확인 (A급 보류)');
 if(isMomentum&&!oneHourMomentumConfirmed)signalReasons.push('급등 초입: 1시간 돌파·거래량 미확인 (A급 보류)');
 if(isRebound&&!oneHourReboundStructure)signalReasons.push('기술적 반등: 1시간 저점 방어·구조 전환 미확정 (A급 보류)');
 if(!fifteenVolumeCore)signalReasons.push('15분 반등 거래량 미확인: A급 보류');
 if(chosen?.name!=='급등 초입'&&!validatedSupport)signalReasons.push('이평선·구름대·저점 구조 지지 미확인');
 if(chosen?.name==='급등 초입'&&!momentumNotChasing)signalReasons.push('돌파 추격/저항 여유 부족: 눌림·재지지 대기');
 if(bearDiv)signalReasons.push('하락 다이버전스 경고');
 if(warned)signalReasons.push('거래소 경고 종목');
 if(!chosen)signalReasons.push('세 전략의 발견 조건 미충족');
 const reasons=[...(chosen?.discover?[`${strategy} 패턴 후보`]:['전략별 패턴 근거 부족']),...signalReasons];
 const entryReady=signal==='GREEN';
 const validity=`15분 종가 ${price.toLocaleString('ko-KR')}원 · 지지 이탈 참고 ${safeN(stop).toFixed(3)}원`;
 return {chartPatterns,primaryPattern,hourlySupport,oneHourBreakoutVolume,oneHourCorrectionVolume,oneHourReentryVolume,oneHourPullbackVolumeConfirmed,fourHourReboundConfirmed,fourHourLowDefended,fourHourSellExhausted,oneHourMomentumConfirmed,oneHourUptrend,oneHourRetest,oneHourPullbackConfirmed,breakoutLevel,oneHourReboundStructure,oneHourReboundVolume,fourHourReference,thirtyState,thirtyVerified,thirtyBearish,thirtySupportive,reboundLiquidityWeak,rawScore,surge,day7History,day7PatternActive,day7PatternState,day7Invalidated,volatility,dailyMover,support15,support1h,validatedSupport,momentumNotChasing,symbol,tier:finalTier,score:finalScore,originalScore:score,phase,strategy,entryReady,entryState,signal,signalReasons,verifiedFactors,entryStop,entryRR,rvol15,fifteenVolumeCore,fifteenStructure,points,price,stop,resistance,rvol,volRecovery,volBreakout,volumeCore,priceCore,independent,turnup,riskValid,rr,stopPct,rewardPct,obvDirection,divergences:divergence,reason:reasons.length?reasons.join(' / '):'핵심 가격구조·거래량·확정 트리거 통과',validity,marketWarning:context.marketWarning||'NONE',safe:gradeA,checkedAt:new Date().toISOString(),candleEnd:h.at(-1).end};
}
export function tierDescription(tier){return tier==='A'?'A급 · 진입 검토':tier==='B'?'B급 · 관찰':tier==='U'?'U급 · 데이터 미검증':'C급 · 제외/보류';}
