import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {parseTradeRows} from './server/trade-api-v83.mjs';
import {gapTape as old} from './server/repair-v86.mjs';
import {gapTape as next} from './server/repair-v87.mjs';
const [tradePath,gapPath]=process.argv.slice(2);if(!tradePath||!gapPath)throw Error('Usage: node replay-v86-to-v87.mjs trade-diagnostics.json gap-diagnostics.json');
const trades=JSON.parse(await readFile(tradePath,'utf8')),gaps=JSON.parse(await readFile(gapPath,'utf8'));
const by=new Map(gaps.markets.map(x=>[x.symbol,x.gapTape]));
const summary={scope:'first page only; no additional API calls; no verified no-trade or candle recovery',samples:0,rows:0,idRepeats:0,identicalRows:0,before:{},after:{},markets:[]};
for(const s of trades.samples){const g=by.get(s.market);if(!g||s.cursor!==null||s.status!==200)continue;const rows=parseTradeRows(s.raw),api=async()=>rows;
 const a=await old(api,s.market,g,g.end,1),b=await next(api,s.market,g,g.end,1);
 summary.samples++;summary.rows+=rows.length;summary.idRepeats+=b.idRepeats;summary.identicalRows+=b.identicalRows;summary.before[a.status]=(summary.before[a.status]||0)+1;summary.after[b.status]=(summary.after[b.status]||0)+1;summary.markets.push({market:s.market,before:a.status,after:b.status,rows:rows.length,idRepeats:b.idRepeats,identicalRows:b.identicalRows,inside:b.inside});assert.equal(b.observationOnly,true);
}
console.log(JSON.stringify(summary,null,2));
