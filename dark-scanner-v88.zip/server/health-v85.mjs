import {units,boundary,kstString,inspectBars} from '../js/data-health.mjs';
import {closedBars} from '../js/api.mjs';
import {aggregateExact,maintenance} from './recovery.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import {determineUniverse} from '../js/universe.mjs';
import {makeApi,slotOf,isStale,alertCandidates} from './scan.mjs';
const DAY=86400000, fields=['open','high','low','close','volume','turnover'];
const approx=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-9*Math.max(Math.abs(a),Math.abs(b),1e-12);
const same=(a,b)=>fields.every(k=>approx(a[k],b[k]));
const known=(t,u)=>maintenance.some(m=>t>=m.start&&t+u*60000<=m.end);
const min={'15m':70,'30m':35,'1h':180,'4h':46};
const sorted=m=>[...m.values()].sort((a,b)=>a.time-b.time);
const safeBars=(bars,u,now)=>{if(bars.length)inspectBars(bars,u,now);return bars;};
function rawBars(raw,market,u,to,count,now){
 if(!Array.isArray(raw)||raw.length>count)throw Error('응답 개수/형식 오류');
 for(const r of raw){if((r.market!==undefined&&r.market!==market)||(r.unit!==undefined&&Number(r.unit)!==u)||['opening_price','trade_price','high_price','low_price','candle_acc_trade_volume','candle_acc_trade_price'].some(k=>r[k]==null||r[k]===''||!Number.isFinite(Number(r[k])))||!Number.isFinite(Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z'))||Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z')>=to)throw Error('응답 필드/시각 오류');}
 const bars=closedBars(raw,u,now);if(bars.length!==raw.length)throw Error('미확정/형식 오류');return safeBars(bars,u,now);
}
function missing(bars,u,now){const step=u*60000,end=boundary(now,u);if(!bars.length)return [];let gaps=[];for(let i=1;i<=bars.length;i++){let a=bars[i-1].end,b=i===bars.length?end:bars[i].time;if(b-a>2000*step){gaps.push({time:a,end:b,large:true});continue;}for(let t=a;t<b;t+=step)gaps.push({time:t,end:t+step});}return gaps;}
function recentCount(bars,u,now){const end=boundary(now,u);return bars.filter(b=>b.time>=end-DAY&&b.end<=end).length;}
function tail(bars){let n=bars.length?1:0;for(let i=bars.length-1;i>0&&bars[i].time===bars[i-1].end;i--)n++;return n;}
// Positive-volume parent and all available child bars must reconcile in OHLCV AND turnover.
// This corroborates a no-trade interval; it is not independent exchange trade tape proof.
export function corroborateNoTrade(gap,tf,sets){const u=units[tf];if(u===240||gap.large)return null;
 for(const [parent,pu] of Object.entries(units)){
  if(pu<=u||pu%u)continue;const start=boundary(gap.time,pu),p=sets[parent]?.find(b=>b.time===start);if(!p)continue;if(p.end!==start+pu*60000||gap.end>p.end||p.volume<=0||p.turnover<=0)return null;
  const bs=(sets[tf]||[]).filter(b=>b.time>=start&&b.end<=p.end);if(!bs.length||bs.some(b=>b.volume<=0||b.turnover<=0))return null;
  const a={open:bs[0].open,close:bs.at(-1).close,high:Math.max(...bs.map(b=>b.high)),low:Math.min(...bs.map(b=>b.low)),volume:bs.reduce((s,b)=>s+b.volume,0),turnover:bs.reduce((s,b)=>s+b.turnover,0)};
  // Prefer the smallest available complete parent. A mismatch cannot be
  // overridden by a larger candle whose aggregate might conceal discrepancies.
  return same(a,p)?parent:null;
 }return null;
}
export function assessFrames(sets,now,meta={},evidence=()=>null){
 const health={},verifiedSets={};for(const [tf,u] of Object.entries(units)){const bars=sets[tf]||[];try{if(!meta[tf]?.error&&meta[tf]?.sourceFresh!==false&&bars.length){safeBars(bars,u,now);verifiedSets[tf]=bars;}}catch{}}
 for(const [tf,u] of Object.entries(units)){
  const bars=sets[tf]||[],end=boundary(now,u);let error=meta[tf]?.error||null;
  try{safeBars(bars,u,now);}catch(e){error=e.message;}
  const gaps=error?[]:missing(bars,u,now).map(g=>{
   // Never classify a maintenance interval as ordinary no-trade evidence.
   const parent=!g.large&&!known(g.time,u)&&verifiedSets[tf]?(corroborateNoTrade(g,tf,verifiedSets)||evidence(g,tf)):null;
   return {...g,kind:g.large?'UNKNOWN':known(g.time,u)?'MAINTENANCE':parent?'NO_TRADE_SUPPORTED':'UNKNOWN',parent};
  });
  const recentGaps=gaps.filter(g=>g.end>end-DAY),latest=bars.at(-1)?.end===end;
  const recentComplete=latest&&recentCount(bars,u,now)===DAY/(u*60000)&&!recentGaps.length;
  const recentSupported=recentGaps.filter(g=>g.kind==='NO_TRADE_SUPPORTED').length;
  const recentReconciled=latest&&bars[0]?.time<=end-DAY&&recentGaps.every(g=>g.kind==='NO_TRADE_SUPPORTED')&&recentCount(bars,u,now)+recentSupported===DAY/(u*60000);
  const oldUnknown=gaps.filter(g=>g.end<=end-DAY&&g.kind==='UNKNOWN').length;
  const count=bars.length,usable=!error&&latest&&count>=min[tf];
  health[tf]={tf,count,latest,expected:end,contiguousRecent:tail(bars),recentComplete,recentReconciled,recentSupported,recentGaps:recentGaps.length,oldUnknown,gaps,error,usable,recovered:meta[tf]?.recovered||0,sourceFresh:meta[tf]?.sourceFresh!==false,requests:meta[tf]?.requests||0,notes:meta[tf]?.notes||[]};
 }
 return health;
}
export function evaluateV81(symbol,sets,now,meta={},context={},analyze=analyzeSymbol){
 const health=assessFrames(sets,now,meta,context.gapEvidence),core=['15m','1h','4h'];const fatal=core.filter(tf=>!health[tf].usable);
 const base={symbol,dataHealth:Object.values(health),candleEnds:Object.fromEntries(Object.entries(sets).filter(([,v])=>v.length).map(([k,v])=>[k,v.at(-1).end]))};
 if(fatal.length)return {...base,tier:'U',score:0,signal:'GRAY',entryState:'데이터 미검증',entryReady:false,safe:false,dataStatus:'INVALID',reason:'핵심 봉 부족/오류: '+fatal.map(tf=>tf+' '+(health[tf].error||'최신성/봉 수 부족')).join(', ')};
 // Original engine uses 4h in scoring and divergence even outside rebounds. Do not silently remove it.
 const input={...sets};const h30=health['30m'];if(!h30.usable||!(h30.recentComplete||(h30.recentReconciled&&h30.contiguousRecent>=35))||h30.oldUnknown||!h30.sourceFresh)delete input['30m'];
 const r=analyze(symbol,input,context);const blocks=[];
 for(const tf of core){const h=health[tf];if(!h.recentComplete&&!h.recentReconciled)blocks.push(tf+' 최근 24시간 미확인/점검 공백 또는 데이터 부족');if(h.oldUnknown)blocks.push(tf+' 과거 원인 미확인 공백');if(!h.sourceFresh)blocks.push(tf+' 이번 API 미검증');}
 // Structure/volume lookback is 49 hourly bars; four-hour rebound lookback is 18 bars.
 // A known gap inside these price structure windows still blocks entry.
 // Require real contiguous candles for the unchanged engine's entry/structure windows.
 if(health['15m'].contiguousRecent<25)blocks.push('15분 진입·거래량 25봉 연속성 부족');
 if(sets['15m'].slice(-25).some(b=>b.volume<=0||b.turnover<=0))blocks.push('15분 진입 구간 무거래/유동성 부족');
 if(health['1h'].contiguousRecent<49)blocks.push('1시간 구조·거래량 49봉 연속성 부족');
 if(/반등/.test(r.strategy||'')&&health['4h'].contiguousRecent<18)blocks.push('반등 4시간 저점/거래량 18봉 연속성 부족');
 if(/변동성 확대/.test(r.strategy||'')){const m=sets['15m'];const day=boundary(m.at(-1).end-1,1440);const first=day-DAY;const last=m.at(-1).end;const selected=m.filter(b=>b.time>=first);if(selected.length!==(last-first)/900000||selected.some((b,i)=>b.time!==first+i*900000))blocks.push('전일·금일 변동성 비교 시간 공백');}
 const warnings=[];if(input['30m']&&h30.recentSupported)warnings.push('30분 과거 미체결 추정 공백: 실제 체결 봉 기준');if(!input['30m'])warnings.push('30분 참고 미검증(독립 차단 없음)');
 for(const tf of core){const h=health[tf];if(h.gaps.length&&!h.oldUnknown&&(h.recentComplete||h.recentReconciled))warnings.push(tf+' 점검/미체결 추정 공백: 실제 체결 봉 기준 지표(시간 간격 변화 가능)');
 if(h.recentSupported)warnings.push(tf+' 최근 24시간 미체결 추정 '+h.recentSupported+'개 · 상위 봉 교차검증, 합성 봉 없음');}
 if(r.tier==='U')return {...r,...base,dataStatus:'INVALID',dataWarnings:warnings};
 if(blocks.length)return {...r,...base,diagnosticTier:r.tier,diagnosticScore:r.score,tier:r.tier==='A'?'B':r.tier,score:r.tier==='A'?Math.min(79,r.score):r.score,phase:r.tier==='C'?'제외/보류':'형성 중',signal:r.signal==='RED'?'RED':r.tier==='C'?'RED':'YELLOW',entryReady:false,safe:false,entryState:'부분 검증 · 진입 보류',entryStop:null,entryRR:null,dataStatus:'PARTIAL',dataWarnings:[...warnings,...blocks],reason:[r.reason,...blocks].join(' / '),signalReasons:[...(r.signalReasons||[]),...blocks]};
 return {...r,...base,dataStatus:warnings.length?'QUALIFIED':Object.values(health).some(h=>h.recovered)?'RECOVERED':'OK',dataWarnings:warnings};
}
