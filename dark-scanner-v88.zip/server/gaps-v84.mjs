import {units,boundary} from '../js/data-health.mjs';
const fields=['open','close','high','low','volume','turnover'];
const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-9*Math.max(Math.abs(a),Math.abs(b),1e-12);
const matches=(p,bs)=>p.volume>0&&p.turnover>0&&bs.length>0&&bs.every(b=>b.volume>0&&b.turnover>0)&&fields.every(k=>near(p[k],k==='open'?bs[0].open:k==='close'?bs.at(-1).close:k==='high'?Math.max(...bs.map(b=>b.high)):k==='low'?Math.min(...bs.map(b=>b.low)):bs.reduce((s,b)=>s+b[k],0)));
export function diagnoseGaps(health,archive,now,days=[]){
 const maps=Object.fromEntries(Object.entries(units).map(([tf,u])=>[tf,new Map((archive[tf]||[]).map(b=>[b.time,b]))]));
 const out=[];
 for(const h of health||[])for(const g of h.gaps||[]){if(g.kind!=='UNKNOWN')continue;
  const u=units[h.tf],parents=Object.keys(units).filter(p=>units[p]>u&&units[p]%u===0);let reason='PARENT_NOT_STORED',evidence=null;
  if(g.large)reason='LARGE_GAP';else if(!parents.length)reason='NO_PARENT_CONFIGURED';else if(parents.every(p=>boundary(g.time,units[p])+units[p]*60000>now))reason='WAIT_PARENT_CLOSE';
  if(!g.large)for(const p of parents){const start=boundary(g.time,units[p]),end=start+units[p]*60000,b=maps[p].get(start);if(!b||end>now)continue;
   const children=(archive[h.tf]||[]).filter(x=>x.time>=start&&x.end<=end);const covered=(archive[h.tf]||[])[0]?.time<=start;
   reason=!covered?'CHILD_HISTORY_INSUFFICIENT':!children.length?'NO_CHILD_EVIDENCE':matches(b,children)?'ARCHIVE_RECONCILED_HINT':'PARENT_MISMATCH';evidence={parent:p,start,end,parentVolume:b.volume,childVolume:children.reduce((s,x)=>s+x.volume,0),parentTurnover:b.turnover,childTurnover:children.reduce((s,x)=>s+x.turnover,0)};break;
  }
  // Daily data is an independent diagnostic only, never promotes entry or invents a candle.
  const day=days.find(b=>b.time<=g.time&&b.end>=g.end);let daily=null;
  if(day){const bs=(archive[h.tf]||[]),children=bs.filter(b=>b.time>=day.time&&b.end<=day.end);daily={start:day.time,end:day.end,status:!bs.length||bs[0].time>day.time||bs.at(-1).end<day.end?'CHILD_HISTORY_INSUFFICIENT':matches(day,children)?'AGGREGATE_MATCH_HINT':'AGGREGATE_NOT_MATCHED'};}
  out.push({tf:h.tf,time:g.time,end:g.end,reason,evidence,daily,recent:g.end>h.expected-86400000});
 }return out;
}
const read=(r)=>{const time=Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z');const x={time,open:Number(r.opening_price),close:Number(r.trade_price),high:Number(r.high_price),low:Number(r.low_price),volume:Number(r.candle_acc_trade_volume),turnover:Number(r.candle_acc_trade_price)};if(!Number.isFinite(time)||Object.values(x).some(v=>!Number.isFinite(v))||['opening_price','trade_price','high_price','low_price','candle_acc_trade_volume','candle_acc_trade_price'].some(k=>r[k]==null||r[k]==='')||x.low<=0||x.low>Math.min(x.open,x.close)||x.high<Math.max(x.open,x.close)||x.volume<0||x.turnover<0)throw Error('캔들 필드 오류');return x;};
export async function currentFrame(api,market,tf,now){const u=units[tf],start=now();try{const rows=await api('v1/candles/minutes/'+u,{market,count:1}),at=now();if(!Array.isArray(rows)||rows.length>1)throw Error('응답 형식 오류');if(!rows.length)return {status:'EMPTY',requestedAt:start,observedAt:at};const r=rows[0];if(r.market!==market||Number(r.unit)!==u)throw Error('종목/시간대 불일치');const b=read(r);if(boundary(b.time,u)!==b.time||b.time>at)throw Error('봉 시각 오류');const end=b.time+u*60000;const status=boundary(at,u)===b.time?'PROVISIONAL':end<=at?'LAST_CLOSED_ONLY':'TIMING_UNCERTAIN';return {status,requestedAt:start,observedAt:at,sourceTimestamp:r.timestamp??null,bar:{...b,end},observationOnly:true};}catch(e){return {status:'ERROR',reason:e.message,requestedAt:start,observedAt:now()};}}
export async function dailyFrames(api,market,now){const rows=await api('v1/candles/days',{market,count:40});if(!Array.isArray(rows)||rows.length>40)throw Error('일봉 응답 형식 오류');const out=[];for(const r of rows){if(r.market!==market)throw Error('일봉 종목 불일치');const b=read(r);b.end=b.time+86400000;if(b.end<=now)out.push(b);}return out.sort((a,b)=>a.time-b.time);}
