// Only complete tape reconciled against the actual closed candle is reported.
const near=(a,b)=>Math.abs(a-b)<=Math.max(Math.abs(a),Math.abs(b),1e-12)*1e-7;
export function candleFlow(bars){
 const b=bars?.at(-1);if(!b)return null;
 const range=b.high-b.low,body=Math.abs(b.close-b.open),lower=Math.min(b.open,b.close)-b.low,upper=b.high-Math.max(b.open,b.close);
 const contiguous=bars.length>=21&&bars.slice(-21).every((x,i,a)=>!i||x.time===a[i-1].end);
 const sample=bars.slice(-20),prev=bars.slice(-21,-1),avg=prev.reduce((s,x)=>s+x.turnover,0)/Math.max(1,prev.length);
 const total=sample.reduce((s,x)=>s+x.volume,0),cmf=sample.reduce((s,x)=>s+(x.high>x.low?(2*x.close-x.high-x.low)/(x.high-x.low):0)*x.volume,0);
 const obvChange=sample.slice(1).reduce((s,x,i)=>s+Math.sign(x.close-sample[i].close)*x.volume,0);
 return {lowerWickBull:range>0&&b.close>b.open&&lower>=body*1.5&&lower/range>=.4&&upper/range<=.25,upperWickBull:range>0&&b.close>b.open&&upper/range>=.4,relativeTurnover:contiguous&&avg>0?b.turnover/avg:null,obvChange:contiguous?obvChange:null,cmf20:contiguous&&total>0?cmf/total:null,indicatorBasis:contiguous?'20개 실제 연속 확정봉':'연속성 부족'};
}
const positive=x=>(typeof x==='number'||typeof x==='string'&&x.trim()!=='')&&Number.isFinite(Number(x))&&Number(x)>0;
export function normalizeTick(t,market){
 if(!t||typeof t!=='object')throw Error('체결 객체 오류');
 const id=t.sequential_id;
 if(!(typeof id==='string'&&/^\d+$/.test(id)||typeof id==='number'&&Number.isSafeInteger(id)&&id>=0))throw Error('체결 ID 누락/정밀도 오류');
 if(t.market!==market)throw Error('체결 종목 불일치');
 if(!positive(t.timestamp)||!Number.isSafeInteger(Number(t.timestamp)))throw Error('체결 시각 오류');
 if(!positive(t.trade_price))throw Error('체결 가격 오류');
 if(!positive(t.trade_volume))throw Error('체결 수량 오류');
 if(!['BID','ASK'].includes(t.ask_bid))throw Error('체결 매수/매도 구분 오류');
 return {id:String(id),ts:Number(t.timestamp),p:Number(t.trade_price),q:Number(t.trade_volume),side:t.ask_bid};
}
export function reconcileTape(bars,ticks,market){
 const seen=new Map(),valid=[];let duplicates=0;
 for(const t of ticks){let v;try{v=normalizeTick(t,market);}catch(e){return {status:'UNVERIFIED',reason:e.message};}if(seen.has(v.id))duplicates++;seen.set(v.id,true);valid.push(v);}
 // Preserve multiplicity within a response, even for identical rows. Candle totals arbitrate.
 const rows=bars.map(b=>{const tape=valid.filter(t=>t.ts>=b.time&&t.ts<b.end);let buy=0,sell=0,bv=0,sv=0;for(const t of tape){if(t.side==='BID'){buy+=t.p*t.q;bv+=t.q;}else{sell+=t.p*t.q;sv+=t.q;}}
  const complete=tape.length>0&&near(bv+sv,b.volume)&&near(buy+sell,b.turnover)&&near(Math.min(...tape.map(t=>t.p)),b.low)&&near(Math.max(...tape.map(t=>t.p)),b.high);
  return complete?{end:b.end,complete,buyTurnover:buy,sellTurnover:sell,buyShare:buy/(buy+sell),turnoverStrength:sell>0?buy/sell*100:null,deltaVolume:bv-sv,trades:tape.length}:{end:b.end,complete:false,trades:tape.length,observedVolume:bv+sv,expectedVolume:b.volume,observedTurnover:buy+sell,expectedTurnover:b.turnover};});
 const last=rows.at(-1);if(!last?.complete)return {status:'UNVERIFIED',reason:'15분봉 거래량·거래대금·고저가 미일치 / 체결 범위 부족',rows,duplicates};
 let cvd=null;if(rows.length===4&&rows.every((r,i)=>r.complete&&(!i||r.end-rows[i-1].end===900000))){let v=0;cvd=rows.map(r=>v+=r.deltaVolume);}
 return {status:'VERIFIED',...last,cvd1h:cvd,rows,duplicates};
}
export async function fetchFlow(api,market,bars,guard,maxPages=12){
 const target=bars.slice(-4),ticks=[];let cursor,pages=0,stopReason='페이지 제한';const cursors=new Set();let previousIds=new Set();
 try{for(;pages<maxPages;){guard();const rows=await api('v1/trades/ticks',{market,count:500,...(cursor?{cursor}:{})});pages++;if(!Array.isArray(rows)||rows.length>500)throw Error('체결 응답 형식');if(!rows.length){stopReason='빈 페이지';break;}
  for(const t of rows)normalizeTick(t,market);if(pages>1&&rows.some(t=>previousIds.has(String(t.sequential_id)))){stopReason='페이지 간 체결 ID 중첩 · 중복 여부 불확실';break;}for(const t of rows)previousIds.add(String(t.sequential_id));ticks.push(...rows);const r=reconcileTape(target,ticks,market);
  if(r.cvd1h){stopReason='4개 확정봉 일치';break;}
  if(rows.length<500){stopReason='마지막 페이지';break;}
  const next=normalizeTick(rows.at(-1),market).id;if(cursors.has(next)){stopReason='커서 반복';break;}cursors.add(next);cursor=next;
 }
 return {...reconcileTape(target,ticks,market),pages,stopReason,receivedTicks:ticks.length};}catch(e){
  // A budget stop preserves only already reconciled complete candles; malformed data never does.
  if(e.message==='선택 작업 시간 제한'){return {...reconcileTape(target,ticks,market),pages,stopReason:e.message,receivedTicks:ticks.length};}
  return {status:'UNVERIFIED',reason:e.message,pages,receivedTicks:ticks.length};}
}
export function flowInterpretation(c,tape,prev){if(tape.status!=='VERIFIED')return '체결 미확인';if(c?.upperWickBull)return '고점 매도 압력 주의';if(c?.lowerWickBull&&tape.buyShare<.5)return '매도 물량 흡수 가능성(추정)';if(tape.buyShare>.6&&c?.relativeTurnover>=1.2)return '매수 주도 거래대금 확대(추정)';if(c?.upperWickBull)return '고점 매도 압력 주의';return '뚜렷한 체결 근거 부족';}
