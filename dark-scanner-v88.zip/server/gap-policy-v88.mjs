import {units} from '../js/data-health.mjs';
import {requestClosed,gapTape} from './repair-v87.mjs';
export const keyOf=(tf,time)=>`${tf}|${time}`;
export function latestGap(r){const h=r.dataHealth?.find(h=>h.tf==='15m');return h&&!h.latest&&!h.error&&h.sourceFresh?h.gaps.find(g=>g.end===h.expected&&!g.large&&g.end-g.time===900000):null;}
export function gapClass(r,h,g,archive={},evidence={}){
 const early=evidence[keyOf(h.tf,g.time)],late=(r.gapTape?.tf===h.tf&&r.gapTape.time===g.time)?r.gapTape:null;const tape=early||late;
 const t=r.initialTicker?.tradeAt;
 const child=Object.entries(units).some(([tf,u])=>u<units[h.tf]&&(r.dataHealth||[]).some(x=>x.tf===tf&&x.sourceFresh&&!x.error)&&(archive[tf]||[]).some(b=>b.time>=g.time&&b.end<=g.end&&b.volume>0&&b.turnover>0));
 if(h.error||!h.sourceFresh)return 'UNKNOWN';
 if((Number.isFinite(t)&&t>=g.time&&t<g.end)||[early,late].some(x=>x?.status==='TRADES_PRESENT'||x?.lowerPositive)||child)return 'TRADE_PRESENT';
 if(g.kind==='MAINTENANCE')return 'MAINTENANCE';
 if(g.kind==='NO_TRADE_SUPPORTED'||tape?.crossChecked===true)return 'NO_TRADE_SUPPORTED';
 if(['NO_TRADE_BRACKETED_HINT','LAST_TRADE_BEFORE_GAP_HINT'].includes(tape?.status))return 'NO_TRADE_HINT';
 return 'UNKNOWN';
}
// Single-page bracketing plus independent time-bounded 1m data. Stale last trade,
// empty lower response, pagination or conflicting positive evidence are not proof.
export async function checkLatest({api,market,g,slot,now,r}){
 const tape={tf:'15m',time:g.time,end:g.end,...await gapTape(api,market,g,slot,1)};
 if(tape.status!=='NO_TRADE_BRACKETED_HINT'||tape.pages!==1||tape.newest>now()||r.initialTicker?.tradeAt>=g.time&&r.initialTicker.tradeAt<g.end)return tape;
 try{const lower=await requestClosed(api,market,1,g.end,15,slot);tape.lowerPositive=lower.some(b=>b.time>=g.time&&b.end<=g.end&&(b.volume>0||b.turnover>0));
 tape.crossChecked=!tape.lowerPositive&&lower.length>0&&lower.some(b=>b.volume>0&&b.turnover>0&&b.end>tape.oldest)&&lower.every(b=>b.end<=g.time);tape.lowerBars=lower.length;
 }catch(e){tape.lowerError=e.message;}return tape;
}
export function summarizePolicy(r,archive={},evidence={}){
 const counts={NO_TRADE_SUPPORTED:0,NO_TRADE_HINT:0,TRADE_PRESENT:0,UNKNOWN:0,MAINTENANCE:0};let latest='NO_LATEST_DATA';const h15=r.dataHealth?.find(h=>h.tf==='15m');if(h15?.latest&&h15.sourceFresh&&!h15.error)latest='AVAILABLE';
 for(const h of r.dataHealth||[])for(const g of h.gaps||[]){const c=gapClass(r,h,g,archive,evidence);counts[c]++;if(h.tf==='15m'&&g.end===h.expected&&!g.large)latest=c;}
 return {latest15m:latest,counts,entryExcluded:latest!=='AVAILABLE',classificationOnly:true};
}
