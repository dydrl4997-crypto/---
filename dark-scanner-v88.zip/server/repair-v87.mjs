export {mergeChecked,requestClosed,targetPriority,pickTargets,targetedRepair,repairParent} from './repair-v86.mjs';
import {normalizeTick} from './flow-v84.mjs';
// Observations only. Do not assume IDs identify individual trades, do not deduplicate
// identical rows, and never turn absence of a trade into a synthetic candle.
export async function gapTape(api,market,g,slot,maxPages=3){
 let cursor,prev=Infinity,pages=0,newest=null,oldest=null,inside=0,receivedRows=0,idRepeats=0,identicalRows=0;
 const ids=new Map(),fingerprints=new Set(),cursors=new Set();
 const result=(status,reason)=>({status,...(reason?{reason}:{}),pages,newest,oldest,inside,receivedRows,idRepeats,identicalRows,observationOnly:true});
 try{
  for(;pages<maxPages;){
   const rows=await api('v1/trades/ticks',{market,count:500,...(cursor?{cursor}:{})});pages++;
   if(!Array.isArray(rows)||rows.length>500)throw Error('체결 응답 형식');
   if(!rows.length)break;
   const page=rows.map(row=>normalizeTick(row,market));
   // A cursor based on a non-unique ID can omit or repeat trades at a boundary.
   // Reject overlapping IDs or timestamps across pages; no speculative stitching.
   if(pages>1&&(page[0].ts>=prev||page.some(t=>ids.has(t.id))))return result('UNVERIFIED','페이지 경계 중첩/커서 모호');
   for(const t of page){
    if(t.ts>prev)throw Error('체결 시간 역순 오류');
    if(ids.has(t.id)&&ids.get(t.id)!==t.ts)throw Error('동일 체결 ID의 시각 불일치');
    if(ids.has(t.id))idRepeats++;
    ids.set(t.id,t.ts);
    const key=JSON.stringify([t.id,t.ts,t.p,t.q,t.side]);
    if(fingerprints.has(key))identicalRows++;
    fingerprints.add(key);
    receivedRows++;prev=t.ts;newest??=t.ts;oldest=t.ts;
    if(t.ts>=g.time&&t.ts<g.end)inside++;
   }
   // Positive evidence is enough for a diagnostic; no need to page for counts.
   if(inside||oldest<g.time||rows.length<500)break;
   const next=page.at(-1).id;
   if(cursors.has(next))return result('UNVERIFIED','커서 반복');
   cursors.add(next);cursor=next;
  }
  return result(inside?'TRADES_PRESENT':newest===null?'EMPTY_UNVERIFIED':newest>=g.end&&oldest<g.time?'NO_TRADE_BRACKETED_HINT':newest<g.time?'LAST_TRADE_BEFORE_GAP_HINT':'COVERAGE_INSUFFICIENT');
 }catch(e){return result('UNVERIFIED',e.message);}
}
