import {units,boundary,inspectBars} from '../js/data-health.mjs';
const fields=['open','high','low','close','volume','turnover'];
const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-9*Math.max(Math.abs(a),Math.abs(b),1e-12);
const matches=(p,bs)=>p.volume>0&&p.turnover>0&&bs.length>0&&bs.every(b=>b.volume>0&&b.turnover>0)&&fields.every(k=>near(p[k],k==='open'?bs[0].open:k==='close'?bs.at(-1).close:k==='high'?Math.max(...bs.map(b=>b.high)):k==='low'?Math.min(...bs.map(b=>b.low)):bs.reduce((s,b)=>s+b[k],0)));
// Only a complete, aligned, bracketed historical interval, with fresh verified
// sources, may extend the original no-trade corroboration. Never override a
// smaller parent's mismatch or use a provisional parent as proof.
export function gapEvidence(archive,sets,meta,now,days=[]){
 const valid={},maps={};for(const [tf,u] of Object.entries(units)){try{if(meta[tf]?.sourceFresh!==true||meta[tf]?.error)continue;const bs=archive[tf]||sets[tf];inspectBars(bs,u,now);valid[tf]=bs;maps[tf]=new Map(bs.map(b=>[b.time,b]));}catch{}}
 const daily=days.filter(d=>d.end-d.time===86400000&&d.end<=now&&fields.every(k=>Number.isFinite(d[k]))&&d.low>0&&d.high>=Math.max(d.open,d.close)&&d.low<=Math.min(d.open,d.close)&&d.volume>0&&d.turnover>0);
 const uniqueDaily=daily.filter(d=>daily.filter(x=>x.time<d.end&&x.end>d.time).length===1);
 const memo=new Map();return (g,tf)=>{if(g.large||!valid[tf])return null;const u=units[tf],bs=valid[tf];const parents=Object.keys(units).filter(p=>units[p]>u&&units[p]%u===0).map(p=>({name:p,bar:maps[p]?.get(boundary(g.time,units[p]))}));parents.push({name:'1d',bar:uniqueDaily.find(d=>d.time<=g.time&&d.end>=g.end)});
 for(const {name,bar:p} of parents){if(!p||p.end>now||p.time>g.time||p.end<g.end)continue;if(boundary(p.time,u)!==p.time||boundary(p.end,u)!==p.end)continue;
 const key=tf+'|'+name+'|'+p.time;if(!memo.has(key)){const covered=bs[0].time<=p.time&&bs.at(-1).end>=p.end;const children=covered?bs.filter(b=>b.time>=p.time&&b.end<=p.end):[];memo.set(key,!covered?'INSUFFICIENT':matches(p,children)?'MATCH':'MISMATCH');}const state=memo.get(key);if(state==='MATCH')return name+'-archive';if(state==='MISMATCH')return null;
 }return null;};
}
export function referencePrice(bars,slot){const b=(bars||[]).filter(b=>b.end<=slot).at(-1);return {asOf:slot,price:b?.close??null,candleStart:b?.time??null,candleEnd:b?.end??null,lagFromCandleEndMs:b?slot-b.end:null,exactTradeTime:null,status:!b?'MISSING':b.end===slot?'CLOSED_CANDLE':'LAST_AVAILABLE_CANDLE'};}
export function tickerSnapshot(t,observedAt,slot){const p=Number(t?.trade_price),ts=Number(t?.trade_timestamp),generated=Number(t?.timestamp);const ok=p>0&&Number.isFinite(p)&&Number.isSafeInteger(ts)&&ts>0&&ts<=observedAt&&Number.isSafeInteger(generated)&&generated>=ts&&generated<=observedAt;return {price:ok?p:null,tradeAt:ok?ts:null,generatedAt:ok?generated:null,observedAt,ageMs:ok?observedAt-ts:null,status:!ok?'UNVERIFIED':ts<slot||observedAt-ts>120000||observedAt-generated>30000?'STALE':'FRESH'};}
export function recheckCandidate(r,t,observedAt,slot){const snap=tickerSnapshot(t,observedAt,slot);const p=snap.price,stop=r.entryStop,target=r.resistance;const risk=(p-stop)/p,rr=(target-p)/(p-stop);const valid=snap.status==='FRESH'&&Number.isFinite(stop)&&stop>0&&Number.isFinite(target)&&risk>=.006&&risk<=.05&&rr>=1.5&&p<=r.price*1.025;return {...snap,status:valid?'RECHECK_OK':snap.status==='FRESH'?'RISK_CHANGED':snap.status,riskPct:Number.isFinite(risk)&&p>0?risk:null,rr:Number.isFinite(rr)&&p>stop?rr:null};}
