import {makeApi} from './scan.mjs';
// Node 22 JSON.parse source context retains int64 lexemes BEFORE Number rounding.
export function parseTradeRows(raw){
 const rows=JSON.parse(raw,(key,value,ctx)=>{
  if(key==='sequential_id'&&typeof value==='number'){
   if(typeof ctx?.source!=='string'||!/^\d+$/.test(ctx.source))throw Error('체결 ID 원문 정밀도 확인 불가');
   return ctx.source;
  }
  return value;
 });
 if(!Array.isArray(rows))throw Error('체결 응답 형식 오류');return rows;
}
export function makeApiV83(fetcher=fetch,onRaw=()=>{}){
 const base=makeApi(fetcher);
 const api=async(path,params)=>{
  if(path!=='v1/trades/ticks')return base(path,params);
  const res=await fetcher('https://api.bithumb.com/'+path+'?'+new URLSearchParams(params),{signal:AbortSignal.timeout(10000),headers:{accept:'application/json'}});
  const raw=await res.text();onRaw({market:params.market,cursor:params.cursor??null,status:res.status,raw});
  if(!res.ok)throw Error('빗썸 HTTP '+res.status);return parseTradeRows(raw);
 };api.legacy=base.legacy;return api;
}
