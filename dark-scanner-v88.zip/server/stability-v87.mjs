import {pickTargets,targetedRepair,gapTape,repairParent} from './repair-v87.mjs';
import {diagnoseGaps,currentFrame,dailyFrames} from './gaps-v84.mjs';
import {units,boundary,inspectBars} from '../js/data-health.mjs';
import {gapEvidence,referencePrice,tickerSnapshot,recheckCandidate} from './evidence-v85.mjs';
import {evaluateV81} from './health-v85.mjs';
import {collectFrame,paceApi} from './stability-v81.mjs';
import {makeApi,slotOf,isStale,alertCandidates as baseCandidates} from './scan.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import {candleFlow,fetchFlow,flowInterpretation} from './flow-v84.mjs';
import {maintenance} from './recovery.mjs';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const DAY=86400000;
const warning=m=>m.market_warning&&m.market_warning!=='NONE'?m.market_warning:m.market_event?.warning||Object.values(m.market_event?.caution||{}).some(Boolean)?'CAUTION':'NONE';
export function orderedUniverse(markets,tickers){
 const ts=new Map(tickers.map(t=>[t.market,t]));const value=t=>Math.max(Number(t?.acc_trade_price_24h)||0,Number(t?.acc_trade_price)||0);
 const valid=markets.filter(m=>/^KRW-[A-Z0-9]+$/.test(m.market));const by=new Map(valid.map(m=>[m.market,m]));
 const all=[...by.keys()];const liquid=all.filter(s=>value(ts.get(s))>=3e8).sort((a,b)=>value(ts.get(b))-value(ts.get(a)));
 const positive=liquid.filter(s=>Number(ts.get(s)?.signed_change_rate)>0).sort((a,b)=>Number(ts.get(b).signed_change_rate)-Number(ts.get(a).signed_change_rate));
 const negative=liquid.filter(s=>Number(ts.get(s)?.signed_change_rate)<=0);
 return [...new Set([...positive.slice(0,55),...liquid.slice(0,100),...negative.slice(0,55),...liquid,...all])];
}
export function evaluateV82(symbol,sets,now,meta={},context={},analyze=analyzeSymbol){
 let r=evaluateV81(symbol,sets,now,meta,context,analyze);
 const h=r.dataHealth?.find(x=>x.tf==='15m');const last=h?.gaps?.find(g=>g.end===h.expected);
 if(r.tier==='U'&&h&&!h.latest&&last?.kind==='NO_TRADE_SUPPORTED'&&h.sourceFresh&&!h.error&&h.count>=70){
  const parents=r.dataHealth.filter(x=>['30m','1h','4h'].includes(x.tf)&&x.usable&&x.sourceFresh&&!x.error);
  if(parents.length){const ref=parents.map(x=>{const b=sets[x.tf].at(-1);return {tf:x.tf,end:b.end,close:b.close,turnover:b.turnover,flow:candleFlow(sets[x.tf])};});r={...r,observationOnly:true,observationFrames:ref,reason:r.reason+' / 최신 15분 미체결 추정 · 상위 봉 관찰만 허용',entryState:'상위 봉 관찰 · 실제 15분 확정봉 대기'};}
 }
 const b=sets['15m']||[];const h1=sets['1h']||[];
 r.flow={candle15:h?.latest&&h.sourceFresh&&!h.error?candleFlow(b):null,candle1h:r.dataHealth?.some(x=>x.tf==='1h'&&x.latest&&x.sourceFresh&&!x.error)?candleFlow(h1):null,tape:{status:'NOT_REQUESTED'},interpretation:'체결 미확인'};
 if(context.tickerMissing||context.marketWarning!=='NONE'&&context.marketWarning){r={...r,entryReady:false,safe:false,signal:r.tier==='U'?'GRAY':'RED',entryState:'시세 미확인/투자주의 · 진입 차단',entryStop:null,entryRR:null,tier:r.tier==='A'?'B':r.tier,score:r.tier==='A'?Math.min(79,r.score):r.score};}
 return r;
}
// Mark only successful primary responses for the current closed boundary as reusable.
// Unchanged higher frames can use the verified backup; first migration rechecks all.
export async function scanV87({api=makeApi(),now=Date.now,wait=sleep,cache={},archive={},verified={},analyze=analyzeSymbol,workers=8,repairFrames=120,flowLimit=60,flowPages=12,liveLimit=60,dailyLimit=80,targetedLimit=160,tapeGapLimit=100,budgetMs=600000}={}){
 const startedAt=now(),slot=slotOf(startedAt),result={version:'8.7',startedAt,slot,analysisAsOf:slot,scope:'all',marketCount:0,total:0,valid:0,partial:0,invalid:0,recovered:0,qualified:0,results:[],errors:[],metrics:{requests:0,requestErrors:0,byEndpoint:{},cacheHits:0,primaryFrames:0,primaryFreshFrames:0,primaryCompletedMarkets:0,engineEvaluations:0,repairFrames:0,flowMarkets:0,flowVerified:0,observationMarkets:0,stagesMs:{}}};
 const mt=result.metrics;let stage=startedAt;const mark=k=>{mt.stagesMs[k]=now()-stage;stage=now();};
 const remaining=()=>Math.min(startedAt+budgetMs,slot+900000)-now();const guard=()=>{if(remaining()<=0)throw Error('검색 시각 초과');};
 let cooldown=0;const call=fn=>async(...args)=>{guard();if(cooldown>Date.now())await wait(cooldown-Date.now());guard();mt.requests++;const name=typeof args[0]==='string'&&args[0].startsWith('v1/')?args[0]:'legacy';mt.byEndpoint[name]=(mt.byEndpoint[name]||0)+1;try{return await fn(...args);}catch(e){mt.requestErrors++;if(/HTTP 429|HTTP 503/.test(e.message))cooldown=Math.max(cooldown,Date.now()+3000);throw e;}};
 const counted=call(api);if(api.legacy)counted.legacy=call(api.legacy);
 const optional=(deadline)=>{const check=()=>{if(now()>=deadline||remaining()<35000)throw Error('선택 작업 시간 제한');};const wrap=fn=>async(...args)=>{check();return fn(...args);};const a=wrap(counted);if(counted.legacy)a.legacy=wrap(counted.legacy);return {api:a,guard:check};};
 const records=new Map();let universe=[];const validTicker=t=>t&&Number.isFinite(Number(t.acc_trade_price_24h))&&Number(t.acc_trade_price_24h)>=0&&Number.isFinite(Number(t.signed_change_rate))&&Number(t.trade_price)>0;
 async function pool(list,fn,n=workers){let next=0;await Promise.all(Array.from({length:Math.min(n,list.length)},async()=>{while(next<list.length&&remaining()>0){const item=list[next++];await fn(item);}}));}
 const evaluate=rec=>{const {symbol,sets,meta,context}=rec;let r;try{r=evaluateV82(symbol,sets,slot,meta,{...context,gapEvidence:gapEvidence(archive[symbol]||{},sets,meta,slot,rec.days)},analyze);}catch(e){r={symbol,tier:'U',score:0,dataStatus:'INVALID',entryReady:false,safe:false,signal:'GRAY',reason:e.message};}r.referencePrice={...referencePrice(sets['15m'],slot),sourceVerified:meta['15m']?.sourceFresh===true&&!meta['15m']?.error};r.initialTicker=tickerSnapshot(rec.ticker,rec.tickerObservedAt??startedAt,slot);r.koreanName=rec.market.korean_name||symbol; // Observations remain separate from the original full strategy engine.
 if(r.tier==='U'){r.availableObservations=Object.entries(sets).filter(([tf,bs])=>meta[tf]?.sourceFresh&&!meta[tf]?.error&&bs.length).map(([tf,bs])=>({tf,end:bs.at(-1).end,expected:boundary(slot,units[tf]),close:bs.at(-1).close,flow:candleFlow(bs),observationOnly:true}));if(r.availableObservations.length)r.observationOnly=true;}
 r.turnover24h=validTicker(rec.ticker)?Number(rec.ticker.acc_trade_price_24h):null;r.turnoverExchangeDay=Number.isFinite(Number(rec.ticker?.acc_trade_price))?Number(rec.ticker.acc_trade_price):null;r.priority3e8=Math.max(r.turnover24h||0,r.turnoverExchangeDay||0)>=3e8;const b=sets['15m']||[],mid=boundary(startedAt,1440);r.turnoverKstObserved=b.filter(x=>x.time>=mid).reduce((a,x)=>a+x.turnover,0);r.turnoverKstComplete=!!(b.length&&b[0].time<=mid&&b.at(-1).end===slot&&b.filter(x=>x.time>=mid).length===(slot-mid)/900000);if(r.tier!=='U')mt.engineEvaluations++;return r;};
 try{
  const markets=[...new Map((await counted('v1/market/all',{isDetails:'true'})).filter(m=>/^KRW-[A-Z0-9]+$/.test(m.market)).map(m=>[m.market,m])).values()];result.marketCount=markets.length;if(!markets.length)throw Error('원화마켓 없음');
  const tickerTimes=new Map();const tickers=[];for(let i=0;i<markets.length;i+=45){try{const rows=await counted('v1/ticker',{markets:markets.slice(i,i+45).map(m=>m.market).join(',')});const at=now();for(const t of rows)tickerTimes.set(t.market,at);tickers.push(...rows);}catch(e){result.errors.push({stage:'ticker',reason:e.message});}}
  const by=new Map(markets.map(m=>[m.market,m])),ts=new Map(tickers.filter(validTicker).map(t=>[t.market,t]));universe=orderedUniverse(markets,tickers);result.total=universe.length;mt.tickerCoverage=ts.size;mark('marketAndTicker');
  for(const symbol of universe)records.set(symbol,{symbol,market:by.get(symbol),ticker:ts.get(symbol),tickerObservedAt:tickerTimes.get(symbol),sets:{},meta:{},context:{marketWarning:warning(by.get(symbol)),tickerMissing:!ts.has(symbol)}});
  // Primary pass: all markets, no gap repairs or tape calls can starve coverage.
  // Frame-major order gives every market the freshest 15m before higher frames.
  for(const [tf,u] of Object.entries(units)){
   await pool(universe,async symbol=>{const rec=records.get(symbol),cached=cache[symbol]?.[tf]||[],end=boundary(startedAt,u);let f;
    if(tf!=='15m'&&verified[symbol]?.[tf]===end&&cached.at(-1)?.end===end){try{inspectBars(cached,u,startedAt);f={bars:cached.slice(-200),archive:cached,meta:{sourceFresh:true,recovered:0,requests:0,notes:['동일 확정봉 검증 백업 재사용']}};mt.cacheHits++;}catch{}}
    if(!f){f=await collectFrame({api:counted,market:symbol,tf,now:startedAt,cached,wait,guard,repair:false});mt.primaryFrames++;}
    rec.sets[tf]=f.bars;rec.meta[tf]=f.meta;archive[symbol]??={};if(f.archive.length)archive[symbol][tf]=f.archive;verified[symbol]??={};if(f.meta.sourceFresh&&!f.meta.error&&f.bars.at(-1)?.end===end){verified[symbol][tf]=end;mt.primaryFreshFrames++;}else delete verified[symbol][tf];
   });
  }
  mt.primaryCompletedMarkets=[...records.values()].filter(r=>Object.keys(r.meta).length===4).length;mark('primary');
  for(const rec of records.values()){if(Object.keys(rec.meta).length===4){rec.r=evaluate(rec);}else rec.r={symbol:rec.symbol,koreanName:rec.market.korean_name,tier:'U',score:0,signal:'GRAY',dataStatus:'INVALID',entryReady:false,safe:false,reason:'시간 제한으로 일부 프레임 미수집',flow:{tape:{status:'NOT_REQUESTED'}}};}mark('analysis');
  // In-progress candles are observations, never inputs to the closed-candle engine or archive.
  const live=optional(now()+Math.max(0,Math.min(140000,remaining()-180000)));
  mt.liveHourlyRequested=0;mt.liveHourlyPresent=0;mt.liveReasons={};
  await pool(universe.slice(0,liveLimit),async symbol=>{if(remaining()<180000)return;const rec=records.get(symbol);try{live.guard();}catch{return;}const snap=await currentFrame(live.api,symbol,'1h',now);rec.liveHour=snap;mt.liveHourlyRequested++;if(snap.status==='PROVISIONAL')mt.liveHourlyPresent++;mt.liveReasons[snap.status]=(mt.liveReasons[snap.status]||0)+1;});mark('live');
  // Classify unknown holes separately; original no-trade and maintenance rules stay intact.
  for(const rec of records.values())rec.gapTrace=diagnoseGaps(rec.r.dataHealth,archive[rec.symbol]||{},startedAt);
  const dailyTargets=[...records.values()].filter(r=>r.gapTrace.length).sort((a,b)=>b.gapTrace.filter(x=>x.recent).length-a.gapTrace.filter(x=>x.recent).length||b.gapTrace.length-a.gapTrace.length);
  const daily=optional(now()+Math.max(0,Math.min(30000,remaining()-180000)));mt.dailyRequested=0;mt.dailyErrors=0;
  await pool(dailyTargets.slice(0,dailyLimit),async rec=>{try{daily.guard();}catch{return;}mt.dailyRequested++;try{rec.days=await dailyFrames(daily.api,rec.symbol,startedAt);}catch(e){mt.dailyErrors++;rec.dailyError=e.message;}});for(const rec of dailyTargets)if(rec.days){rec.r=evaluate(rec);rec.gapTrace=diagnoseGaps(rec.r.dataHealth,archive[rec.symbol]||{},slot,rec.days);}mark('daily');
  // Prioritize actual trade evidence and latest holes; keep grade gates unchanged.
  const targeted=pickTargets(records.values(),slot);mt.targetedQueue=targeted.length;mt.targetedAttempted=0;mt.targetedRecovered=0;mt.targetedMethods={};mt.targetedParentRecovered=0;mt.gapTapeMarkets=0;mt.gapTapeReasons={};mt.targetedErrors=0;mt.targetedDeferred=0;
  const targetedApi=optional(now()+Math.max(0,Math.min(110000,remaining()-150000)));const tapeTargets=[];const refreshed=new Set();
  await pool(targeted.slice(0,targetedLimit),async({rec,g})=>{try{targetedApi.guard();}catch{return;}const tf=g.tf;if(rec.meta[tf]?.error||!rec.meta[tf]?.sourceFresh)return;mt.targetedAttempted++;const old=archive[rec.symbol]?.[tf]||[];const f=await targetedRepair({api:targetedApi.api,market:rec.symbol,g,slot,old});rec.targetedGap={...g,method:f.method,error:f.error||null};if(f.error){mt.targetedErrors++;if(/불일치/.test(f.error)){rec.meta[tf].error=f.error;rec.meta[tf].sourceFresh=false;delete verified[rec.symbol][tf];refreshed.add(rec);}return;}
   archive[rec.symbol][tf]=f.bars;rec.sets[tf]=f.bars.slice(-200);refreshed.add(rec);if(f.method){mt.targetedRecovered++;mt.targetedMethods[f.method]=(mt.targetedMethods[f.method]||0)+1;rec.meta[tf].recovered=(rec.meta[tf].recovered||0)+1;if(f.bars.at(-1)?.end===boundary(slot,units[tf]))verified[rec.symbol][tf]=boundary(slot,units[tf]);}
   else{tapeTargets.push({rec,g});if(g.reason==='PARENT_NOT_STORED'){try{const p=await repairParent({api:targetedApi.api,market:rec.symbol,g,slot,archive:archive[rec.symbol],meta:rec.meta});if(p){archive[rec.symbol][p.tf]=p.bars;rec.sets[p.tf]=p.bars.slice(-200);mt.targetedParentRecovered++;}}catch(e){rec.targetedGap.parentError=e.message;mt.targetedErrors++;if(e.frame&&/불일치/.test(e.message)){rec.meta[e.frame].error=e.message;rec.meta[e.frame].sourceFresh=false;delete verified[rec.symbol][e.frame];}}}}
  },4);
  for(const rec of refreshed){rec.r=evaluate(rec);rec.gapTrace=diagnoseGaps(rec.r.dataHealth,archive[rec.symbol]||{},slot,rec.days);}
  mt.targetedDeferred=Math.max(0,targeted.length-mt.targetedAttempted);mark('targetedRepair');
  // Gap tape has a separate quota from strategy flow and cannot promote a grade.
  const gapApi=optional(now()+Math.max(0,Math.min(65000,remaining()-120000)));
  const tapeSet=new Set(tapeTargets.map(x=>x.rec.symbol));const gapQueue=targeted.filter(x=>tapeSet.has(x.rec.symbol)||!x.rec.targetedGap).filter(({rec,g})=>!archive[rec.symbol]?.[g.tf]?.some(b=>b.time===g.time));
  await pool(gapQueue.slice(0,tapeGapLimit),async({rec,g})=>{try{gapApi.guard();}catch{return;}const tape=await gapTape(gapApi.api,rec.symbol,g,slot);rec.gapTape={tf:g.tf,time:g.time,end:g.end,...tape};mt.gapTapeMarkets++;mt.gapTapeReasons[tape.status]=(mt.gapTapeReasons[tape.status]||0)+1;},4);mark('gapTape');
  // Primary coverage first. Optional repair uses up to 4 minutes, reserving
  // 2 minutes for tape and 45 seconds for finalization within the hard guard.
  const jobs=[];for(const rec of records.values())for(const h of rec.r.dataHealth||[]){const knownOld=(archive[rec.symbol]?.[h.tf]||[]).some((b,i,a)=>i&&maintenance.some(m=>a[i-1].end<m.end&&b.time>m.start&&b.time>a[i-1].end));
   if(h.error||!h.sourceFresh||!h.count||h.gaps.some(g=>!g.large&&g.kind!=='NO_TRADE_SUPPORTED'&&!(rec.targetedGap?.tf===h.tf&&rec.targetedGap?.time===g.time)&&!rec.gapTrace?.some(x=>x.tf===h.tf&&x.time===g.time&&x.reason==='WAIT_PARENT_CLOSE'))||knownOld)jobs.push({rec,h,refresh:!!(h.error||!h.sourceFresh||!h.count||(!h.latest&&rec.targetedGap?.tf!==h.tf))});}
  // Rotate stable order rather than liquidity rank, so less-active markets get a turn.
  jobs.sort((a,b)=>(a.rec.symbol+'|'+a.h.tf).localeCompare(b.rec.symbol+'|'+b.h.tf));
  const rotate=jobs.length?Math.floor(slot/900000)*Math.max(1,repairFrames)%jobs.length:0;
  const batch=[...jobs.slice(rotate),...jobs.slice(0,rotate)].sort((a,b)=>Number(b.refresh)-Number(a.refresh)||Number(b.rec.gapTrace?.some(x=>x.tf===b.h.tf&&x.recent&&x.reason==='PARENT_MISMATCH'))-Number(a.rec.gapTrace?.some(x=>x.tf===a.h.tf&&x.recent&&x.reason==='PARENT_MISMATCH'))||Number(b.rec.gapTrace?.some(x=>x.tf===b.h.tf&&x.recent&&x.reason!=='WAIT_PARENT_CLOSE'))-Number(a.rec.gapTrace?.some(x=>x.tf===a.h.tf&&x.recent&&x.reason!=='WAIT_PARENT_CLOSE'))).slice(0,repairFrames);mt.repairQueue=jobs.length;mt.repairRecoveredCandles=0;mt.repairErrors=0;mt.repairRefreshes=0;
  const repairDeadline=now()+Math.max(0,Math.min(240000,remaining()-120000));const repair=optional(repairDeadline);const touched=new Set();
  await pool(batch,async({rec,h,refresh})=>{if(now()>=repairDeadline||remaining()<120000)return;if(/불일치/.test(rec.meta[h.tf]?.error||''))return;const tf=h.tf,old=archive[rec.symbol]?.[tf]||[],before=new Set(old.map(b=>b.time));
   const f=await collectFrame({api:repair.api,market:rec.symbol,tf,now:startedAt,cached:old,wait,guard:repair.guard,repairOnly:!refresh,repair:true,skipTimes:new Set(h.gaps.filter(g=>g.kind==='NO_TRADE_SUPPORTED'||(rec.targetedGap?.tf===h.tf&&rec.targetedGap?.time===g.time)||rec.gapTrace?.some(x=>x.tf===h.tf&&x.time===g.time&&x.reason==='WAIT_PARENT_CLOSE')).map(g=>g.time))});mt.repairFrames++;if(refresh)mt.repairRefreshes++;
   const conflict=/불일치/.test(f.meta.error||'');if(f.meta.error&&!conflict){mt.repairErrors++;if(!refresh){rec.meta[tf].notes.push('추가 복구 보류: '+f.meta.error);return;}}if(f.archive.length){archive[rec.symbol][tf]=f.archive;mt.repairRecoveredCandles+=f.archive.filter(b=>!before.has(b.time)&&old.length&&b.time>=old[0].time&&b.end<=boundary(startedAt,units[tf])).length;}
   rec.sets[tf]=f.bars;rec.meta[tf]={...f.meta,recovered:(rec.meta[tf]?.recovered||0)+f.meta.recovered,requests:(rec.meta[tf]?.requests||0)+f.meta.requests};touched.add(rec);if(f.meta.error){delete verified[rec.symbol][tf];}else if(f.bars.at(-1)?.end===boundary(startedAt,units[tf]))verified[rec.symbol][tf]=boundary(startedAt,units[tf]);},Math.min(workers,4));
  for(const rec of touched)rec.r=evaluate(rec);mt.repairDeferred=Math.max(0,jobs.length-mt.repairFrames);mark('repair');
  const targets=[...records.values()].filter(rec=>rec.r.tier!=='U'&&rec.r.dataStatus!=='INVALID'&&rec.r.flow?.candle15&&(/반등|급등|초입/.test(rec.r.strategy||'')||rec.r.flow.candle15.lowerWickBull)).sort((a,b)=>Number(b.r.flow.candle15.lowerWickBull)-Number(a.r.flow.candle15.lowerWickBull)||b.r.score-a.r.score);mt.flowEligible=targets.length;mt.flowReasons={};mt.flowPages=0;
  const flow=optional(now()+Math.max(0,remaining()-60000));
  await pool(targets.slice(0,flowLimit),async rec=>{if(remaining()<60000)return;const tape=await fetchFlow(flow.api,rec.symbol,rec.sets['15m'],flow.guard,flowPages);rec.r.flow.tape=tape;rec.r.flow.interpretation=flowInterpretation(rec.r.flow.candle15,tape);mt.flowMarkets++;mt.flowPages+=tape.pages||0;if(tape.status==='VERIFIED')mt.flowVerified++;else{const why=tape.reason||'기타';mt.flowReasons[why]=(mt.flowReasons[why]||0)+1;}},4);mt.flowDeferred=Math.max(0,targets.length-mt.flowMarkets);mark('flow');
  // Final current-price check cannot upgrade any closed-candle grade.
  const candidates=[...records.values()].filter(({r})=>r&&r.dataStatus!=='PARTIAL'&&r.dataStatus!=='INVALID'&&((r.tier==='A'&&r.signal==='GREEN')||(r.tier==='B'&&r.signal==='YELLOW'&&r.phase==='진입 임박')));
  mt.priceRecheckTargets=candidates.length;mt.priceRecheckPassed=0;
  for(let i=0;i<candidates.length;i+=45){const batch=candidates.slice(i,i+45);let rows=[];try{if(remaining()>20000)rows=await counted('v1/ticker',{markets:batch.map(x=>x.symbol).join(',')});}catch(e){result.errors.push({stage:'priceRecheck',reason:e.message});}const at=now();for(const rec of batch){const r=rec.r;r.firstDetectedTier=r.tier;r.priceRecheck=recheckCandidate(r,rows.find(x=>x.market===rec.symbol),at,slot);if(r.priceRecheck.status==='RECHECK_OK'){mt.priceRecheckPassed++;r.currentValidTier=r.tier;}else{r.currentValidTier=r.tier==='A'?'B':'C';r.tier=r.currentValidTier;r.score=Math.min(r.score,r.tier==='B'?79:64);r.entryReady=false;r.safe=false;r.entryStop=null;r.entryRR=null;r.signal='YELLOW';r.phase='형성 중';r.entryState='현재가 재검증 보류';r.reason+=' / 현재가 재검증: '+r.priceRecheck.status;}}}mark('priceRecheck');
 }catch(e){result.status='FAILED';result.message=e.message;}
 mt.extendedGapEvidence=0;mt.dailyGapEvidence=0;mt.gapReasons={};mt.recentGapReasons={};for(const rec of records.values()){if(!rec.r)continue;rec.r.firstDetectedTier??=rec.r.tier;rec.r.currentValidTier??=rec.r.tier;rec.r.targetedGap=rec.targetedGap||null;rec.r.gapTape=rec.gapTape||null;rec.r.liveHour=rec.liveHour||{status:'NOT_REQUESTED'};rec.r.dailyDiagnostic=rec.dailyError?{status:'ERROR',reason:rec.dailyError}:rec.days?{status:'RECEIVED',closedDays:rec.days.length}:{status:'NOT_REQUESTED'};rec.r.gapTrace=diagnoseGaps(rec.r.dataHealth,archive[rec.symbol]||{},slot,rec.days);if(rec.days)rec.r.dailyEvidenceBars=rec.days;for(const h of rec.r.dataHealth||[])for(const g of h.gaps||[])if(g.parent?.endsWith('-archive')){mt.extendedGapEvidence++;if(g.parent==='1d-archive')mt.dailyGapEvidence++;}for(const g of rec.r.gapTrace){mt.gapReasons[g.reason]=(mt.gapReasons[g.reason]||0)+1;if(g.recent)mt.recentGapReasons[g.reason]=(mt.recentGapReasons[g.reason]||0)+1;}}
 result.results=universe.map(symbol=>records.get(symbol)?.r||{symbol,tier:'U',score:0,signal:'GRAY',dataStatus:'INVALID',entryReady:false,safe:false,reason:'검색 중단 · 미분석'});
 result.valid=result.results.filter(r=>r.tier!=='U'&&['OK','RECOVERED','QUALIFIED'].includes(r.dataStatus)).length;result.partial=result.results.filter(r=>r.tier!=='U'&&r.dataStatus==='PARTIAL').length;result.invalid=result.results.length-result.valid-result.partial;result.qualified=result.results.filter(r=>r.dataStatus==='QUALIFIED').length;result.recovered=result.results.filter(r=>r.dataHealth?.some(h=>h.recovered)).length;mt.observationMarkets=result.results.filter(r=>r.observationOnly).length;mt.uniqueEngineMarkets=result.valid+result.partial;mt.processedMarkets=result.results.length;mt.fullCoverage=result.total>0&&mt.primaryCompletedMarkets===result.total;mt.elapsedMs=now()-startedAt;result.finishedAt=now();
 result.errors.push(...result.results.filter(r=>r.tier==='U').map(r=>({symbol:r.symbol,reason:r.reason})));result.results.sort((a,b)=>({A:0,B:1,C:2,U:3}[a.tier]-{A:0,B:1,C:2,U:3}[b.tier])||b.score-a.score);
 if(slotOf(result.finishedAt)!==slot||result.finishedAt-startedAt>=budgetMs)result.status='STALE';else if(!result.status)result.status=!mt.fullCoverage?'INCOMPLETE':!result.valid&&!result.partial?'FAILED':result.invalid||result.partial?'PARTIAL':'OK';
 result.message??=mt.fullCoverage?'전체 종목 조회 완료 · 데이터 품질 별도 표시':'전체 종목 수집 미완료';return result;
}
export function alertCandidates(s,previous={},now=Date.now()){return s?.metrics?.fullCoverage?baseCandidates(s,previous,now).filter(r=>r.entryStop&&r.signal!=='RED'&&r.priceRecheck?.status==='RECHECK_OK'&&now-r.priceRecheck.tradeAt<=120000):[];}
export {isStale,paceApi};

export {evaluateV82 as evaluateV83};
