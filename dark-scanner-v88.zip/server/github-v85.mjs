import {mkdir,readFile,writeFile,rename} from 'node:fs/promises';
import {scanV85,paceApi,alertCandidates,isStale} from './stability-v85.mjs';
import {makeApiV83} from './trade-api-v83.mjs';
import {units,inspectBars,boundary} from '../js/data-health.mjs';
const dir='.dark-cache',file=dir+'/candles.json';const archive={},verified={};let cacheStatus='초기 실행';
try{const c=JSON.parse(await readFile(file,'utf8'));if(c.schema!==1||!c.markets||typeof c.markets!=='object')throw Error('백업 형식 오류');for(const [symbol,sets] of Object.entries(c.markets)){if(!/^KRW-[A-Z0-9]+$/.test(symbol))continue;for(const [tf,u] of Object.entries(units)){const bars=sets?.[tf];if(!Array.isArray(bars)||!bars.length)continue;try{inspectBars(bars,u,Date.now());const retained=bars.filter(b=>b.end>=boundary(Date.now(),u)-30*86400000).slice(-3000);if(retained.length){archive[symbol]??={};archive[symbol][tf]=retained;}}catch{cacheStatus='일부 백업 검증 실패';}}}if(['8.2','8.3','8.4','8.5'].includes(c.version)&&c.verified&&typeof c.verified==='object')for(const [symbol,frames] of Object.entries(c.verified)){if(!archive[symbol])continue;verified[symbol]={};for(const tf of Object.keys(units))if(archive[symbol][tf]?.at(-1)?.end===frames?.[tf])verified[symbol][tf]=frames[tf];}if(cacheStatus==='초기 실행')cacheStatus='백업 복원';}catch(e){if(e.code!=='ENOENT')cacheStatus='백업 읽기 실패: '+e.message;}
const rawSamples=[];let rawBytes=0;const rawMarkets=new Set();
const capture=x=>{if(rawMarkets.has(x.market))return;const size=Buffer.byteLength(x.raw);if(rawBytes+size>8*1024*1024)return;rawMarkets.add(x.market);rawBytes+=size;rawSamples.push(x);};
const cache=structuredClone(archive),result=await scanV85({api:paceApi(makeApiV83(fetch,capture),undefined,80),cache,archive,verified});
result.metrics.rawTradeSampleMarkets=rawSamples.length;result.metrics.rawTradeSampleBytes=rawBytes;
const stale=isStale(result);if(stale)result.status='STALE';const candidates=alertCandidates(result);
await mkdir('scan-output',{recursive:true});await mkdir(dir,{recursive:true});
async function atomic(path,data){await writeFile(path+'.tmp',JSON.stringify(data));await rename(path+'.tmp',path);}
const saved={schema:1,version:'8.5',savedAt:Date.now(),markets:archive,verified};await atomic(file,saved);await atomic('scan-output/candles.json',saved);
await atomic('scan-output/trade-diagnostics.json',{sampleScope:'first response per market, max 8 MiB of public raw bodies',samples:rawSamples,reasonCounts:result.metrics.flowReasons});
await atomic('scan-output/gap-diagnostics.json',{version:'8.5',startedAt:result.startedAt,reasonCounts:result.metrics.gapReasons,recentReasonCounts:result.metrics.recentGapReasons,markets:result.results.map(r=>({symbol:r.symbol,liveHour:r.liveHour,dailyDiagnostic:r.dailyDiagnostic,unknown:r.gapTrace||[]}))});
await atomic('scan-output/latest.json',{...result,cacheStatus,candidateCount:candidates.length});
console.log(JSON.stringify({version:'8.5',status:result.status,total:result.total,valid:result.valid,qualified:result.qualified,partial:result.partial,invalid:result.invalid,recovered:result.recovered,cacheStatus,archivedMarkets:Object.keys(archive).length,candidateCount:candidates.length,metrics:result.metrics,message:result.message,finishedAt:new Date(result.finishedAt).toISOString()},null,2));
console.log('Candidate preview (not a buy signal):',JSON.stringify(candidates.map(r=>({symbol:r.symbol,tier:r.tier,strategy:r.strategy,phase:r.phase,price:r.price,stop:r.entryStop,rr:r.entryRR})),null,2));
console.log('Data errors (first 10):',JSON.stringify(result.errors.slice(0,10),null,2));
if(!['OK','PARTIAL'].includes(result.status)||!result.metrics.fullCoverage||!result.valid&&!result.partial)process.exitCode=1;
