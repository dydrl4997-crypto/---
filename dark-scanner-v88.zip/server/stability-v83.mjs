import {units,boundary,inspectBars} from '../js/data-health.mjs';
import {collectFrame,evaluateV81,assessFrames,paceApi} from './stability-v81.mjs';
import {makeApi,slotOf,isStale,alertCandidates as baseCandidates} from './scan.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import {candleFlow,fetchFlow,flowInterpretation} from './flow-v83.mjs';
import {maintenance} from './recovery.mjs';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const DAY=86400000;
const warning=m=>m.market_warning&&m.market_warning!=='NONE'?m.market_warning:m.market_event?.warning||Object.values(m.market_event?.caution||{}).some(Boolean)?'CAUTION':'NONE';
export function orderedUniverse(markets,tickers){
 const ts=new Map(tickers.map(t=>[t.market,t]));const value=t=>Math.max(Number(t?.acc_trade_price_24h)||0,Number(t?.acc_trade_price)||0);
 const valid=markets.filter(m=>/^KRW-[A-Z0-9]+$/.test(m.market));const by=new Map(valid.map(m=>[m.market,m]));
 const all=[...by.keys()];const liquid=all.filter(s=>value(ts.get(s))>=3e8).sort((a,b)=>value(ts.get(b))-value(ts.get(a)));
 const positive=liquid.filter(s=>Number(ts.get(s)?.signed_change_rate)>0).sort((a,b)=>Number(ts.get(b).signed_change_rate)-Number(ts.get(a).signed_change_rate));
 const negative=liquid.filter(s=>Number(ts.get(s)?.signed_change_rate)<=0);
 return [...new Set([...positive.slice(0,55),...liquid.slice(0,100),...negative.slice(0,55),...liquid,...all])];
}
export function evaluateV82(symbol,sets,now,meta={},context={},analyze=analyzeSymbol){
 let r=evaluateV81(symbol,sets,now,meta,context,analyze);
 const h=r.dataHealth?.find(x=>x.tf==='15m');const last=h?.gaps?.find(g=>g.end===h.expected);
 if(r.tier==='U'&&h&&!h.latest&&last?.kind==='NO_TRADE_SUPPORTED'&&h.sourceFresh&&!h.error&&h.count>=70){
  const parents=r.dataHealth.filter(x=>['30m','1h','4h'].includes(x.tf)&&x.usable&&x.sourceFresh&&!x.error);
  if(parents.length){const ref=parents.map(x=>{const b=sets[x.tf].at(-1);return {tf:x.tf,end:b.end,close:b.close,turnover:b.turnover,flow:candleFlow(sets[x.tf])};});r={...r,observationOnly:true,observationFrames:ref,reason:r.reason+' / 최신 15분 미체결 추정 · 상위 봉 관찰만 허용',entryState:'상위 봉 관찰 · 실제 15분 확정봉 대기'};}
 }
 const b=sets['15m']||[];const h1=sets['1h']||[];
 r.flow={candle15:h?.latest&&h.sourceFresh&&!h.error?candleFlow(b):null,candle1h:r.dataHealth?.some(x=>x.tf==='1h'&&x.latest&&x.sourceFresh&&!x.error)?candleFlow(h1):null,tape:{status:'NOT_REQUESTED'},interpretation:'체결 미확인'};
 if(context.tickerMissing||context.marketWarning!=='NONE'&&context.marketWarning){r={...r,entryReady:false,safe:false,signal:r.tier==='U'?'GRAY':'RED',entryState:'시세 미확인/투자주의 · 진입 차단',entryStop:null,entryRR:null,tier:r.tier==='A'?'B':r.tier,score:r.tier==='A'?Math.min(79,r.score):r.score};}
 return r;
}
// Mark only successful primary responses for the current closed boundary as reusable.
// Unchanged higher frames can use the verified backup; first migration rechecks all.
export async function scanV83({api=makeApi(),now=Date.now,wait=sleep,cache={},archive={},verified={},analyze=analyzeSymbol,workers=8,repairFrames=240,flowLimit=60,flowPages=12,budgetMs=600000}={}){
 const startedAt=now(),slot=slotOf(startedAt),result={version:'8.3',startedAt,slot,scope:'all',marketCount:0,total:0,valid:0,partial:0,invalid:0,recovered:0,qualified:0,results:[],errors:[],metrics:{requests:0,requestErrors:0,byEndpoint:{},cacheHits:0,primaryFrames:0,primaryFreshFrames:0,primaryCompletedMarkets:0,engineEvaluations:0,repairFrames:0,flowMarkets:0,flowVerified:0,observationMarkets:0,stagesMs:{}}};
 const mt=result.metrics;let stage=startedAt;const mark=k=>{mt.stagesMs[k]=now()-stage;stage=now();};
 const remaining=()=>Math.min(startedAt+budgetMs,slot+900000)-now();const guard=()=>{if(remaining()<=0)throw Error('검색 시각 초과');};
 let cooldown=0;const call=fn=>async(...args)=>{guard();if(cooldown>Date.now())await wait(cooldown-Date.now());guard();mt.requests++;const name=typeof args[0]==='string'&&args[0].startsWith('v1/')?args[0]:'legacy';mt.byEndpoint[name]=(mt.byEndpoint[name]||0)+1;try{return await fn(...args);}catch(e){mt.requestErrors++;if(/HTTP 429|HTTP 503/.test(e.message))cooldown=Math.max(cooldown,Date.now()+3000);throw e;}};
 const counted=call(api);if(api.legacy)counted.legacy=call(api.legacy);
 const optional=(deadline)=>{const check=()=>{if(now()>=deadline||remaining()<35000)throw Error('선택 작업 시간 제한');};const wrap=fn=>async(...args)=>{check();return fn(...args);};const a=wrap(counted);if(counted.legacy)a.legacy=wrap(counted.legacy);return {api:a,guard:check};};
 const records=new Map();let universe=[];const validTicker=t=>t&&Number.isFinite(Number(t.acc_trade_price_24h))&&Number(t.acc_trade_price_24h)>=0&&Number.isFinite(Number(t.signed_change_rate))&&Number(t.trade_price)>0;
 async function pool(list,fn,n=workers){let next=0;await Promise.all(Array.from({length:Math.min(n,list.length)},async()=>{while(next<list.length&&remaining()>0){const item=list[next++];await fn(item);}}));}
 const evaluate=rec=>{const {symbol,sets,meta,context}=rec;let r;try{r=evaluateV82(symbol,sets,startedAt,meta,context,analyze);}catch(e){r={symbol,tier:'U',score:0,dataStatus:'INVALID',entryReady:false,safe:false,signal:'GRAY',reason:e.message};}r.koreanName=rec.market.korean_name||symbol;r.turnover24h=validTicker(rec.ticker)?Number(rec.ticker.acc_trade_price_24h):null;r.turnoverExchangeDay=Number.isFinite(Number(rec.ticker?.acc_trade_price))?Number(rec.ticker.acc_trade_price):null;r.priority3e8=Math.max(r.turnover24h||0,r.turnoverExchangeDay||0)>=3e8;const b=sets['15m']||[],mid=boundary(startedAt,1440);r.turnoverKstObserved=b.filter(x=>x.time>=mid).reduce((a,x)=>a+x.turnover,0);r.turnoverKstComplete=!!(b.length&&b[0].time<=mid&&b.at(-1).end===slot&&b.filter(x=>x.time>=mid).length===(slot-mid)/900000);if(r.tier!=='U')mt.engineEvaluations++;return r;};
 try{
  const markets=[...new Map((await counted('v1/market/all',{isDetails:'true'})).filter(m=>/^KRW-[A-Z0-9]+$/.test(m.market)).map(m=>[m.market,m])).values()];result.marketCount=markets.length;if(!markets.length)throw Error('원화마켓 없음');
  const tickers=[];for(let i=0;i<markets.length;i+=45){try{tickers.push(...await counted('v1/ticker',{markets:markets.slice(i,i+45).map(m=>m.market).join(',')}));}catch(e){result.errors.push({stage:'ticker',reason:e.message});}}
  const by=new Map(markets.map(m=>[m.market,m])),ts=new Map(tickers.filter(validTicker).map(t=>[t.market,t]));universe=orderedUniverse(markets,tickers);result.total=universe.length;mt.tickerCoverage=ts.size;mark('marketAndTicker');
  for(const symbol of universe)records.set(symbol,{symbol,market:by.get(symbol),ticker:ts.get(symbol),sets:{},meta:{},context:{marketWarning:warning(by.get(symbol)),tickerMissing:!ts.has(symbol)}});
  // Primary pass: all markets, no gap repairs or tape calls can starve coverage.
  // Frame-major order gives every market the freshest 15m before higher frames.
  for(const [tf,u] of Object.entries(units)){
   await pool(universe,async symbol=>{const rec=records.get(symbol),cached=cache[symbol]?.[tf]||[],end=boundary(startedAt,u);let f;
    if(tf!=='15m'&&verified[symbol]?.[tf]===end&&cached.at(-1)?.end===end){try{inspectBars(cached,u,startedAt);f={bars:cached.slice(-200),archive:cached,meta:{sourceFresh:true,recovered:0,requests:0,notes:['동일 확정봉 검증 백업 재사용']}};mt.cacheHits++;}catch{}}
    if(!f){f=await collectFrame({api:counted,market:symbol,tf,now:startedAt,cached,wait,guard,repair:false});mt.primaryFrames++;}
    rec.sets[tf]=f.bars;rec.meta[tf]=f.meta;archive[symbol]??={};if(f.archive.length)archive[symbol][tf]=f.archive;verified[symbol]??={};if(f.meta.sourceFresh&&!f.meta.error&&f.bars.at(-1)?.end===end){verified[symbol][tf]=end;mt.primaryFreshFrames++;}else delete verified[symbol][tf];
   });
  }
  mt.primaryCompletedMarkets=[...records.values()].filter(r=>Object.keys(r.meta).length===4).length;mark('primary');
  for(const rec of records.values()){if(Object.keys(rec.meta).length===4){rec.r=evaluate(rec);}else rec.r={symbol:rec.symbol,koreanName:rec.market.korean_name,tier:'U',score:0,signal:'GRAY',dataStatus:'INVALID',entryReady:false,safe:false,reason:'시간 제한으로 일부 프레임 미수집',flow:{tape:{status:'NOT_REQUESTED'}}};}mark('analysis');
  // Primary coverage first. Optional repair uses up to 4 minutes, reserving
  // 2 minutes for tape and 45 seconds for finalization within the hard guard.
  const jobs=[];for(const rec of records.values())for(const h of rec.r.dataHealth||[]){const knownOld=(archive[rec.symbol]?.[h.tf]||[]).some((b,i,a)=>i&&maintenance.some(m=>a[i-1].end<m.end&&b.time>m.start&&b.time>a[i-1].end));
   if(h.error||!h.sourceFresh||!h.count||h.gaps.some(g=>!g.large&&g.kind!=='NO_TRADE_SUPPORTED')||knownOld)jobs.push({rec,h,refresh:!!(h.error||!h.sourceFresh||!h.count)});}
  // Rotate stable order rather than liquidity rank, so less-active markets get a turn.
  jobs.sort((a,b)=>(a.rec.symbol+'|'+a.h.tf).localeCompare(b.rec.symbol+'|'+b.h.tf));
  const rotate=jobs.length?Math.floor(slot/900000)*Math.max(1,repairFrames)%jobs.length:0;
  const batch=[...jobs.slice(rotate),...jobs.slice(0,rotate)].slice(0,repairFrames);mt.repairQueue=jobs.length;mt.repairRecoveredCandles=0;mt.repairErrors=0;mt.repairRefreshes=0;
  const repairDeadline=now()+Math.max(0,Math.min(240000,remaining()-120000));const repair=optional(repairDeadline);const touched=new Set();
  await pool(batch,async({rec,h,refresh})=>{if(now()>=repairDeadline||remaining()<120000)return;const tf=h.tf,old=archive[rec.symbol]?.[tf]||[],before=new Set(old.map(b=>b.time));
   const f=await collectFrame({api:repair.api,market:rec.symbol,tf,now:startedAt,cached:old,wait,guard:repair.guard,repairOnly:!refresh,repair:true,skipTimes:new Set(h.gaps.filter(g=>g.kind==='NO_TRADE_SUPPORTED').map(g=>g.time))});mt.repairFrames++;if(refresh)mt.repairRefreshes++;
   const conflict=/불일치/.test(f.meta.error||'');if(f.meta.error&&!conflict){mt.repairErrors++;if(!refresh){rec.meta[tf].notes.push('추가 복구 보류: '+f.meta.error);return;}}if(f.archive.length){archive[rec.symbol][tf]=f.archive;mt.repairRecoveredCandles+=f.archive.filter(b=>!before.has(b.time)&&old.length&&b.time>=old[0].time&&b.end<=boundary(startedAt,units[tf])).length;}
   rec.sets[tf]=f.bars;rec.meta[tf]={...f.meta,recovered:(rec.meta[tf]?.recovered||0)+f.meta.recovered,requests:(rec.meta[tf]?.requests||0)+f.meta.requests};touched.add(rec);if(f.meta.error){delete verified[rec.symbol][tf];}else if(f.bars.at(-1)?.end===boundary(startedAt,units[tf]))verified[rec.symbol][tf]=boundary(startedAt,units[tf]);},Math.min(workers,4));
  for(const rec of touched)rec.r=evaluate(rec);mt.repairDeferred=Math.max(0,jobs.length-mt.repairFrames);mark('repair');
  const targets=[...records.values()].filter(rec=>rec.r.tier!=='U'&&rec.r.dataStatus!=='INVALID'&&rec.r.flow?.candle15&&(/반등|급등|초입/.test(rec.r.strategy||'')||rec.r.flow.candle15.lowerWickBull)).sort((a,b)=>Number(b.r.flow.candle15.lowerWickBull)-Number(a.r.flow.candle15.lowerWickBull)||b.r.score-a.r.score);mt.flowEligible=targets.length;mt.flowReasons={};mt.flowPages=0;
  const flow=optional(now()+Math.max(0,remaining()-45000));
  await pool(targets.slice(0,flowLimit),async rec=>{if(remaining()<45000)return;const tape=await fetchFlow(flow.api,rec.symbol,rec.sets['15m'],flow.guard,flowPages);rec.r.flow.tape=tape;rec.r.flow.interpretation=flowInterpretation(rec.r.flow.candle15,tape);mt.flowMarkets++;mt.flowPages+=tape.pages||0;if(tape.status==='VERIFIED')mt.flowVerified++;else{const why=tape.reason||'기타';mt.flowReasons[why]=(mt.flowReasons[why]||0)+1;}},4);mt.flowDeferred=Math.max(0,targets.length-mt.flowMarkets);mark('flow');
 }catch(e){result.status='FAILED';result.message=e.message;}
 result.results=universe.map(symbol=>records.get(symbol)?.r||{symbol,tier:'U',score:0,signal:'GRAY',dataStatus:'INVALID',entryReady:false,safe:false,reason:'검색 중단 · 미분석'});
 result.valid=result.results.filter(r=>r.tier!=='U'&&['OK','RECOVERED','QUALIFIED'].includes(r.dataStatus)).length;result.partial=result.results.filter(r=>r.tier!=='U'&&r.dataStatus==='PARTIAL').length;result.invalid=result.results.length-result.valid-result.partial;result.qualified=result.results.filter(r=>r.dataStatus==='QUALIFIED').length;result.recovered=result.results.filter(r=>r.dataHealth?.some(h=>h.recovered)).length;mt.observationMarkets=result.results.filter(r=>r.observationOnly).length;mt.uniqueEngineMarkets=result.valid+result.partial;mt.processedMarkets=result.results.length;mt.fullCoverage=result.total>0&&mt.primaryCompletedMarkets===result.total;mt.elapsedMs=now()-startedAt;result.finishedAt=now();
 result.errors.push(...result.results.filter(r=>r.tier==='U').map(r=>({symbol:r.symbol,reason:r.reason})));result.results.sort((a,b)=>({A:0,B:1,C:2,U:3}[a.tier]-{A:0,B:1,C:2,U:3}[b.tier])||b.score-a.score);
 if(slotOf(result.finishedAt)!==slot||result.finishedAt-startedAt>=budgetMs)result.status='STALE';else if(!result.status)result.status=!mt.fullCoverage?'INCOMPLETE':!result.valid&&!result.partial?'FAILED':result.invalid||result.partial?'PARTIAL':'OK';
 result.message??=mt.fullCoverage?'전체 종목 조회 완료 · 데이터 품질 별도 표시':'전체 종목 수집 미완료';return result;
}
export function alertCandidates(s,previous={},now=Date.now()){return s?.metrics?.fullCoverage?baseCandidates(s,previous,now).filter(r=>r.entryStop&&r.signal!=='RED'):[];}
export {isStale,paceApi};

export {evaluateV82 as evaluateV83};
