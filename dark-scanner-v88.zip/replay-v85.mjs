import {readFileSync} from 'node:fs';
import {evaluateV82 as oldEval} from './server/stability-v84.mjs';
import {evaluateV82 as newEval} from './server/stability-v85.mjs';
import {gapEvidence} from './server/evidence-v85.mjs';
const folder=process.argv[2];const snap=JSON.parse(readFileSync(folder+'/latest.json')),cache=JSON.parse(readFileSync(folder+'/candles.json'));const out={total:snap.total,old:{valid:0,partial:0,invalid:0},next:{valid:0,partial:0,invalid:0},baselineMismatch:0,entryChanges:0,extraEvidence:0,changed:0};
const status=r=>r.tier==='U'?'invalid':r.dataStatus==='PARTIAL'?'partial':'valid';
for(const r of snap.results){const archive=cache.markets[r.symbol]||{},sets=Object.fromEntries(Object.entries(archive).map(([tf,bs])=>[tf,bs.filter(b=>b.end<=snap.slot).slice(-200)]));const meta=Object.fromEntries((r.dataHealth||[]).map(h=>[h.tf,{sourceFresh:h.sourceFresh,error:h.error,recovered:h.recovered,requests:h.requests,notes:h.notes}]));const ctx={marketWarning:r.marketWarning||'NONE',tickerMissing:r.turnover24h==null};const a=oldEval(r.symbol,sets,snap.startedAt,meta,ctx);const b=newEval(r.symbol,sets,snap.slot,meta,{...ctx,gapEvidence:gapEvidence(archive,sets,meta,snap.slot)});out.old[status(a)]++;out.next[status(b)]++;if(status(a)!==status(r)||a.tier!==r.tier||a.score!==r.score)out.baselineMismatch++;if(status(a)!==status(b))out.changed++;if(a.entryReady!==b.entryReady)out.entryChanges++;out.extraEvidence+=(b.dataHealth||[]).flatMap(h=>h.gaps).filter(g=>g.parent?.endsWith('-archive')).length;}
console.log(JSON.stringify(out,null,2));
