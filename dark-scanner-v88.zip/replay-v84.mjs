import {readFileSync} from 'node:fs';
import {diagnoseGaps} from './server/gaps-v84.mjs';
import {reconcileTape} from './server/flow-v84.mjs';
import {parseTradeRows} from './server/trade-api-v83.mjs';
import {evaluateV83} from './server/stability-v83.mjs';
const [dir]=process.argv.slice(2);const r=JSON.parse(readFileSync(dir+'/latest.json')),a=JSON.parse(readFileSync(dir+'/candles.json')),t=JSON.parse(readFileSync(dir+'/trade-diagnostics.json'));
const counts={},recent={},tape={};let verified=0,cvd=0;
for(const x of r.results){const d=diagnoseGaps(x.dataHealth,a.markets[x.symbol],r.startedAt);for(const g of d){counts[g.reason]=(counts[g.reason]||0)+1;if(g.recent)recent[g.reason]=(recent[g.reason]||0)+1;}}
for(const x of t.samples){const rows=parseTradeRows(x.raw),bs=a.markets[x.market]['15m'].filter(b=>b.end<=r.slot).slice(-4);const z=reconcileTape(bs,rows,x.market);if(z.status==='VERIFIED'){verified++;if(z.cvd1h)cvd++;}else tape[z.reason]=(tape[z.reason]||0)+1;}
console.log(JSON.stringify({counts,recent,firstPageTape:{samples:t.samples.length,verified,cvd,unverified:tape}},null,2));
