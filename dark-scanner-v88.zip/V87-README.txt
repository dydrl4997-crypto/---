V8.7 — trade gap diagnostics (no trading strategy changes)
- Same ID at the same timestamp is permitted within one page; multiplicity is preserved, including identical rows. Different timestamps for the same ID remain rejected.
- Cross-page overlap by ID or timestamp, reverse ordering, malformed rows and repeated cursors are not stitched. No absence is promoted into verified no-trade, no synthetic candles and no entry-grade change.
- Positive evidence stops pagination early; observed counts are not complete trade totals. Original candidate tape reconciliation (flow-v84) is unchanged.
- Up to 4 MiB of additional cursor responses captured separately; first-page sample cap unchanged. Not exhaustive.
- Replay from V8.6 first-page samples: 69 markets, 33,817 rows, 4,946 ID repeats, 44 identical normalized-row repeats. 68 UNVERIFIED + 1 LAST_TRADE_BEFORE_GAP_HINT -> 60 LAST_TRADE_BEFORE_GAP_HINT + 9 NO_TRADE_BRACKETED_HINT. No candle recovery or fresh API verification implied.
- Replay: node replay-v86-to-v87.mjs path/to/trade-diagnostics.json path/to/gap-diagnostics.json
- Test: node tests/run-all.mjs (Node 22)
- GitHub: upload dark-scanner-v87.zip OR byte-identical dark-scanner-v87.txt at repository root; upload dark-v87-test.yml under .github/workflows; run Dark Scanner V87 Trade Evidence Test. Workflow accepts either extension, prefers ZIP if both exist. Download dark-v87-results artifact.
