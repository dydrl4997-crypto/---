import {parseTradeRows} from './server/trade-api-v83.mjs';
import {readFileSync} from 'node:fs';
import {summarizePolicy,latestGap} from './server/gap-policy-v88.mjs';
import {gapTape} from './server/repair-v87.mjs';
const [latest,candles,trades]=process.argv.slice(2).map(p=>JSON.parse(readFileSync(p,'utf8')));
const counts={},allGaps={},replay={};let blocked=0,latestMissing=0,checked=0;
const samples=new Map(trades.samples.map(x=>[x.market,x]));
for(const r of latest.results){const g=latestGap(r),e={};if(g){latestMissing++;const sample=samples.get(r.symbol);if(sample){const t=await gapTape(async()=>parseTradeRows(sample.raw),r.symbol,g,latest.slot,1);e['15m|'+g.time]={...t,tf:'15m',time:g.time,end:g.end};checked++;replay[t.status]=(replay[t.status]||0)+1;}}
 const policy=summarizePolicy(r,candles.markets[r.symbol],e);counts[policy.latest15m]=(counts[policy.latest15m]||0)+1;for(const [k,v] of Object.entries(policy.counts))allGaps[k]=(allGaps[k]||0)+v;if(policy.entryExcluded&&!r.entryReady)blocked++;if(policy.entryExcluded&&r.entryReady)throw Error('unexpected entry');}
console.log(JSON.stringify({markets:latest.results.length,latestMissing,rawSamplesForLatest:checked,rawReplay:replay,latestPolicy:counts,gaps:allGaps,blocked,notes:'Saved raw first pages and archive only; no new 1m query or live verification. No grade changes.'},null,2));
