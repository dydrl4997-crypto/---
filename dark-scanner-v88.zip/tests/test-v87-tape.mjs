import assert from 'node:assert/strict';
import {gapTape} from '../server/repair-v87.mjs';
const m='KRW-TEST',g={time:1000,end:2000};
const t=(ts,id,p=100,q=1)=>({market:m,timestamp:ts,sequential_id:String(id),trade_price:p,trade_volume:q,ask_bid:'BID'});
const run=(rows)=>gapTape(async()=>rows,m,g,2000,1);
let r=await run([t(1500,9),t(1500,9,101),t(1500,9,101),t(900,8)]);assert.equal(r.status,'TRADES_PRESENT');assert.equal(r.inside,3);assert.equal(r.idRepeats,2);assert.equal(r.identicalRows,1);assert.equal(r.observationOnly,true);
r=await run([t(2100,9),t(2100,9,101),t(900,8)]);assert.equal(r.status,'NO_TRADE_BRACKETED_HINT');
assert.equal((await run([t(2100,9),t(900,9)])).status,'UNVERIFIED');
assert.equal((await run([t(900,8),t(2100,9)])).status,'UNVERIFIED');
assert.equal((await run([{...t(1500,9),market:'KRW-OTHER'}])).status,'UNVERIFIED');
assert.equal((await run([t(900,8)])).status,'LAST_TRADE_BEFORE_GAP_HINT');
const page=Array.from({length:500},(_,i)=>t(4000-i,4000-i));
const fetch=async(p,a)=>a.cursor?[t(3500,3500),t(900,8)]:page;
r=await gapTape(fetch,m,g,2000);assert.equal(r.status,'NO_TRADE_BRACKETED_HINT');assert.equal(r.pages,2);
for(const bad of [[page.at(-1),t(900,8)],[t(3501,999),t(900,8)],[t(3500,4000),t(900,8)]]){r=await gapTape(async(p,a)=>a.cursor?bad:page,m,g,2000);assert.equal(r.status,'UNVERIFIED');}
console.log('PASS v8.7 repeated ID, identical row preservation, reverse chronology, cursor boundary, no-trade hints only');
