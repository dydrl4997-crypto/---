# v7.8 서버 자동 검색 (배포 전 시험판)

## 변경사항
- 기존 v7.7 verified fixes의 engine.mjs 및 전략, 점수, 패턴은 그대로. 실제 기존 엔진은 A>=85, B>=60 기반이며 별도 ChatGPT 알림의 A80/B65와 차이가 있다. 이번에는 임의로 수정하지 않았다.
- 공통 후보 선정 함수, 15/30/60/240분봉 최신성·정렬·중복·누락 검사. 거래가 없어 봉이 생성되지 않은 경우도 보수적으로 U 처리한다. 기존 30분 참고 판정에 앞서 수집 무결성을 검사하므로 실제 검색 대상이 줄 수 있다. 백테스트 필요.
- Netlify 예약 함수 scan-schedule (UTC 매시 01,16,31,46분; KST도 동일 분), 인증된 scan-worker 백그라운드 함수 호출, Blobs 결과 저장, 읽기 전용 scan-results API, 웹 화면 결과 불러오기 및 1분 상태 갱신.
- 서버 기본 검색은 원래 기본 후보 풀(전체 원화 코인이 아닌 거래대금 기준 선별)이며 SCAN_SCOPE=broad로 확대 가능. 자동 검색과 수동 검색의 경고 입력/범위/시점 차이로 결과 차이가 가능하다.
- 매수 후보 알림은 새로운 A 또는 B 진입 임박 중 최대 5개/회, Telegram 선택 방식. 포지션 매도 감시와 ChatGPT 앱 자체 푸시는 미연결. 뉴스/입금량 경보 별도 확인. 매매 기능 없음.
- 오류/오래된 결과는 매매 알림 차단, 검색 결과가 없다는 뜻이 아니다. 슬롯별 원자적 claim으로 중복 실행 방지. 한 슬롯 내 실패 시 자동 재시도 없이 다음 슬롯을 기다리는 보수적 설계. 발송 성공 후 저장 실패 등 극단적 장애에서는 중복 또는 누락 가능.

## 배포 (기존 사이트 유지, 단순 ZIP 드롭 방식 아님)
1. ZIP 해제. 이 README, package.json, netlify.toml이 있는 폴더를 Git 저장소의 루트에 올려 기존 Netlify 사이트에 연결한다. 공개 Git 저장소를 쓰지 않아도 된다. Netlify에서 Git 연동 build/deploy를 사용한다. Node 22 권장. Build command `npm run build`, publish `dist`, functions `netlify/functions`는 toml로 지정되어 있다. 정적 파일 드롭만으로는 예약/백그라운드 함수 및 Blobs 연동을 보장하지 못한다.
2. Netlify 환경 변수 (Functions scope 및 production): `SCAN_SECRET` 무작위 32자 이상 (예: 로컬에서 `openssl rand -hex 32` 생성), 선택 `SCAN_SCOPE`=`broad`, 선택 `SCAN_WARNINGS`=`ELSA,KRW-OTHER` (실제 경고 종목에만). 비밀은 소스/대화/공개 웹에 넣지 않는다. 예약 함수는 Netlify의 URL 환경 변수 또는 context.site.url을 사용한다.
3. 첫 배포는 Telegram 설정 없이 실시. Functions 페이지에서 scan-schedule Scheduled 표시 확인 후 Run now 실행. scan-worker 및 Blobs 로그 확인. 실제 15분 경계 이후 첫 정기 검색 완료까지 확인한다.
4. 홈페이지 `서버 자동 검색` 영역과 `https://<실제사이트>/.netlify/functions/scan-results` JSON을 확인한다. status=OK 또는 PARTIAL, stale=false, valid>0, candleEnds 및 finishedAt 검증. 실패는 FAILED/STALE/NOT_RUN으로 처리한다. API는 공개 시장 검색 결과만 제공하며 개인 계좌 데이터/비밀은 넣지 않는다. 공개 API가 다크의 대화 환경에서 접근 가능한지는 별도 테스트 필요.
5. 선택 Telegram: 공식 BotFather에서 봇 생성, 본인이 먼저 봇에 메시지를 보낸 후 chat ID 확인. Netlify 환경변수에 `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`를 Functions scope에 저장(채팅에 공유하지 않기). 새 조건 충족 시 알림이 발생하므로 테스트 후보가 없으면 실제 알림은 발송되지 않는다. 실수신을 확인하기 전 매매에 의존하지 않는다.
6. 최소 연속 4회 정상 실행 확인, 비용/호출량과 검색 소요시간 확인. 하루 96회, 최대 수백 API 호출/회 가능. Netlify 예약 함수 30초 제한과 백그라운드 최대 15분 제한을 고려해 작업 시간 10분 및 슬롯 경계 차단을 둠. 호출률/계정 플랜/비용은 실제 확인 필요. 외부에서 무인 실행되며 ChatGPT 자동화의 15분 실행 한도를 우회하는 것이 아니라 독립 서비스다.

## 로컬 검증
`npm test` : 12개 테스트 파일 통과 (기존 11 + 신규 1). 신규는 모의 시세/봉으로 서버-기존 엔진 점수 일치, 최신성/누락/중복 차단, 데이터 실패 알림 차단, 후보 중복 억제, 예약 함수 호출 모의 및 Telegram 모의 응답. `npm run build` 통과; 모든 JS 모듈 node --check 통과. 실제 Blobs 저장, 배포, upstream Bithumb, Telegram 실수신 및 50코인 백테스트는 미검증. 현재 개발 환경 DNS 오류로 npm 의존성 설치도 못 했으므로 Netlify 빌드에서 확인 필요. Netlify 계정 접근/배포 권한 없음. 기존 ChatGPT 예약 알림 설정 변경 없음.
