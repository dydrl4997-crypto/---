import {boundary,kstString,inspectBars} from '../js/data-health.mjs';
import {closedBars} from '../js/api.mjs';
// Completed exchange-wide maintenance notice 1655738; only fully contained slots
// are tagged maintenance. Edge slots and any other gap remain unknown.
export const maintenance=[{start:Date.parse('2026-11-23T01:00:00+09:00'),end:Date.parse('2026-11-23T07:30:00+09:00'),source:'https://m-feed.bithumb.com/notice/1655738'}];
const known=(a,b)=>maintenance.some(m=>a>=m.start&&b<=m.end);
const fields=['open','close','high','low','volume','turnover'];
const same=(a,b)=>fields.every(k=>Math.abs(a[k]-b[k])<=1e-9*Math.max(1,Math.abs(a[k]),Math.abs(b[k])));
const minsRequired={'15m':70,'30m':35,'1h':180,'4h':46};
// Observation requires the newest local structure to be continuous. This is a
// data quality gate only; the original engine still needs its full bar counts.
const recentRequired={'15m':70,'30m':35,'1h':49,'4h':3};
function decode(raw,market,unit,now){
 if(!Array.isArray(raw)||!raw.length)throw Error('봉 응답 없음');
 for(const r of raw){if((r.market!==undefined&&r.market!==market)||(r.unit!==undefined&&Number(r.unit)!==unit)||['opening_price','trade_price','high_price','low_price','candle_acc_trade_volume','candle_acc_trade_price'].some(k=>r[k]===null||r[k]===undefined||r[k]===''||!Number.isFinite(Number(r[k])))||Number(r.candle_acc_trade_volume)<0||Number(r.candle_acc_trade_price)<0||!Number.isFinite(Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z')))throw Error('봉 응답 필드 오류');}
 const bars=closedBars(raw,unit,now);inspectBars(bars,unit,now);return bars;
}
function merge(map,b){const a=map.get(b.time);if(a&&!same(a,b))throw Error('동일 확정봉 교차조회 값 불일치');if(!a)map.set(b.time,b);return !a;}
const ordered=map=>[...map.values()].sort((a,b)=>a.time-b.time);
export function aggregateExact(bars,start,unit,lower){
 const step=lower*60000,n=unit/lower;
 const selected=bars.filter(b=>b.time>=start&&b.time<start+unit*60000);
 if(!Number.isInteger(n)||selected.length!==n||selected.some((b,i)=>b.time!==start+i*step||b.end!==b.time+step))return null;
 return {time:start,end:start+unit*60000,open:selected[0].open,close:selected.at(-1).close,high:Math.max(...selected.map(b=>b.high)),low:Math.min(...selected.map(b=>b.low)),volume:selected.reduce((s,b)=>s+b.volume,0),turnover:selected.reduce((s,b)=>s+b.turnover,0)};
}
function holes(bars,unit,now){const step=unit*60000,h=inspectBars(bars,unit,now);const missing=[];for(const g of [...h.gaps,{start:h.latest,end:h.expected}]){if((g.end-g.start)/step>10000)throw Error('비정상 캔들 간격');for(let t=g.start;t<g.end;t+=step)missing.push(t);}return missing;}
export async function recoverFrame({api,market,tf,unit,now,wait=async()=>{},cached=[]}){
 const step=unit*60000,end=boundary(now,unit),report={tf,expected:end,retried:0,recovered:0,cacheRecovered:0,aggregated:0,maintenance:0,unknown:0,legacy:'미조회',notes:[]};
 const request=async(u,to,count)=>{const r=await api('v1/candles/minutes/'+u,{market,to:kstString(to),count});await wait(150);if(!Array.isArray(r)||r.length>count||r.some(x=>Date.parse((x.candle_date_time_utc||'').replace(' ','T')+'Z')>=to))throw Error('조회 시간/개수 불일치');return decode(r,market,u,now);};
 const initial=await request(unit,end,200);const map=new Map(initial.map(b=>[b.time,b]));
 // Optional trusted local archive (same market/frame, actual closed candles only).
 if(cached.length){inspectBars(cached,unit,now);for(const b of cached)if(b.time>=initial[0].time&&b.end<=end&&merge(map,b)){report.cacheRecovered++;report.recovered++;}}
 const missing=()=>holes(ordered(map),unit,now);
 // Bounded recovery: two most recent unknown slots per timeframe; maintenance
 // slots have no original trade guarantee, so do not spend retries on them.
 const targets=missing().filter(t=>!known(t,t+step)).slice(-2).reverse();
 for(const t of targets){
  if(map.has(t))continue;report.retried++;
  let retry;try{retry=await request(unit,t+step,4);}catch(e){report.notes.push('재조회: '+e.message);}
  if(retry){for(const b of retry)if(b.time>=initial[0].time&&b.end<=end&&merge(map,b))report.recovered++;}
  if(map.has(t))continue;
  const lower=unit===15?5:unit===30?15:unit===60?15:60;
  let lowerBars;try{lowerBars=await request(lower,t+step,unit/lower);}catch(e){report.notes.push('하위봉: '+e.message);}
  if(lowerBars){const b=aggregateExact(lowerBars,t,unit,lower);if(b&&merge(map,b)){report.aggregated++;report.recovered++;}}
 }
 let bars=ordered(map).slice(-200);const remaining=holes(bars,unit,now);report.maintenance=remaining.filter(t=>known(t,t+step)).length;report.unknown=remaining.length-report.maintenance;
 report.gaps=remaining.map(t=>({time:t,kind:known(t,t+step)?'MAINTENANCE':'UNKNOWN'}));
 // Old API has no turnover, and possibly different grids. It can corroborate
 // an unresolved slot only; never substitute approximate turnover or OHLCV.
 if(report.unknown&&typeof api.legacy==='function'){
  try{const data=await api.legacy(market,tf==='60m'?'1h':tf);const target=remaining.filter(t=>!known(t,t+step)).at(-1);report.legacy=data.some(r=>Number(r[0])===target)?'보조 API 봉 존재 (거래대금 없음, 미복구)':'보조 API 대상 시각 미발견';await wait(150);}catch(e){report.legacy='보조 API 조회 실패';}
 }
 if(bars.at(-1).end!==end)throw Error(tf+' 최신 확정봉 미수신');
 if(bars.length<minsRequired[tf])throw Error(tf+' 확정봉 수 부족');
 let tail=1;for(let i=bars.length-1;i>0&&bars[i].time===bars[i-1].end;i--)tail++;
 report.contiguousRecent=tail;report.count=bars.length;
 if(tail<recentRequired[tf])throw Error(tf+' 최근 핵심 봉 누락 (연속 '+tail+'봉)');
 report.status=remaining.length?'PARTIAL':report.recovered?'RECOVERED':'OK';
 return {bars,report};
}
export function observationOnly(r,health){
 if(r.tier==='U'||!health.some(x=>x.status==='PARTIAL'))return r;
 // Do not treat gapped historical indicator windows as verified. Preserve raw
 // output only as diagnostic; no green / imminent signal on partial data.
 return {...r,diagnosticTier:r.tier,diagnosticScore:r.score,score:Math.min(r.score??0,r.tier==='C'?59:84),tier:r.tier==='C'?'C':'B',phase:r.tier==='C'?'제외/보류':'형성 중',signal:r.signal==='RED'||r.tier==='C'?'RED':'YELLOW',entryReady:false,safe:false,entryState:'부분 검증 · 진입 보류',entryStop:null,entryRR:null,reason:'과거 봉 누락 — 관찰 전용 / '+r.reason,signalReasons:[...(r.signalReasons||[]),'과거 봉 누락: A급·진입 임박 차단']};
}
