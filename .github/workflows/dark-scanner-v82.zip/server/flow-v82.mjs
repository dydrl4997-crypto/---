// Only complete tape reconciled against the actual closed candle is reported.
const near=(a,b)=>Math.abs(a-b)<=Math.max(Math.abs(a),Math.abs(b),1e-12)*1e-7;
export function candleFlow(bars){
 const b=bars?.at(-1);if(!b)return null;
 const range=b.high-b.low,body=Math.abs(b.close-b.open),lower=Math.min(b.open,b.close)-b.low,upper=b.high-Math.max(b.open,b.close);
 const contiguous=bars.length>=21&&bars.slice(-21).every((x,i,a)=>!i||x.time===a[i-1].end);
 const sample=bars.slice(-20),prev=bars.slice(-21,-1),avg=prev.reduce((s,x)=>s+x.turnover,0)/Math.max(1,prev.length);
 const total=sample.reduce((s,x)=>s+x.volume,0),cmf=sample.reduce((s,x)=>s+(x.high>x.low?(2*x.close-x.high-x.low)/(x.high-x.low):0)*x.volume,0);
 const obvChange=sample.slice(1).reduce((s,x,i)=>s+Math.sign(x.close-sample[i].close)*x.volume,0);
 return {lowerWickBull:range>0&&b.close>b.open&&lower>=body*1.5&&lower/range>=.4&&upper/range<=.25,upperWickBull:range>0&&b.close>b.open&&upper/range>=.4,relativeTurnover:contiguous&&avg>0?b.turnover/avg:null,obvChange:contiguous?obvChange:null,cmf20:contiguous&&total>0?cmf/total:null,indicatorBasis:contiguous?'20개 실제 연속 확정봉':'연속성 부족'};
}
export function reconcileTape(bars,ticks,market){
 const seen=new Set(),valid=[];
 for(const t of ticks){const id=t.sequential_id,ts=Number(t.timestamp),p=Number(t.trade_price),q=Number(t.trade_volume);if(id==null||typeof id==='number'&&!Number.isSafeInteger(id)||t.market!==market||!Number.isFinite(ts)||!(p>0&&q>0)||!['BID','ASK'].includes(t.ask_bid))return {status:'UNVERIFIED',reason:'체결 필드 오류'};if(seen.has(String(id)))return {status:'UNVERIFIED',reason:'체결 ID 중복'};seen.add(String(id));valid.push({ts,p,q,side:t.ask_bid});}
 const rows=bars.map(b=>{const tape=valid.filter(t=>t.ts>=b.time&&t.ts<b.end);let buy=0,sell=0,bv=0,sv=0;for(const t of tape){if(t.side==='BID'){buy+=t.p*t.q;bv+=t.q;}else{sell+=t.p*t.q;sv+=t.q;}}
  const complete=tape.length>0&&near(bv+sv,b.volume)&&near(buy+sell,b.turnover)&&near(Math.min(...tape.map(t=>t.p)),b.low)&&near(Math.max(...tape.map(t=>t.p)),b.high);
  return complete?{end:b.end,complete,buyTurnover:buy,sellTurnover:sell,buyShare:buy/(buy+sell),turnoverStrength:sell>0?buy/sell*100:null,deltaVolume:bv-sv,trades:tape.length}:{end:b.end,complete:false,trades:tape.length};});
 const last=rows.at(-1);if(!last?.complete)return {status:'UNVERIFIED',reason:'15분봉 거래량·거래대금·고저가 미일치 / 체결 범위 부족',rows};
 let cvd=null;if(rows.length===4&&rows.every((r,i)=>r.complete&&(!i||r.end-rows[i-1].end===900000))){let v=0;cvd=rows.map(r=>v+=r.deltaVolume);}
 return {status:'VERIFIED',...last,cvd1h:cvd,rows};
}
export async function fetchFlow(api,market,bars,guard,maxPages=3){
 const target=bars.slice(-4),ticks=[];let cursor, pages=0;
 try{for(;pages<maxPages;){guard();const rows=await api('v1/trades/ticks',{market,count:500,...(cursor?{cursor}:{})});pages++;if(!Array.isArray(rows)||rows.length>500)throw Error('체결 응답 형식');if(!rows.length)break;ticks.push(...rows);const r=reconcileTape(target,ticks,market);if(r.cvd1h||Math.min(...rows.map(t=>Number(t.timestamp)))<=target[0].time||rows.length<500)break;const next=rows.at(-1)?.sequential_id;if(next==null||String(next)===String(cursor)||typeof next==='number'&&!Number.isSafeInteger(next))break;cursor=String(next);}
 return {...reconcileTape(target,ticks,market),pages};}catch(e){return {status:'UNVERIFIED',reason:e.message,pages};}
}
export function flowInterpretation(c,tape,prev){if(tape.status!=='VERIFIED')return '체결 미확인';if(c?.lowerWickBull&&tape.buyShare<.5)return '매도 물량 흡수 가능성(추정)';if(tape.buyShare>.6&&c?.relativeTurnover>=1.2)return '매수 주도 거래대금 확대(추정)';if(c?.upperWickBull)return '고점 매도 압력 주의';return '뚜렷한 체결 근거 부족';}
