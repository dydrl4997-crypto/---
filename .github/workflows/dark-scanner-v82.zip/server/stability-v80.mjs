import {units,boundary,kstString,inspectBars} from '../js/data-health.mjs';
import {closedBars} from '../js/api.mjs';
import {aggregateExact,maintenance} from './recovery.mjs';
import {analyzeSymbol} from '../js/engine.mjs';
import {determineUniverse} from '../js/universe.mjs';
import {makeApi,slotOf,isStale,alertCandidates} from './scan.mjs';
const DAY=86400000, fields=['open','high','low','close','volume','turnover'];
const approx=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-9*Math.max(Math.abs(a),Math.abs(b),1e-12);
const same=(a,b)=>fields.every(k=>approx(a[k],b[k]));
const known=(t,u)=>maintenance.some(m=>t>=m.start&&t+u*60000<=m.end);
const min={'15m':70,'30m':35,'1h':180,'4h':46};
const sorted=m=>[...m.values()].sort((a,b)=>a.time-b.time);
const safeBars=(bars,u,now)=>{if(bars.length)inspectBars(bars,u,now);return bars;};
function rawBars(raw,market,u,to,count,now){
 if(!Array.isArray(raw)||raw.length>count)throw Error('응답 개수/형식 오류');
 for(const r of raw){if((r.market!==undefined&&r.market!==market)||(r.unit!==undefined&&Number(r.unit)!==u)||['opening_price','trade_price','high_price','low_price','candle_acc_trade_volume','candle_acc_trade_price'].some(k=>r[k]==null||r[k]===''||!Number.isFinite(Number(r[k])))||!Number.isFinite(Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z'))||Date.parse((r.candle_date_time_utc||'').replace(' ','T')+'Z')>=to)throw Error('응답 필드/시각 오류');}
 const bars=closedBars(raw,u,now);if(bars.length!==raw.length)throw Error('미확정/형식 오류');return safeBars(bars,u,now);
}
function missing(bars,u,now){const step=u*60000,end=boundary(now,u);if(!bars.length)return [];let gaps=[];for(let i=1;i<=bars.length;i++){let a=bars[i-1].end,b=i===bars.length?end:bars[i].time;if(b-a>2000*step){gaps.push({time:a,end:b,large:true});continue;}for(let t=a;t<b;t+=step)gaps.push({time:t,end:t+step});}return gaps;}
function recentCount(bars,u,now){const end=boundary(now,u);return bars.filter(b=>b.time>=end-DAY&&b.end<=end).length;}
function tail(bars){let n=bars.length?1:0;for(let i=bars.length-1;i>0&&bars[i].time===bars[i-1].end;i--)n++;return n;}
// Positive-volume parent and all available child bars must reconcile in OHLCV AND turnover.
// This corroborates a no-trade interval; it is not independent exchange trade tape proof.
export function corroborateNoTrade(gap,tf,sets){const u=units[tf];if(u===240||gap.large)return false;
 for(const [parent,pu] of Object.entries(units)){
  if(pu<=u||pu%u)continue;const start=boundary(gap.time,pu),p=sets[parent]?.find(b=>b.time===start);if(!p||p.end!==start+pu*60000||gap.end>p.end||p.volume<=0||p.turnover<=0)continue;
  const bs=(sets[tf]||[]).filter(b=>b.time>=start&&b.end<=p.end);if(!bs.length||bs.some(b=>b.volume<=0||b.turnover<=0))continue;
  const a={open:bs[0].open,close:bs.at(-1).close,high:Math.max(...bs.map(b=>b.high)),low:Math.min(...bs.map(b=>b.low)),volume:bs.reduce((s,b)=>s+b.volume,0),turnover:bs.reduce((s,b)=>s+b.turnover,0)};
  if(same(a,p))return true;
 }return false;
}
export function assessFrames(sets,now,meta={}){
 const health={},verifiedSets={};for(const [tf,u] of Object.entries(units)){const bars=sets[tf]||[];try{if(!meta[tf]?.error&&meta[tf]?.sourceFresh!==false&&bars.length){safeBars(bars,u,now);verifiedSets[tf]=bars;}}catch{}}
 for(const [tf,u] of Object.entries(units)){
  const bars=sets[tf]||[],end=boundary(now,u);let error=meta[tf]?.error||null;
  try{safeBars(bars,u,now);}catch(e){error=e.message;}
  const gaps=error?[]:missing(bars,u,now).map(g=>({...g,kind:g.large?'UNKNOWN':known(g.time,u)?'MAINTENANCE':corroborateNoTrade(g,tf,verifiedSets)?'NO_TRADE_SUPPORTED':'UNKNOWN'}));
  const recentGaps=gaps.filter(g=>g.end>end-DAY),latest=bars.at(-1)?.end===end;
  const recentComplete=latest&&recentCount(bars,u,now)===DAY/(u*60000)&&!recentGaps.length;
  const oldUnknown=gaps.filter(g=>g.end<=end-DAY&&g.kind==='UNKNOWN').length;
  const count=bars.length,usable=!error&&latest&&count>=min[tf];
  health[tf]={tf,count,latest,expected:end,contiguousRecent:tail(bars),recentComplete,recentGaps:recentGaps.length,oldUnknown,gaps,error,usable,recovered:meta[tf]?.recovered||0,sourceFresh:meta[tf]?.sourceFresh!==false,requests:meta[tf]?.requests||0,notes:meta[tf]?.notes||[]};
 }
 return health;
}
export function evaluateV80(symbol,sets,now,meta={},context={},analyze=analyzeSymbol){
 const health=assessFrames(sets,now,meta),core=['15m','1h','4h'];const fatal=core.filter(tf=>!health[tf].usable);
 const base={symbol,dataHealth:Object.values(health),candleEnds:Object.fromEntries(Object.entries(sets).filter(([,v])=>v.length).map(([k,v])=>[k,v.at(-1).end]))};
 if(fatal.length)return {...base,tier:'U',score:0,signal:'GRAY',entryState:'데이터 미검증',entryReady:false,safe:false,dataStatus:'INVALID',reason:'핵심 봉 부족/오류: '+fatal.map(tf=>tf+' '+(health[tf].error||'최신성/봉 수 부족')).join(', ')};
 // Original engine uses 4h in scoring and divergence even outside rebounds. Do not silently remove it.
 const input={...sets};const h30=health['30m'];if(!h30.usable||!h30.recentComplete||h30.oldUnknown||!h30.sourceFresh)delete input['30m'];
 const r=analyze(symbol,input,context);const blocks=[];
 for(const tf of core){const h=health[tf];if(!h.recentComplete)blocks.push(tf+' 최근 24시간 공백/부족');if(h.oldUnknown)blocks.push(tf+' 과거 원인 미확인 공백');if(!h.sourceFresh)blocks.push(tf+' 이번 API 미검증');}
 // Structure/volume lookback is 49 hourly bars; four-hour rebound lookback is 18 bars.
 // A known gap inside these price structure windows still blocks entry.
 if(health['1h'].contiguousRecent<49)blocks.push('1시간 구조·거래량 49봉 연속성 부족');
 if(/반등/.test(r.strategy||'')&&health['4h'].contiguousRecent<18)blocks.push('반등 4시간 저점/거래량 18봉 연속성 부족');
 if(/변동성 확대/.test(r.strategy||'')){const m=sets['15m'];const day=boundary(m.at(-1).end-1,1440);const first=day-DAY;const last=m.at(-1).end;const selected=m.filter(b=>b.time>=first);if(selected.length!==(last-first)/900000||selected.some((b,i)=>b.time!==first+i*900000))blocks.push('전일·금일 변동성 비교 시간 공백');}
 const warnings=[];if(!input['30m'])warnings.push('30분 참고 미검증(독립 차단 없음)');
 for(const tf of core){const h=health[tf];if(h.gaps.length&&!h.oldUnknown&&h.recentComplete)warnings.push(tf+' 과거 점검/미체결 추정 공백: 실제 체결 봉 기준 지표');}
 if(r.tier==='U')return {...r,...base,dataStatus:'INVALID',dataWarnings:warnings};
 if(blocks.length)return {...r,...base,diagnosticTier:r.tier,diagnosticScore:r.score,tier:r.tier==='A'?'B':r.tier,score:r.tier==='A'?Math.min(79,r.score):r.score,phase:r.tier==='C'?'제외/보류':'형성 중',signal:r.signal==='RED'?'RED':r.tier==='C'?'RED':'YELLOW',entryReady:false,safe:false,entryState:'부분 검증 · 진입 보류',entryStop:null,entryRR:null,dataStatus:'PARTIAL',dataWarnings:[...warnings,...blocks],reason:[r.reason,...blocks].join(' / '),signalReasons:[...(r.signalReasons||[]),...blocks]};
 return {...r,...base,dataStatus:warnings.length?'QUALIFIED':Object.values(health).some(h=>h.recovered)?'RECOVERED':'OK',dataWarnings:warnings};
}
export async function collectFrame({api,market,tf,now,cached=[],wait=async()=>{},guard=()=>{}}){
 const u=units[tf],end=boundary(now,u),step=u*60000,meta={sourceFresh:false,recovered:0,requests:0,notes:[]};let map=new Map();
 try{safeBars(cached,u,now);map=new Map(cached.map(b=>[b.time,b]));}catch(e){meta.notes.push('백업 오류: '+e.message);}
 const request=async(unit,to,count)=>{guard();meta.requests++;return rawBars(await api('v1/candles/minutes/'+unit,{market,to:kstString(to),count}),market,unit,to,count,now);};
 const merge=bs=>{for(const b of bs){const p=map.get(b.time);if(p&&!same(p,b))throw Error('동일 확정봉 백업/재조회 불일치');}for(const b of bs)map.set(b.time,b);};
 try{
  const cacheWindow=sorted(map).filter(b=>b.end<=end).slice(-200);const incremental=cacheWindow.length>=200&&end-cacheWindow.at(-1).end<=12*step;
  let fresh;try{fresh=await request(u,end,incremental?16:200);}catch(e){await wait(400);fresh=await request(u,end,200);}
  if(!fresh.length)throw Error('빈 응답');merge(fresh);meta.sourceFresh=true;
  const initial=sorted(map).slice(-200),gaps=missing(initial,u,now).filter(g=>!g.large);
  // One recent target and one rotating older target, including maintenance. Old holes are revisited on later slots.
  const recent=gaps.filter(g=>g.end>end-DAY),older=gaps.filter(g=>g.end<=end-DAY);
  const olderPick=older.length?older[Math.floor(now/900000)%older.length]:null;
  const targets=[recent.at(-1),olderPick||recent.at(-2)].filter(Boolean);
  for(const g of targets){if(map.has(g.time))continue;
   try{const bs=await request(u,g.end,8);const had=map.has(g.time);merge(bs);if(!had&&map.has(g.time))meta.recovered++;}catch(e){if(/불일치/.test(e.message))throw e;meta.notes.push('재조회: '+e.message);}
   if(map.has(g.time)||known(g.time,u))continue;
   const lower=u===15?5:u===30?15:u===60?15:60;
   try{const bs=await request(lower,g.end,u/lower);const b=aggregateExact(bs,g.time,u,lower);if(b){merge([b]);meta.recovered++;}}catch(e){if(/불일치/.test(e.message))throw e;meta.notes.push('하위봉: '+e.message);}
  }
  const unresolved=targets.find(g=>!known(g.time,u)&&!map.has(g.time));
  if(unresolved&&typeof api.legacy==='function'){try{guard();meta.requests++;const legacy=await api.legacy(market,tf);meta.notes.push(legacy.some(b=>Number(b[0])===unresolved.time)?'보조 API 봉 확인: 거래대금 미제공으로 교체 금지':'보조 API 대상 봉 미확인');}catch(e){meta.notes.push('보조 API 조회 실패: '+e.message);}}
 }catch(e){meta.error=e.message;meta.sourceFresh=false;}
 const archive=sorted(map).filter(b=>b.end>=end-30*DAY).slice(-3000);return {bars:archive.slice(-200),archive,meta};
}
export function paceApi(api,wait=ms=>new Promise(r=>setTimeout(r,ms)),interval=150){let chain=Promise.resolve();let next=0;const wrap=fn=>async(...args)=>{const gate=chain.then(async()=>{await wait(Math.max(0,next-Date.now()));next=Date.now()+interval;});chain=gate.catch(()=>{});await gate;return fn(...args);};const paced=wrap(api);if(typeof api.legacy==='function')paced.legacy=wrap(api.legacy);return paced;}
export async function scanV80({api=makeApi(),now=Date.now,wait=ms=>new Promise(r=>setTimeout(r,ms)),scope='rise',cache={},archive={},analyze=analyzeSymbol}={}){
 const startedAt=now(),slot=slotOf(startedAt),result={version:'8.0',startedAt,slot,scope,marketCount:0,total:0,valid:0,partial:0,invalid:0,recovered:0,qualified:0,results:[],errors:[]};
 const guard=()=>{if(slotOf(now())!==slot||now()-startedAt>10*60000)throw Error('검색 시각 초과');};
 try{const markets=(await api('v1/market/all',{isDetails:'true'})).filter(m=>/^KRW-[A-Z0-9]+$/.test(m.market));result.marketCount=markets.length;if(!markets.length)throw Error('원화마켓 없음');const tickers=[];for(let i=0;i<markets.length;i+=45){guard();tickers.push(...await api('v1/ticker',{markets:markets.slice(i,i+45).map(m=>m.market).join(',')}));}const validTicker=new Set(tickers.filter(t=>Number.isFinite(Number(t.acc_trade_price_24h))&&Number.isFinite(Number(t.signed_change_rate))&&Number(t.trade_price)>0).map(t=>t.market));if(markets.some(m=>!validTicker.has(m.market)))throw Error('시세 누락');const universe=determineUniverse(markets,tickers,scope==='broad');result.total=universe.length;if(!universe.length)throw Error('검색 대상 없음');const by=new Map(markets.map(m=>[m.market,m]));let i=0;
 async function worker(){while(i<universe.length){const symbol=universe[i++];const sets={},meta={};archive[symbol]??={};for(const tf of Object.keys(units)){let f;try{guard();f=await collectFrame({api,market:symbol,tf,now:startedAt,cached:cache[symbol]?.[tf]||[],wait,guard});}catch(e){f={bars:[],archive:[],meta:{error:e.message,sourceFresh:false}};}sets[tf]=f.bars;meta[tf]=f.meta;if(f.archive.length)archive[symbol][tf]=f.archive;}
 let r;try{r=evaluateV80(symbol,sets,startedAt,meta,{marketWarning:by.get(symbol).market_warning||'NONE'},analyze);}catch(e){r={symbol,tier:'U',score:0,dataStatus:'INVALID',signal:'GRAY',reason:String(e.message)};}r.koreanName=by.get(symbol).korean_name||symbol;result.results.push(r);if(r.tier==='U')result.errors.push({symbol,reason:r.reason});}}
 await Promise.all([worker(),worker(),worker()]);
 }catch(e){result.message=e.message;result.status='FAILED';}
 result.valid=result.results.filter(r=>['OK','RECOVERED','QUALIFIED'].includes(r.dataStatus)&&r.tier!=='U').length;result.partial=result.results.filter(r=>r.dataStatus==='PARTIAL'&&r.tier!=='U').length;result.invalid=result.results.length-result.valid-result.partial;result.qualified=result.results.filter(r=>r.dataStatus==='QUALIFIED').length;result.recovered=result.results.filter(r=>r.dataHealth?.some(h=>h.recovered)).length;result.finishedAt=now();result.results.sort((a,b)=>({A:0,B:1,C:2,U:3}[a.tier]-{A:0,B:1,C:2,U:3}[b.tier])||b.score-a.score);
 if(slotOf(result.finishedAt)!==slot||result.finishedAt-startedAt>10*60000)result.status='STALE';else result.status=result.status||(!result.valid&&!result.partial?'FAILED':result.invalid||result.partial?'PARTIAL':'OK');result.message??=result.status==='OK'?'데이터 판정 완료':result.status==='PARTIAL'?'일부 관찰/미검증 — 진입 차단 유지':result.status==='STALE'?'검색 시간 초과 — 신호 차단':'검증 결과 없음';return result;
}
export {alertCandidates,isStale};
