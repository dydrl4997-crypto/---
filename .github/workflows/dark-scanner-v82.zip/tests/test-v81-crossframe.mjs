import assert from 'node:assert/strict';
import {units,boundary} from '../js/data-health.mjs';
import {evaluateV81,corroborateNoTrade,collectFrame,scanV81,alertCandidates} from '../server/stability-v81.mjs';
const now=Date.parse('2026-11-25T21:12:00+09:00'),market='KRW-TEST';
const bars=(u,n=200,end=boundary(now,u))=>Array.from({length:n},(_,i)=>({time:end-(n-i)*u*60000,end:end-(n-i-1)*u*60000,open:100,close:100,high:101,low:99,volume:u,turnover:u*100}));
const full=Object.fromEntries(Object.entries(units).map(([tf,u])=>[tf,bars(u)]));
const fake=(symbol,sets)=>({symbol,tier:'A',score:95,signal:'GREEN',strategy:'눌림목',phase:'진입 검토',entryReady:true,safe:true,entryStop:98,entryRR:2,price:100,reason:'test',thirtyVerified:!!sets['30m']});
function remove(tf,offset,adjust=true){const s=structuredClone(full),g=s[tf].splice(-offset,1)[0],u=units[tf];if(adjust)for(const [p,pu] of Object.entries(units)){if(pu<=u||pu%u)continue;const b=s[p].find(b=>b.time===boundary(g.time,pu));if(b){b.volume-=u;b.turnover-=u*100;}}return {s,g};}
const evaluate=(s,meta={},analyze=fake)=>evaluateV81(market,s,now,meta,{},analyze);
assert.equal(evaluate(full).dataStatus,'OK');
let {s,g}=remove('15m',35);const before=JSON.stringify(s);let r=evaluate(s);assert.equal(r.dataStatus,'QUALIFIED');assert.equal(r.tier,'A');assert.equal(r.dataHealth[0].recentSupported,1);assert.equal(r.dataHealth[0].gaps.find(x=>x.time===g.time).parent,'30m');assert.equal(JSON.stringify(s),before);assert.equal(s['15m'].length,199);
// Positive-volume mismatch cannot be disguised by a matching larger parent.
let parent=s['30m'].find(b=>b.time===boundary(g.time,30));parent.turnover++;assert.equal(corroborateNoTrade(g,'15m',s),null);assert.equal(evaluate(s).dataStatus,'PARTIAL');parent.turnover--;
// Fallback to a verified 1h candle only if the 30m parent is unavailable.
const pTime=parent.time;s['30m']=s['30m'].filter(b=>b.time!==pTime);assert.equal(corroborateNoTrade(g,'15m',s),'1h');assert.equal(evaluate(s).dataStatus,'QUALIFIED');
assert.equal(evaluate(s,{'1h':{sourceFresh:false},'4h':{sourceFresh:false}}).dataStatus,'PARTIAL');
// No evidence => no entry. Entry window must contain 25 genuine consecutive 15m bars.
({s,g}=remove('15m',35,false));r=evaluate(s);assert.equal(r.dataStatus,'PARTIAL');assert.equal(r.entryReady,false);assert.equal(r.tier,'B');
({s,g}=remove('15m',10));r=evaluate(s);assert.equal(r.dataStatus,'PARTIAL');assert.equal(r.dataHealth[0].recentSupported,1);assert.equal(r.entryReady,false);
({s,g}=remove('15m',1));assert.equal(evaluate(s).tier,'U');
({s,g}=remove('1h',30));assert.equal(evaluate(s).dataStatus,'PARTIAL');
({s,g}=remove('4h',12));assert.equal(evaluate(s,{},(a,b)=>({...fake(a,b),strategy:'기술적 반등'})).dataStatus,'PARTIAL');
s=structuredClone(full);s['15m'].at(-1).volume=0;s['15m'].at(-1).turnover=0;assert.equal(evaluate(s).entryReady,false);
// Same-day/previous-day calculation still requires real timeline and is not repaired by parent inference.
({s,g}=remove('15m',35));r=evaluate(s,{},(a,b)=>({...fake(a,b),strategy:'변동성 확대 · 급락 후 반등'}));assert.equal(r.entryReady,false);
// No leading coverage can masquerade as a complete 24h window.
s=structuredClone(full);s['15m']=s['15m'].slice(-70);assert.equal(evaluate(s).dataStatus,'PARTIAL');
// Real post-maintenance recovery, even if maintenance is outside the last 200 candles.
const old=Date.parse('2026-11-23T02:00:00+09:00');
const toRows=(u,to,count)=>bars(u,count,to).map(b=>({market,unit:u,candle_date_time_utc:new Date(b.time).toISOString().slice(0,-1),opening_price:b.open,trade_price:b.close,high_price:b.high,low_price:b.low,candle_acc_trade_volume:b.volume,candle_acc_trade_price:b.turnover}));
const api=async(p,a)=>toRows(Number(p.split('/').at(-1)),Date.parse(a.to+'+09:00'),a.count);
let maintenanceCache=bars(15,400).filter(b=>b.time!==old),calls=[];
let f=await collectFrame({api:async(p,a)=>{calls.push(a);return api(p,a);},market,tf:'15m',now,cached:maintenanceCache});assert.ok(calls.some(a=>Date.parse(a.to+'+09:00')===old+900000));assert.ok(f.archive.some(b=>b.time===old));assert.equal(f.meta.recovered,1);
// Try exact lower-candle reconstruction after maintenance if direct retry still lacks the slot.
f=await collectFrame({api:async(p,a)=>{const rows=await api(p,a);return p.endsWith('/15')?rows.filter(x=>Date.parse(x.candle_date_time_utc+'Z')!==old):rows;},market,tf:'15m',now,cached:maintenanceCache});assert.equal(f.meta.recovered,1);assert.ok(f.archive.some(b=>b.time===old));
// Outage never erases stored real data or emits an eligible entry.
f=await collectFrame({api:async()=>{throw Error('offline')},market,tf:'15m',now,cached:maintenanceCache});assert.equal(f.archive.length,maintenanceCache.length);assert.equal(f.meta.sourceFresh,false);
const mixed=async(p,a)=>p==='v1/market/all'?[{market},{market:'KRW-BAD'}]:p==='v1/ticker'?[market,'KRW-BAD'].map(m=>({market:m,acc_trade_price_24h:1e9,signed_change_rate:.1,trade_price:100})):a.market==='KRW-BAD'&&p.endsWith('/15')?[]:(await api(p,a)).map(x=>({...x,market:a.market}));
const archive={};const res=await scanV81({api:mixed,now:()=>now,wait:async()=>{},archive});assert.equal(res.version,'8.1');assert.equal(res.valid,1);assert.equal(res.invalid,1);assert.ok(archive['KRW-BAD']['30m'].length);assert.equal(alertCandidates({...res,status:'STALE'}, {}, now).length,0);
console.log('PASS v8.1: recent 24h cross-frame reconciliation, parent disagreement, fallback, stale evidence, real entry windows, zero-volume block, calendar completeness, post-maintenance replay and exact recovery, archive preservation, mixed scan');
