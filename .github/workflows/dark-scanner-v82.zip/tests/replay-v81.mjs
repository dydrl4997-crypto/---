import {readFile} from 'node:fs/promises';
import {evaluateV80} from '../server/stability-v80.mjs';
import {evaluateV81} from '../server/stability-v81.mjs';
const [candles,latest]=await Promise.all(process.argv.slice(2).map(async f=>JSON.parse(await readFile(f,'utf8'))));
const now=latest.startedAt, rows=[];
for(const old of latest.results){
 const sets=Object.fromEntries(Object.entries(candles.markets[old.symbol]||{}).map(([tf,b])=>[tf,b.filter(x=>x.end<=now).slice(-200)]));
 const meta=Object.fromEntries((old.dataHealth||[]).map(h=>[h.tf,{error:h.error,sourceFresh:h.sourceFresh,recovered:h.recovered}]));
 const context={marketWarning:old.marketWarning||'NONE'};
 const a=evaluateV80(old.symbol,sets,now,meta,context),b=evaluateV81(old.symbol,sets,now,meta,context);
 rows.push({symbol:old.symbol,recorded:old.dataStatus,baseline:a.dataStatus,after:b.dataStatus,beforeTier:a.tier,afterTier:b.tier,beforeEntry:a.entryReady||false,afterEntry:b.entryReady||false,reason:b.dataWarnings, recentSupported:b.dataHealth.reduce((s,h)=>s+h.recentSupported,0)});
}
const count=(k)=>rows.reduce((a,r)=>(a[r[k]]=(a[r[k]]||0)+1,a),{});
console.log(JSON.stringify({total:rows.length,recorded:count('recorded'),baseline:count('baseline'),after:count('after'),baselineMatches:rows.filter(r=>r.recorded===r.baseline).length,baselineTier:count('beforeTier'),afterTier:count('afterTier'),entryBefore:rows.filter(r=>r.beforeEntry).length,entryAfter:rows.filter(r=>r.afterEntry).length,transitions:rows.reduce((a,r)=>(a[r.baseline+' -> '+r.after]=(a[r.baseline+' -> '+r.after]||0)+1,a),{}),rows},null,2));
