import assert from 'node:assert/strict';
import {scanV82,evaluateV82,orderedUniverse,alertCandidates} from '../server/stability-v82.mjs';
import {reconcileTape,candleFlow} from '../server/flow-v82.mjs';
import {units,boundary} from '../js/data-health.mjs';
const start=Date.parse('2026-11-26T23:01:00+09:00');
const bars=(u,n,end)=>Array.from({length:n},(_,i)=>({time:end-(n-i)*u*60000,end:end-(n-i-1)*u*60000,open:100,close:100,high:100,low:100,volume:u,turnover:u*100}));
const markets=Array.from({length:485},(_,i)=>({market:'KRW-T'+i,market_warning:i===484?'CAUTION':'NONE'}));
const tickers=markets.map((m,i)=>({market:m.market,acc_trade_price_24h:i<100?4e8:1e6,acc_trade_price:i===483?4e8:1e6,signed_change_rate:.02,trade_price:100}));
const archive={},verified={};
const api=async(p,a)=>p==='v1/market/all'?markets:p==='v1/ticker'?tickers.filter(t=>a.markets.split(',').includes(t.market)):p==='v1/trades/ticks'?[]:bars(Number(p.split('/').at(-1)),a.count,Date.parse(a.to+'+09:00')).map(b=>({market:a.market,unit:Number(p.split('/').at(-1)),candle_date_time_utc:new Date(b.time).toISOString().slice(0,-1),opening_price:b.open,trade_price:b.close,high_price:b.high,low_price:b.low,candle_acc_trade_volume:b.volume,candle_acc_trade_price:b.turnover}));
assert.equal(orderedUniverse(markets,tickers).length,485);assert.ok(orderedUniverse(markets,tickers).includes('KRW-T484'));
const bench=performance.now();let r=await scanV82({api,now:()=>start,wait:async()=>{},archive,verified,repairFrames:0,flowLimit:0});assert.equal(r.total,485);assert.equal(r.metrics.primaryCompletedMarkets,485);assert.equal(r.metrics.fullCoverage,true);assert.equal(r.metrics.primaryFrames,1940);assert.equal(r.metrics.cacheHits,0);assert.equal(r.metrics.uniqueEngineMarkets,485);assert.equal(r.results.find(x=>x.symbol==='KRW-T484').entryReady,false);assert.equal(Object.keys(archive).length,485);
const coldMs=performance.now()-bench;const warmStart=performance.now();let r2=await scanV82({api,now:()=>start+900000,wait:async()=>{},cache:archive,archive,verified,repairFrames:0,flowLimit:0});assert.equal(r2.metrics.primaryFrames,485);assert.equal(r2.metrics.cacheHits,1455);assert.equal(r2.metrics.fullCoverage,true);
const warmMs=performance.now()-warmStart;const allStart=performance.now();let r3=await scanV82({api,now:()=>start+3600000,wait:async()=>{},cache:archive,archive,verified,repairFrames:0,flowLimit:0});assert.equal(r3.metrics.primaryFrames,1940);assert.equal(r3.metrics.fullCoverage,true); // 00:00 KST all frames close
const allMs=performance.now()-allStart;
const s=Object.fromEntries(Object.entries(units).map(([tf,u])=>[tf,bars(u,200,boundary(start,u))]));s['15m'].pop();for(const [tf,u] of Object.entries(units)){if(tf==='15m')continue;const p=s[tf].at(-1);if(p.end===boundary(start,15)){p.volume-=15;p.turnover-=1500;}}
let obs=evaluateV82('KRW-T0',s,start,{},{});assert.equal(obs.observationOnly,true);assert.equal(obs.entryReady,false);assert.equal(obs.tier,'U');assert.ok(obs.observationFrames.length);
s['30m'].at(-1).turnover+=1;assert.equal(evaluateV82('KRW-T0',s,start,{},{}).observationOnly,undefined);
const candle={time:0,end:900000,open:100,close:100,high:100,low:100,volume:3,turnover:300};const t=[{market:'KRW-T0',sequential_id:1,timestamp:1,trade_price:100,trade_volume:2,ask_bid:'BID'},{market:'KRW-T0',sequential_id:2,timestamp:2,trade_price:100,trade_volume:1,ask_bid:'ASK'}];assert.equal(reconcileTape([candle],t,'KRW-T0').buyShare,2/3);assert.equal(reconcileTape([candle],t.slice(0,1),'KRW-T0').status,'UNVERIFIED');assert.equal(reconcileTape([candle],[...t,t[0]],'KRW-T0').status,'UNVERIFIED');assert.equal(candleFlow([{...candle,open:99,close:100,low:95,high:100.5}]).lowerWickBull,true);
let clock=start;const slow=async(p,a)=>{clock+=10000;return api(p,a);};const late=await scanV82({api:slow,now:()=>clock,wait:async()=>{},budgetMs:20000,repairFrames:0,flowLimit:0});assert.equal(late.metrics.fullCoverage,false);assert.equal(alertCandidates(late,{},clock).length,0);
// End-to-end repair with a real missing candle (mock exchange). Primary query omits
// the old interval; dedicated backfill returns the genuine candle. No fabricated fill.
const hole=boundary(start,15)-35*900000,one=markets.slice(0,1),fixArchive={},fixVerified={};
const repairApi=async(p,a)=>{if(p==='v1/market/all')return one;if(p==='v1/ticker')return tickers.slice(0,1);const rows=await api(p,a);if(p.endsWith('/15')&&Date.parse(a.to+'+09:00')===boundary(start,15))return rows.filter(x=>Date.parse(x.candle_date_time_utc+'Z')!==hole);return rows;};
const repaired=await scanV82({api:repairApi,now:()=>start,wait:async()=>{},archive:fixArchive,verified:fixVerified,repairFrames:32,flowLimit:0});assert.equal(repaired.metrics.primaryCompletedMarkets,1);assert.equal(repaired.recovered,1);assert.ok(fixArchive[one[0].market]['15m'].some(b=>b.time===hole));
console.log('PASS v8.2: 485 all-market cold/warm/all-boundary mock scans, priority without exclusion, warning guard, incomplete coverage block, no-trade observation, complete/incomplete tape, wick');
console.log('V82 MOCK REQUESTS',JSON.stringify({cold:r.metrics.requests,warm:r2.metrics.requests,allBoundary:r3.metrics.requests,localUnpacedMs:{cold:Math.round(coldMs),warm:Math.round(warmMs),allBoundary:Math.round(allMs)}}));
