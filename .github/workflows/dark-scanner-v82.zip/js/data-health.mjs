// Bithumb 240m grid observed in GitHub diagnostics: 00/04/08/12/16/20 KST.
export const units={'15m':15,'30m':30,'1h':60,'4h':240};
export const KST=9*3600000;
export const boundary=(t,mins)=>Math.floor((t+KST)/(mins*60000))*mins*60000-KST;
export const kstString=t=>new Date(t+KST).toISOString().slice(0,19);
export function inspectBars(bars,mins,now,tf=`${mins}m`){
 const step=mins*60000,expected=boundary(now,mins);
 if(!Array.isArray(bars)||!bars.length)throw Error(tf+' 봉 누락');
 const gaps=[];
 for(let i=0;i<bars.length;i++){
  const b=bars[i];if(![b.time,b.end,b.open,b.close,b.high,b.low,b.volume,b.turnover].every(Number.isFinite)||boundary(b.time,mins)!==b.time||b.end!==b.time+step||b.low<=0||b.low>Math.min(b.open,b.close)||b.high<Math.max(b.open,b.close)||b.high<b.low||b.volume<0||b.turnover<0||(i&&b.time<=bars[i-1].time))throw Error(tf+' 봉 형식/중복 오류');
  if(i&&b.time-bars[i-1].time!==step)gaps.push({start:bars[i-1].end,end:b.time,missing:(b.time-bars[i-1].end)/step});
 }
 if(bars.at(-1).end>expected)throw Error(tf+' 미확정봉 오류');
 return {expected,latest:bars.at(-1).end,gaps};
}
export function validateSets(sets,now){
 for(const [tf,mins] of Object.entries(units)){
  const h=inspectBars(sets[tf],mins,now,tf);
  if(h.latest!==h.expected)throw Error(tf+' 최신 확정봉 미수신');
  if(h.gaps.length)throw Error(tf+' 중간 봉 누락 (거래 없음 포함)');
 }
}
